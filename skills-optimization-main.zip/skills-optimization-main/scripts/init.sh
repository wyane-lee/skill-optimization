#!/bin/bash

# Skills 优化系统 - 初始化脚本
set -e

SKILL_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PROJECT_NAME="skills-optimization"

echo "🚀 初始化 $PROJECT_NAME Skill..."
echo ""

# 1. 检查 Python 环境
echo "✓ 检查 Python 环境..."
if ! command -v python3 &> /dev/null; then
    echo "❌ 错误：未找到 Python 3"
    exit 1
fi
PYTHON_VERSION=$(python3 --version | awk '{print $2}')
echo "  Python 版本: $PYTHON_VERSION"

# 2. 创建必要的目录
echo "✓ 创建目录结构..."
mkdir -p "$SKILL_DIR/data/executions"
mkdir -p "$SKILL_DIR/reports/performance"
mkdir -p "$SKILL_DIR/logs"
echo "  ✓ data/executions/"
echo "  ✓ reports/performance/"
echo "  ✓ logs/"

# 3. 验证核心文件
echo "✓ 验证核心文件..."
if [ -f "$SKILL_DIR/SKILL.md" ]; then
    echo "  ✓ SKILL.md"
fi
if [ -f "$SKILL_DIR/config.json" ]; then
    echo "  ✓ config.json"
fi
if [ -f "$SKILL_DIR/tools/skill_execution_monitor.py" ]; then
    echo "  ✓ tools/skill_execution_monitor.py"
fi

# 4. 创建初始化标记
echo "✓ 创建初始化标记..."
touch "$SKILL_DIR/.initialized"

echo ""
echo "✅ 初始化完成！"
echo ""

#!/bin/bash
# Skill Watch - 实时监控 Skill 执行日志
# 用法: ./skill-watch.sh [execution_id]

WATCH_DIR="$HOME/.opencode/skill-executions"

skill_watch() {
    local execution_id=$1
    
    if [ -z "$execution_id" ]; then
        # 如果没有指定 execution_id，监控最新的执行
        execution_id=$(ls -t "$WATCH_DIR" 2>/dev/null | head -1)
    fi
    
    if [ -z "$execution_id" ]; then
        echo "❌ 没有找到 Skill 执行"
        return 1
    fi
    
    local exec_dir="$WATCH_DIR/$execution_id"
    local log_file="$exec_dir/execution.log"
    
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "📊 实时监控 Skill 执行"
    echo "Execution ID: $execution_id"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo ""
    
    # 实时显示日志
    if [ -f "$log_file" ]; then
        tail -f "$log_file"
    else
        echo "⏳ 等待执行日志..."
        while [ ! -f "$log_file" ]; do
            sleep 0.1
        done
        tail -f "$log_file"
    fi
}

skill_watch "$@"

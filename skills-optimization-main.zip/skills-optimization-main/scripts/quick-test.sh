#!/bin/bash

# 快速功能测试
SKILL_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

echo "🧪 运行快速功能测试..."
echo ""

cd "$SKILL_DIR"

# 测试 1: 导入模块
echo "测试 1: 导入 skill_execution_monitor..."
python3 << 'PYTHON'
import sys
sys.path.insert(0, '/Users/wenfeli/.config/opencode/skills/skills-optimization/tools')

try:
    from skill_execution_monitor import SkillExecutionMonitor
    print("✅ 成功导入 SkillExecutionMonitor")
except Exception as e:
    print(f"❌ 导入失败: {e}")
    sys.exit(1)
PYTHON

echo ""

# 测试 2: 创建监控实例
echo "测试 2: 创建监控实例..."
python3 << 'PYTHON'
import sys
sys.path.insert(0, '/Users/wenfeli/.config/opencode/skills/skills-optimization/tools')

try:
    from skill_execution_monitor import SkillExecutionMonitor
    monitor = SkillExecutionMonitor()
    print("✅ 成功创建 SkillExecutionMonitor 实例")
except Exception as e:
    print(f"❌ 创建失败: {e}")
    sys.exit(1)
PYTHON

echo ""

# 测试 3: 测试监控功能
echo "测试 3: 测试监控功能..."
python3 << 'PYTHON'
import sys
sys.path.insert(0, '/Users/wenfeli/.config/opencode/skills/skills-optimization/tools')

try:
    from skill_execution_monitor import SkillExecutionMonitor
    monitor = SkillExecutionMonitor()
    
    result = monitor.monitor_execution(
        skill_name="test-skill",
        execution_id="test_001",
        log_content="Test log\n✅ Success",
        metadata={"duration": 1.0}
    )
    
    print("✅ 成功执行 monitor_execution()")
except Exception as e:
    print(f"❌ 执行失败: {e}")
    sys.exit(1)
PYTHON

echo ""

# 测试 4: 测试分析功能
echo "测试 4: 测试分析功能..."
python3 << 'PYTHON'
import sys
sys.path.insert(0, '/Users/wenfeli/.config/opencode/skills/skills-optimization/tools')

try:
    from skill_execution_monitor import SkillExecutionMonitor
    monitor = SkillExecutionMonitor()
    
    analysis = monitor.analyze_performance("test-skill", "24h")
    print("✅ 成功执行 analyze_performance()")
except Exception as e:
    print(f"❌ 执行失败: {e}")
    sys.exit(1)
PYTHON

echo ""

# 测试 5: 导入其他工具
echo "测试 5: 导入其他工具..."
python3 << 'PYTHON'
import sys
sys.path.insert(0, '/Users/wenfeli/.config/opencode/skills/skills-optimization/tools')

try:
    from skill_router import SkillRouter
    print("✅ 成功导入 SkillRouter")
except Exception as e:
    print(f"⚠️  SkillRouter 导入失败: {e}")

try:
    from overlap_detector import OverlapDetector
    print("✅ 成功导入 OverlapDetector")
except Exception as e:
    print(f"⚠️  OverlapDetector 导入失败: {e}")

try:
    from health_check import HealthChecker
    print("✅ 成功导入 HealthChecker")
except Exception as e:
    print(f"⚠️  HealthChecker 导入失败: {e}")

try:
    from usage_analyzer import UsageAnalyzer
    print("✅ 成功导入 UsageAnalyzer")
except Exception as e:
    print(f"⚠️  UsageAnalyzer 导入失败: {e}")
PYTHON

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "✅ 快速功能测试完成！"
echo ""

#!/bin/bash
# 一键启动 Skill 监控机制
# 用法: ./setup-skill-monitoring.sh

set -e

PROJECT_DIR="/Users/wenfeli/Documents/claude_projects/skills-optimization"
BIN_DIR="$HOME/bin"
LAUNCHD_DIR="$HOME/Library/LaunchAgents"
OPENCODE_DIR="$HOME/.opencode"

echo "╔════════════════════════════════════════════════════════════════╗"
echo "║         🚀 Skill 监控机制一键启动                              ║"
echo "╚════════════════════════════════════════════════════════════════╝"
echo ""

# 步骤 1：创建必要的目录
echo "📁 创建必要的目录..."
mkdir -p "$BIN_DIR"
mkdir -p "$LAUNCHD_DIR"
mkdir -p "$OPENCODE_DIR"
echo "✅ 目录创建完成"
echo ""

# 步骤 2：复制脚本到 ~/bin
echo "📋 复制监控脚本..."
cp "$PROJECT_DIR/scripts/skill-monitor-daemon.sh" "$BIN_DIR/"
cp "$PROJECT_DIR/scripts/skill-watch.sh" "$BIN_DIR/"
cp "$PROJECT_DIR/scripts/skill-dashboard.sh" "$BIN_DIR/"
cp "$PROJECT_DIR/scripts/skill-report.sh" "$BIN_DIR/"

# 赋予执行权限
chmod +x "$BIN_DIR/skill-monitor-daemon.sh"
chmod +x "$BIN_DIR/skill-watch.sh"
chmod +x "$BIN_DIR/skill-dashboard.sh"
chmod +x "$BIN_DIR/skill-report.sh"

echo "✅ 脚本复制完成"
echo ""

# 步骤 3：安装 launchd 服务
echo "⚙️  安装 launchd 服务..."
cp "$PROJECT_DIR/scripts/com.opencode.skill-monitor.plist" "$LAUNCHD_DIR/"

# 加载服务
launchctl load "$LAUNCHD_DIR/com.opencode.skill-monitor.plist" 2>/dev/null || {
    echo "⚠️  服务已存在，卸载后重新加载..."
    launchctl unload "$LAUNCHD_DIR/com.opencode.skill-monitor.plist" 2>/dev/null || true
    launchctl load "$LAUNCHD_DIR/com.opencode.skill-monitor.plist"
}

echo "✅ launchd 服务安装完成"
echo ""

# 步骤 4：验证服务运行
echo "🔍 验证服务运行状态..."
sleep 1

if launchctl list | grep -q "com.opencode.skill-monitor"; then
    echo "✅ 服务已启动"
else
    echo "❌ 服务启动失败"
    exit 1
fi
echo ""

# 步骤 5：创建别名
echo "🔗 创建命令别名..."

# 检查 shell 配置文件
if [ -f "$HOME/.zshrc" ]; then
    SHELL_RC="$HOME/.zshrc"
elif [ -f "$HOME/.bashrc" ]; then
    SHELL_RC="$HOME/.bashrc"
else
    SHELL_RC="$HOME/.zshrc"
fi

# 添加别名（如果还没有）
if ! grep -q "alias skill-watch" "$SHELL_RC"; then
    cat >> "$SHELL_RC" << 'EOF'

# Skill 监控命令别名
alias skill-watch='~/bin/skill-watch.sh'
alias skill-dashboard='~/bin/skill-dashboard.sh'
alias skill-report='~/bin/skill-report.sh'
alias skill-check='cat ~/.opencode/skill-executions/$(ls -t ~/.opencode/skill-executions/ | head -1)/execution-report.json | jq'
EOF
    echo "✅ 别名添加到 $SHELL_RC"
else
    echo "✅ 别名已存在"
fi
echo ""

# 步骤 6：显示启动完成信息
echo "╔════════════════════════════════════════════════════════════════╗"
echo "║                   ✅ 启动完成！                                ║"
echo "╚════════════════════════════════════════════════════════════════╝"
echo ""

echo "📊 可用的监控命令："
echo ""
echo "  skill-watch              # 实时监控最新执行"
echo "  skill-watch <id>         # 监控特定执行"
echo "  skill-dashboard          # 显示实时仪表板"
echo "  skill-report             # 生成执行报告"
echo "  skill-report <id>        # 生成特定执行的报告"
echo "  skill-check              # 快速检查最新执行"
echo ""

echo "📝 查看监控日志："
echo ""
echo "  tail -f ~/.opencode/skill-monitor.log"
echo ""

echo "🔧 管理 launchd 服务："
echo ""
echo "  # 查看服务状态"
echo "  launchctl list | grep skill-monitor"
echo ""
echo "  # 停止服务"
echo "  launchctl unload ~/Library/LaunchAgents/com.opencode.skill-monitor.plist"
echo ""
echo "  # 启动服务"
echo "  launchctl load ~/Library/LaunchAgents/com.opencode.skill-monitor.plist"
echo ""

echo "🚀 下一步："
echo ""
echo "  1. 重新加载 shell 配置："
echo "     source $SHELL_RC"
echo ""
echo "  2. 手动触发一个 Skill 执行，观察监控反应"
echo ""
echo "  3. 查看监控日志："
echo "     tail -f ~/.opencode/skill-monitor.log"
echo ""

echo "✨ 监控机制已启动！"

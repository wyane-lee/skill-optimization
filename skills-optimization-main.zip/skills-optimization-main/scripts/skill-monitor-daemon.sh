#!/bin/bash
# Skill Monitor Daemon - 实时监控 Skill 执行
# 用法: ./skill-monitor-daemon.sh

set -e

WATCH_DIR="$HOME/.opencode/skill-executions"
LOG_FILE="$HOME/.opencode/skill-monitor.log"
LAST_CHECK_FILE="$HOME/.opencode/.skill-monitor-last-check"

# 确保目录存在
mkdir -p "$WATCH_DIR"
mkdir -p "$(dirname "$LOG_FILE")"

# 初始化
if [ ! -f "$LAST_CHECK_FILE" ]; then
    echo 0 > "$LAST_CHECK_FILE"
fi

log() {
    local msg="$1"
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    echo "[$timestamp] $msg" | tee -a "$LOG_FILE"
}

monitor_execution() {
    local execution_id=$1
    local exec_dir="$WATCH_DIR/$execution_id"
    local log_file="$exec_dir/execution.log"
    local report_file="$exec_dir/execution-report.json"
    
    log "🚀 Skill 执行开始: $execution_id"
    
    # 等待执行完成（检查 execution-report.json）
    local timeout=300  # 5 分钟超时
    local elapsed=0
    
    while [ ! -f "$report_file" ] && [ $elapsed -lt $timeout ]; do
        sleep 0.5
        elapsed=$((elapsed + 1))
    done
    
    if [ ! -f "$report_file" ]; then
        log "❌ 执行超时: $execution_id"
        return 1
    fi
    
    # 显示执行结果
    local status=$(jq -r '.status' "$report_file" 2>/dev/null || echo "unknown")
    local skill_name=$(jq -r '.skill_name' "$report_file" 2>/dev/null || echo "unknown")
    local elapsed_time=$(jq -r '.elapsed_seconds' "$report_file" 2>/dev/null || echo "0")
    
    if [ "$status" = "success" ]; then
        log "✅ Skill 执行成功: $skill_name (${elapsed_time}s)"
    else
        log "❌ Skill 执行失败: $skill_name"
    fi
    
    # 发送 macOS 通知
    if command -v osascript &> /dev/null; then
        if [ "$status" = "success" ]; then
            osascript -e "display notification \"$skill_name 执行成功 (${elapsed_time}s)\" with title \"✅ Skill 执行完成\"" 2>/dev/null || true
        else
            osascript -e "display notification \"$skill_name 执行失败\" with title \"❌ Skill 执行失败\"" 2>/dev/null || true
        fi
    fi
}

main() {
    log "Skill Monitor Daemon 启动"
    log "监控目录: $WATCH_DIR"
    
    local last_check=$(cat "$LAST_CHECK_FILE")
    
    while true; do
        # 每 0.5 秒检查一次新的执行
        sleep 0.5
        
        # 找到所有执行目录
        if [ -d "$WATCH_DIR" ]; then
            for exec_dir in $(ls -t "$WATCH_DIR" 2>/dev/null); do
                local full_path="$WATCH_DIR/$exec_dir"
                
                if [ -d "$full_path" ]; then
                    # 获取目录的修改时间
                    local dir_time=$(stat -f %m "$full_path" 2>/dev/null || echo 0)
                    
                    # 如果这是一个新的执行（时间戳更新）
                    if [ "$dir_time" -gt "$last_check" ]; then
                        last_check=$dir_time
                        echo "$last_check" > "$LAST_CHECK_FILE"
                        
                        # 监控这个执行
                        monitor_execution "$exec_dir" &
                    fi
                fi
            done
        fi
    done
}

# 捕获 SIGTERM 和 SIGINT
trap 'log "Skill Monitor Daemon 停止"; exit 0' SIGTERM SIGINT

main

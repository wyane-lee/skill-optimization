#!/bin/bash
# Skill 监控系统 - 部署验证脚本
# 验证 Skill 是否可以正确安装和使用

set -e

echo "========================================================================"
echo "Skill 监控系统 - 部署验证"
echo "========================================================================"

SKILL_DIR="$HOME/.config/opencode/skills/skill-monitoring"
EXEC_DIR="$HOME/.opencode/skill-executions"
BIN_DIR="$HOME/bin"

# 颜色定义
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# 计数器
PASSED=0
FAILED=0

# 测试函数
test_check() {
    local name=$1
    local command=$2
    
    echo -n "  检查: $name ... "
    
    if eval "$command" > /dev/null 2>&1; then
        echo -e "${GREEN}✅ 通过${NC}"
        ((PASSED++))
    else
        echo -e "${RED}❌ 失败${NC}"
        ((FAILED++))
    fi
}

# 测试 1: Skill 目录结构
echo ""
echo "📋 Phase 1: 目录结构验证"
echo "----------------------------------------------------------------------"

test_check "Skill 目录存在" "[ -d '$SKILL_DIR' ]"
test_check "scripts 目录存在" "[ -d '$SKILL_DIR/scripts' ]"
test_check "tools 目录存在" "[ -d '$SKILL_DIR/tools' ]"
test_check "docs 目录存在" "[ -d '$SKILL_DIR/docs' ]"
test_check "data 目录存在" "[ -d '$SKILL_DIR/data' ]"

# 测试 2: 关键文件
echo ""
echo "📋 Phase 2: 关键文件验证"
echo "----------------------------------------------------------------------"

test_check "SKILL.md 存在" "[ -f '$SKILL_DIR/SKILL.md' ]"
test_check "setup-skill-monitoring.sh 存在" "[ -f '$SKILL_DIR/scripts/setup-skill-monitoring.sh' ]"
test_check "skill_monitoring.py 存在" "[ -f '$SKILL_DIR/tools/skill_monitoring.py' ]"
test_check "skill_router.py 存在" "[ -f '$SKILL_DIR/tools/skill_router.py' ]"
test_check "usage_analyzer.py 存在" "[ -f '$SKILL_DIR/tools/usage_analyzer.py' ]"
test_check "test_suite.py 存在" "[ -f '$SKILL_DIR/tools/test_suite.py' ]"
test_check "skills-matrix.json 存在" "[ -f '$SKILL_DIR/data/skills-matrix.json' ]"

# 测试 3: 脚本权限
echo ""
echo "📋 Phase 3: 脚本权限验证"
echo "----------------------------------------------------------------------"

test_check "setup-skill-monitoring.sh 可执行" "[ -x '$SKILL_DIR/scripts/setup-skill-monitoring.sh' ]"
test_check "skill-monitor-daemon.sh 可执行" "[ -x '$SKILL_DIR/scripts/skill-monitor-daemon.sh' ]"
test_check "skill-watch.sh 可执行" "[ -x '$SKILL_DIR/scripts/skill-watch.sh' ]"
test_check "skill-dashboard.sh 可执行" "[ -x '$SKILL_DIR/scripts/skill-dashboard.sh' ]"
test_check "skill-report.sh 可执行" "[ -x '$SKILL_DIR/scripts/skill-report.sh' ]"

# 测试 4: Python 模块
echo ""
echo "📋 Phase 4: Python 模块验证"
echo "----------------------------------------------------------------------"

test_check "skill_monitoring.py 语法正确" "python3 -m py_compile '$SKILL_DIR/tools/skill_monitoring.py'"
test_check "skill_router.py 语法正确" "python3 -m py_compile '$SKILL_DIR/tools/skill_router.py'"
test_check "usage_analyzer.py 语法正确" "python3 -m py_compile '$SKILL_DIR/tools/usage_analyzer.py'"
test_check "test_suite.py 语法正确" "python3 -m py_compile '$SKILL_DIR/tools/test_suite.py'"

# 测试 5: 执行目录
echo ""
echo "📋 Phase 5: 执行目录验证"
echo "----------------------------------------------------------------------"

test_check "执行目录存在" "[ -d '$EXEC_DIR' ]"
test_check "执行目录可写" "[ -w '$EXEC_DIR' ]"

# 测试 6: 命令别名（如果已安装）
echo ""
echo "📋 Phase 6: 命令别名验证"
echo "----------------------------------------------------------------------"

if [ -f "$BIN_DIR/skill-watch" ]; then
    test_check "skill-watch 命令存在" "[ -f '$BIN_DIR/skill-watch' ]"
    test_check "skill-watch 可执行" "[ -x '$BIN_DIR/skill-watch' ]"
else
    echo "  ⚠️  命令别名未安装（需要运行 setup-skill-monitoring.sh）"
fi

# 测试 7: launchd 服务（如果已安装）
echo ""
echo "📋 Phase 7: launchd 服务验证"
echo "----------------------------------------------------------------------"

if [ -f "$HOME/Library/LaunchAgents/com.opencode.skill-monitor.plist" ]; then
    test_check "launchd plist 存在" "[ -f '$HOME/Library/LaunchAgents/com.opencode.skill-monitor.plist' ]"
    test_check "launchd 服务已加载" "launchctl list | grep -q 'com.opencode.skill-monitor'"
else
    echo "  ⚠️  launchd 服务未安装（需要运行 setup-skill-monitoring.sh）"
fi

# 测试 8: 数据文件
echo ""
echo "📋 Phase 8: 数据文件验证"
echo "----------------------------------------------------------------------"

test_check "skills-inventory.json 存在" "[ -f '$SKILL_DIR/data/skills-inventory.json' ]"
test_check "skills-matrix.json 存在" "[ -f '$SKILL_DIR/data/skills-matrix.json' ]"
test_check "overlaps-detected.json 存在" "[ -f '$SKILL_DIR/data/overlaps-detected.json' ]"
test_check "skills-documentation.json 存在" "[ -f '$SKILL_DIR/data/skills-documentation.json' ]"

# 测试 9: 文档
echo ""
echo "📋 Phase 9: 文档验证"
echo "----------------------------------------------------------------------"

test_check "SKILL-MONITORING-STARTUP.md 存在" "[ -f '$SKILL_DIR/docs/SKILL-MONITORING-STARTUP.md' ]"
test_check "SKILL-CALL-CONFIRMATION.md 存在" "[ -f '$SKILL_DIR/docs/SKILL-CALL-CONFIRMATION.md' ]"
test_check "SKILL-EXECUTION-VERIFICATION.md 存在" "[ -f '$SKILL_DIR/docs/SKILL-EXECUTION-VERIFICATION.md' ]"

# 测试 10: 功能测试
echo ""
echo "📋 Phase 10: 功能测试"
echo "----------------------------------------------------------------------"

# 测试 Python 导入
echo -n "  测试: Python 模块导入 ... "
if python3 << 'EOF' > /dev/null 2>&1
import sys
sys.path.insert(0, '$SKILL_DIR/tools')
from skill_monitoring import SkillMonitoring
monitor = SkillMonitoring()
execution_id = monitor.generate_execution_id()
assert execution_id.startswith('exec_'), "Invalid execution ID"
EOF
then
    echo -e "${GREEN}✅ 通过${NC}"
    ((PASSED++))
else
    echo -e "${RED}❌ 失败${NC}"
    ((FAILED++))
fi

# 测试路由
echo -n "  测试: 智能路由 ... "
if python3 << 'EOF' > /dev/null 2>&1
import sys
sys.path.insert(0, '$SKILL_DIR/tools')
from skill_router import SkillRouter
router = SkillRouter()
skills = router.list_all_skills()
assert isinstance(skills, list), "Invalid skills list"
EOF
then
    echo -e "${GREEN}✅ 通过${NC}"
    ((PASSED++))
else
    echo -e "${RED}❌ 失败${NC}"
    ((FAILED++))
fi

# 测试分析
echo -n "  测试: 性能分析 ... "
if python3 << 'EOF' > /dev/null 2>&1
import sys
sys.path.insert(0, '$SKILL_DIR/tools')
from usage_analyzer import UsageAnalyzer
analyzer = UsageAnalyzer()
result = analyzer.analyze_all()
assert 'status' in result, "Invalid analysis result"
EOF
then
    echo -e "${GREEN}✅ 通过${NC}"
    ((PASSED++))
else
    echo -e "${RED}❌ 失败${NC}"
    ((FAILED++))
fi

# 生成报告
echo ""
echo "========================================================================"
echo "部署验证报告"
echo "========================================================================"

TOTAL=$((PASSED + FAILED))
SUCCESS_RATE=$((PASSED * 100 / TOTAL))

echo ""
echo "📊 总体统计:"
echo "  总检查数: $TOTAL"
echo "  通过: $PASSED"
echo "  失败: $FAILED"
echo "  成功率: $SUCCESS_RATE%"

if [ $FAILED -eq 0 ]; then
    echo ""
    echo -e "${GREEN}✅ 部署验证成功！Skill 已准备好投产。${NC}"
    echo ""
    echo "下一步："
    echo "  1. 运行安装脚本："
    echo "     bash $SKILL_DIR/scripts/setup-skill-monitoring.sh"
    echo ""
    echo "  2. 验证安装："
    echo "     launchctl list | grep skill-monitor"
    echo ""
    echo "  3. 启动监控："
    echo "     skill-dashboard"
    echo ""
    exit 0
else
    echo ""
    echo -e "${RED}❌ 部署验证失败！请检查上述错误。${NC}"
    echo ""
    echo "常见问题："
    echo "  - 确保 Skill 目录已复制到 $SKILL_DIR"
    echo "  - 确保脚本有执行权限"
    echo "  - 确保 Python 3 已安装"
    echo ""
    exit 1
fi

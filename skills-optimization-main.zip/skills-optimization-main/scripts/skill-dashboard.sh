#!/bin/bash
# Skill Dashboard - 实时仪表板
# 用法: ./skill-dashboard.sh

WATCH_DIR="$HOME/.opencode/skill-executions"

skill_dashboard() {
    while true; do
        clear
        
        echo "╔════════════════════════════════════════════════════════════════╗"
        echo "║           🎯 Skill 执行实时仪表板                              ║"
        echo "╚════════════════════════════════════════════════════════════════╝"
        echo ""
        
        # 显示最近的 5 个执行
        echo "📋 最近的执行："
        echo ""
        
        local count=0
        for exec_dir in $(ls -t "$WATCH_DIR" 2>/dev/null | head -5); do
            count=$((count + 1))
            
            local report="$WATCH_DIR/$exec_dir/execution-report.json"
            
            if [ -f "$report" ]; then
                local skill_name=$(jq -r '.skill_name' "$report" 2>/dev/null || echo "unknown")
                local status=$(jq -r '.status' "$report" 2>/dev/null || echo "unknown")
                local elapsed=$(jq -r '.elapsed_seconds' "$report" 2>/dev/null || echo "0")
                
                # 显示状态图标
                if [ "$status" = "success" ]; then
                    local icon="✅"
                else
                    local icon="❌"
                fi
                
                printf "%d. %s %-30s [%s] %.3fs\n" "$count" "$icon" "$skill_name" "$status" "$elapsed"
            else
                # 执行还在进行中
                local log_file="$WATCH_DIR/$exec_dir/execution.log"
                if [ -f "$log_file" ]; then
                    local skill_name=$(grep "skill_name:" "$log_file" 2>/dev/null | head -1 | awk -F': ' '{print $2}' || echo "unknown")
                    printf "%d. ⏳ %-30s [running]\n" "$count" "$skill_name"
                fi
            fi
        done
        
        echo ""
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo ""
        
        # 显示统计信息
        echo "📊 统计信息："
        echo ""
        
        local total=$(ls -1 "$WATCH_DIR" 2>/dev/null | wc -l)
        local success=$(find "$WATCH_DIR" -name "execution-report.json" -exec grep -l '"status": "success"' {} \; 2>/dev/null | wc -l)
        local failed=$(find "$WATCH_DIR" -name "execution-report.json" -exec grep -l '"status": "failed"' {} \; 2>/dev/null | wc -l)
        
        echo "总执行数: $total"
        echo "成功: $success"
        echo "失败: $failed"
        
        if [ "$total" -gt 0 ]; then
            local success_rate=$(echo "scale=1; $success * 100 / $total" | bc 2>/dev/null || echo "0")
            echo "成功率: ${success_rate}%"
        fi
        
        echo ""
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo ""
        echo "按 Ctrl+C 退出，每 2 秒刷新一次"
        echo ""
        
        sleep 2
    done
}

skill_dashboard

#!/bin/bash

# Skills 优化系统 - 测试脚本
set -e

SKILL_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

echo "🧪 运行 skills-optimization 测试..."
echo ""

# 检查 pytest
if ! command -v pytest &> /dev/null; then
    echo "⚠️  pytest 未安装，尝试安装..."
    pip3 install pytest --quiet
fi

cd "$SKILL_DIR"

# 运行测试
echo "运行单元测试..."
python3 -m pytest tools/test_skill_execution_monitor.py -v --tb=short 2>&1 || {
    echo "❌ 测试失败"
    exit 1
}

echo ""
echo "✅ 所有测试通过！"
echo ""

#!/bin/bash
# Skill Report - 生成执行报告
# 用法: ./skill-report.sh [execution_id]

WATCH_DIR="$HOME/.opencode/skill-executions"

skill_report() {
    local execution_id=$1
    
    if [ -z "$execution_id" ]; then
        execution_id=$(ls -t "$WATCH_DIR" 2>/dev/null | head -1)
    fi
    
    local exec_dir="$WATCH_DIR/$execution_id"
    local report="$exec_dir/execution-report.json"
    
    if [ ! -f "$report" ]; then
        echo "❌ 报告文件不存在"
        return 1
    fi
    
    echo "╔════════════════════════════════════════════════════════════════╗"
    echo "║                    📄 Skill 执行报告                           ║"
    echo "╚════════════════════════════════════════════════════════════════╝"
    echo ""
    
    # 基本信息
    echo "📋 基本信息"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    jq '{
        skill_name: .skill_name,
        status: .status,
        elapsed_seconds: .elapsed_seconds,
        timestamp: .timestamp
    }' "$report" 2>/dev/null | sed 's/^/  /'
    echo ""
    
    # 前置条件
    echo "✅ 前置条件检查"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    jq '.preconditions | to_entries[] | "  \(.key): \(.value)"' -r "$report" 2>/dev/null || echo "  (无数据)"
    echo ""
    
    # 工具调用
    echo "🔧 工具调用"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    jq '.tool_calls[] | "  \(.tool_name): \(.status)"' -r "$report" 2>/dev/null || echo "  (无数据)"
    echo ""
    
    # 输出验证
    echo "📊 输出验证"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    jq '.output_verification | to_entries[] | "  \(.key): \(.value)"' -r "$report" 2>/dev/null || echo "  (无数据)"
    echo ""
    
    # 副作用
    echo "⚙️  副作用"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    jq '.side_effects | to_entries[] | "  \(.key): \(.value)"' -r "$report" 2>/dev/null || echo "  (无数据)"
    echo ""
    
    # 生成的工件
    echo "📦 生成的工件"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    if [ -d "$exec_dir/artifacts" ]; then
        ls -lh "$exec_dir/artifacts/" 2>/dev/null | tail -n +2 | awk '{print "  " $9 " (" $5 ")"}' || echo "  (无)"
    else
        echo "  (无)"
    fi
    echo ""
    
    echo "╔════════════════════════════════════════════════════════════════╗"
    echo "║                        报告生成完成                            ║"
    echo "╚════════════════════════════════════════════════════════════════╝"
}

skill_report "$@"

# Skill: Skill 监控和优化系统

## 用途

完整的 Skill 监控、验证、路由和性能分析系统。提供：

- **Skill 执行监控** — 实时追踪 Skill 执行，自动生成执行报告
- **执行验证** — 三层验证框架确保 Skill 真正执行
- **智能路由** — 根据用户意图自动选择最合适的 Skill
- **性能分析** — 追踪 Skill 执行成功率、耗时、错误率等指标
- **Agent 集成** — 提供 Python API 让 Agent 自动调用监控功能

## 触发条件

用户说：
- "启动 Skill 监控"
- "监控 Skill 执行"
- "分析 Skill 性能"
- "路由到合适的 Skill"
- "获取 Skill 成功率"
- "skill-watch", "skill-dashboard", "skill-report"

## 功能

### 1. Skill 监控（skill_monitoring.py）

```python
from skill_monitoring import SkillMonitoring

monitor = SkillMonitoring()

# 生成执行 ID
execution_id = monitor.generate_execution_id()

# 一键启动监控
result = monitor.setup(execution_id)

# 实时监控
logs = monitor.watch(execution_id)

# 显示仪表板
dashboard = monitor.dashboard()

# 生成报告
report = monitor.report(execution_id)

# 列出最近的执行
executions = monitor.list_executions(limit=10)
```

### 2. 智能路由（skill_router.py）

```python
from skill_router import SkillRouter

router = SkillRouter()

# 根据用户意图路由
matches = router.route("我想监控 Skill 执行", top_k=3)

# 根据操作类型路由
matches = router.route_by_action("search", top_k=3)

# 根据数据源路由
matches = router.route_by_data_source("webex", top_k=3)

# 获取 Skill 信息
info = router.get_skill_info("skill-name")
```

### 3. 性能分析（usage_analyzer.py）

```python
from usage_analyzer import UsageAnalyzer

analyzer = UsageAnalyzer()

# 分析所有执行
analysis = analyzer.analyze_all()

# 分析特定 Skill
skill_analysis = analyzer.analyze_skill("skill-name")

# 获取成功率
success_rate = analyzer.get_success_rate()

# 获取错误报告
errors = analyzer.get_error_report()

# 获取性能报告
performance = analyzer.get_performance_report()
```

### 4. 执行验证（skill-execution-verifier.py）

```python
from skill_execution_verifier import SkillExecutionVerifier

verifier = SkillExecutionVerifier("skill-name")

# 记录事件
verifier.log_event("event_type", {"key": "value"})

# 验证前置条件
passed = verifier.verify_preconditions({"check1": True})

# 验证工具执行
verification = verifier.verify_tool_execution("bash", {}, "output")

# 验证输出
output_check = verifier.verify_output(output, expected_type=dict)
```

## 使用方式

### 命令行使用

```bash
# 一键启动监控
bash ~/.config/opencode/skills/skill-monitoring/scripts/setup-skill-monitoring.sh

# 实时监控
skill-watch

# 显示仪表板
skill-dashboard

# 生成报告
skill-report

# 快速检查
skill-check
```

### Python API 使用

```python
from skill_monitoring import SkillMonitoring
from skill_router import SkillRouter
from usage_analyzer import UsageAnalyzer

# 初始化
monitor = SkillMonitoring()
router = SkillRouter()
analyzer = UsageAnalyzer()

# 生成执行 ID
execution_id = monitor.generate_execution_id()

# 路由到合适的 Skill
matches = router.route("用户意图", top_k=3)

# 分析性能
analysis = analyzer.analyze_all()
```

## 输出

### 执行日志
```
~/.opencode/skill-executions/{execution_id}/execution.log
```

### 执行报告
```
~/.opencode/skill-executions/{execution_id}/execution-report.json
```

### 工件
```
~/.opencode/skill-executions/{execution_id}/artifacts/
```

## 测试

运行完整测试套件：

```bash
python3 ~/.config/opencode/skills/skill-monitoring/tools/test_suite.py
```

测试覆盖：
- ✅ 单元测试（4 个模块，15 个测试）
- ✅ 集成测试（3 个测试）
- ✅ 端到端测试（1 个测试）
- ✅ 性能测试（3 个测试）

**总体成功率：100%（22/22 测试通过）**

## 文档

- `SKILL-MONITORING-STARTUP.md` — 完整设计文档
- `SKILL-CALL-CONFIRMATION.md` — 调用确认机制
- `SKILL-EXECUTION-VERIFICATION.md` — 验证机制设计
- `DEPLOYMENT-STRATEGY.md` — 部署策略
- `PROJECT-STATUS.md` — 项目状态

## 故障排除

### 问题：监控脚本找不到

**解决方案**：确保脚本已复制到 `~/.config/opencode/skills/skill-monitoring/scripts/`

```bash
ls -la ~/.config/opencode/skills/skill-monitoring/scripts/
```

### 问题：执行 ID 生成失败

**解决方案**：检查 `~/.opencode/` 目录是否存在

```bash
mkdir -p ~/.opencode/skill-executions
```

### 问题：路由返回空结果

**解决方案**：检查 `skills-matrix.json` 是否存在

```bash
ls -la ~/.config/opencode/skills/skill-monitoring/data/skills-matrix.json
```

### 问题：性能分析无数据

**解决方案**：确保有执行记录

```bash
ls -la ~/.opencode/skill-executions/
```

## 支持

如有问题，请查看：
- 项目文档：`~/.config/opencode/skills/skill-monitoring/docs/`
- 测试报告：`~/.config/opencode/skills/skill-monitoring/tools/test-report.json`
- 执行日志：`~/.opencode/skill-executions/{execution_id}/`

## 版本

- **版本**：1.0.0
- **发布日期**：2026-06-17
- **状态**：生产就绪（已通过全面测试）

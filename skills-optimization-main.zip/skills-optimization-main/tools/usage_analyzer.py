#!/usr/bin/env python3
"""
Skill 执行成功率追踪和分析工具

追踪 Skill 执行性能、成功率、平均耗时等指标。
"""

import json
import os
from pathlib import Path
from typing import Optional, Dict, Any, List
from datetime import datetime, timedelta
from collections import defaultdict
import statistics


class UsageAnalyzer:
    """Skill 使用情况分析工具"""
    
    def __init__(self, executions_dir: Optional[str] = None):
        """
        初始化分析工具
        
        Args:
            executions_dir: 执行目录路径
        """
        if executions_dir is None:
            executions_dir = str(Path.home() / ".opencode" / "skill-executions")
        
        self.executions_dir = Path(executions_dir)
        self.executions_dir.mkdir(parents=True, exist_ok=True)
    
    def analyze_all(self) -> Dict[str, Any]:
        """分析所有执行"""
        executions = self._load_all_executions()
        
        if not executions:
            return {
                "status": "no_data",
                "message": "No executions found",
                "timestamp": datetime.now().isoformat()
            }
        
        # 计算统计信息
        stats = self._calculate_stats(executions)
        
        # 按 Skill 分组
        by_skill = self._group_by_skill(executions)
        
        # 计算趋势
        trends = self._calculate_trends(executions)
        
        return {
            "status": "success",
            "summary": {
                "total_executions": len(executions),
                "success_rate": stats["success_rate"],
                "average_duration": stats["average_duration"],
                "total_duration": stats["total_duration"],
                "error_count": stats["error_count"],
                "success_count": stats["success_count"]
            },
            "by_skill": by_skill,
            "trends": trends,
            "timestamp": datetime.now().isoformat()
        }
    
    def analyze_skill(self, skill_name: str) -> Dict[str, Any]:
        """分析特定 Skill 的执行"""
        executions = self._load_all_executions()
        
        # 过滤特定 Skill 的执行
        skill_executions = [
            e for e in executions
            if e.get("skill_name") == skill_name
        ]
        
        if not skill_executions:
            return {
                "status": "no_data",
                "skill_name": skill_name,
                "message": f"No executions found for skill: {skill_name}",
                "timestamp": datetime.now().isoformat()
            }
        
        # 计算统计信息
        stats = self._calculate_stats(skill_executions)
        
        # 获取最近的执行
        recent = sorted(
            skill_executions,
            key=lambda x: x.get("timestamp", ""),
            reverse=True
        )[:5]
        
        return {
            "status": "success",
            "skill_name": skill_name,
            "statistics": {
                "total_executions": len(skill_executions),
                "success_rate": stats["success_rate"],
                "average_duration": stats["average_duration"],
                "error_count": stats["error_count"],
                "success_count": stats["success_count"]
            },
            "recent_executions": recent,
            "timestamp": datetime.now().isoformat()
        }
    
    def analyze_time_range(self, hours: int = 24) -> Dict[str, Any]:
        """分析指定时间范围内的执行"""
        executions = self._load_all_executions()
        
        # 计算时间范围
        cutoff_time = datetime.now() - timedelta(hours=hours)
        
        # 过滤时间范围内的执行
        filtered = [
            e for e in executions
            if self._parse_timestamp(e.get("timestamp", "")) >= cutoff_time
        ]
        
        if not filtered:
            return {
                "status": "no_data",
                "hours": hours,
                "message": f"No executions in the last {hours} hours",
                "timestamp": datetime.now().isoformat()
            }
        
        # 计算统计信息
        stats = self._calculate_stats(filtered)
        
        # 按小时分组
        by_hour = self._group_by_hour(filtered)
        
        return {
            "status": "success",
            "time_range": f"Last {hours} hours",
            "summary": {
                "total_executions": len(filtered),
                "success_rate": stats["success_rate"],
                "average_duration": stats["average_duration"],
                "error_count": stats["error_count"],
                "success_count": stats["success_count"]
            },
            "by_hour": by_hour,
            "timestamp": datetime.now().isoformat()
        }
    
    def get_success_rate(self) -> Dict[str, Any]:
        """获取成功率"""
        executions = self._load_all_executions()
        
        if not executions:
            return {
                "status": "no_data",
                "success_rate": 0.0,
                "timestamp": datetime.now().isoformat()
            }
        
        success_count = sum(1 for e in executions if e.get("status") == "success")
        success_rate = (success_count / len(executions)) * 100
        
        return {
            "status": "success",
            "success_rate": round(success_rate, 2),
            "success_count": success_count,
            "total_count": len(executions),
            "timestamp": datetime.now().isoformat()
        }
    
    def get_error_report(self) -> Dict[str, Any]:
        """获取错误报告"""
        executions = self._load_all_executions()
        
        # 过滤失败的执行
        errors = [e for e in executions if e.get("status") != "success"]
        
        if not errors:
            return {
                "status": "success",
                "error_count": 0,
                "errors": [],
                "timestamp": datetime.now().isoformat()
            }
        
        # 按错误类型分组
        by_error_type = defaultdict(list)
        for error in errors:
            error_type = error.get("error_type", "unknown")
            by_error_type[error_type].append(error)
        
        return {
            "status": "success",
            "error_count": len(errors),
            "by_error_type": {
                error_type: {
                    "count": len(execs),
                    "recent": execs[-1]
                }
                for error_type, execs in by_error_type.items()
            },
            "timestamp": datetime.now().isoformat()
        }
    
    def get_performance_report(self) -> Dict[str, Any]:
        """获取性能报告"""
        executions = self._load_all_executions()
        
        if not executions:
            return {
                "status": "no_data",
                "timestamp": datetime.now().isoformat()
            }
        
        # 计算耗时统计
        durations = [
            e.get("duration", 0) for e in executions
            if e.get("duration") is not None
        ]
        
        if not durations:
            return {
                "status": "no_duration_data",
                "timestamp": datetime.now().isoformat()
            }
        
        return {
            "status": "success",
            "performance": {
                "min_duration": min(durations),
                "max_duration": max(durations),
                "average_duration": statistics.mean(durations),
                "median_duration": statistics.median(durations),
                "std_dev": statistics.stdev(durations) if len(durations) > 1 else 0
            },
            "timestamp": datetime.now().isoformat()
        }
    
    def _load_all_executions(self) -> List[Dict[str, Any]]:
        """加载所有执行"""
        executions = []
        
        if not self.executions_dir.exists():
            return executions
        
        for exec_dir in self.executions_dir.iterdir():
            if not exec_dir.is_dir():
                continue
            
            # 尝试加载执行报告
            report_file = exec_dir / "execution-report.json"
            if report_file.exists():
                try:
                    with open(report_file) as f:
                        report = json.load(f)
                    report["execution_id"] = exec_dir.name
                    executions.append(report)
                except Exception:
                    pass
        
        return executions
    
    def _calculate_stats(self, executions: List[Dict[str, Any]]) -> Dict[str, Any]:
        """计算统计信息"""
        if not executions:
            return {
                "success_rate": 0.0,
                "average_duration": 0.0,
                "total_duration": 0.0,
                "error_count": 0,
                "success_count": 0
            }
        
        success_count = sum(1 for e in executions if e.get("status") == "success")
        error_count = len(executions) - success_count
        
        durations = [
            e.get("duration", 0) for e in executions
            if e.get("duration") is not None
        ]
        
        average_duration = statistics.mean(durations) if durations else 0.0
        total_duration = sum(durations) if durations else 0.0
        
        return {
            "success_rate": round((success_count / len(executions)) * 100, 2),
            "average_duration": round(average_duration, 2),
            "total_duration": round(total_duration, 2),
            "error_count": error_count,
            "success_count": success_count
        }
    
    def _group_by_skill(self, executions: List[Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
        """按 Skill 分组"""
        by_skill = defaultdict(list)
        
        for execution in executions:
            skill_name = execution.get("skill_name", "unknown")
            by_skill[skill_name].append(execution)
        
        result = {}
        for skill_name, skill_execs in by_skill.items():
            stats = self._calculate_stats(skill_execs)
            result[skill_name] = {
                "count": len(skill_execs),
                **stats
            }
        
        return result
    
    def _group_by_hour(self, executions: List[Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
        """按小时分组"""
        by_hour = defaultdict(list)
        
        for execution in executions:
            timestamp = self._parse_timestamp(execution.get("timestamp", ""))
            hour_key = timestamp.strftime("%Y-%m-%d %H:00")
            by_hour[hour_key].append(execution)
        
        result = {}
        for hour_key in sorted(by_hour.keys()):
            execs = by_hour[hour_key]
            stats = self._calculate_stats(execs)
            result[hour_key] = {
                "count": len(execs),
                **stats
            }
        
        return result
    
    def _calculate_trends(self, executions: List[Dict[str, Any]]) -> Dict[str, Any]:
        """计算趋势"""
        if len(executions) < 2:
            return {}
        
        # 按时间排序
        sorted_execs = sorted(
            executions,
            key=lambda x: self._parse_timestamp(x.get("timestamp", ""))
        )
        
        # 计算最近 24 小时的趋势
        cutoff_time = datetime.now() - timedelta(hours=24)
        recent = [
            e for e in sorted_execs
            if self._parse_timestamp(e.get("timestamp", "")) >= cutoff_time
        ]
        
        if not recent:
            return {}
        
        # 计算成功率变化
        recent_stats = self._calculate_stats(recent)
        all_stats = self._calculate_stats(sorted_execs)
        
        return {
            "recent_24h_success_rate": recent_stats["success_rate"],
            "overall_success_rate": all_stats["success_rate"],
            "trend": "improving" if recent_stats["success_rate"] > all_stats["success_rate"] else "declining"
        }
    
    def _parse_timestamp(self, timestamp_str: str) -> datetime:
        """解析时间戳"""
        try:
            return datetime.fromisoformat(timestamp_str)
        except Exception:
            return datetime.now()


# 便捷函数
def analyze_all() -> Dict[str, Any]:
    """分析所有执行"""
    analyzer = UsageAnalyzer()
    return analyzer.analyze_all()


def analyze_skill(skill_name: str) -> Dict[str, Any]:
    """分析特定 Skill"""
    analyzer = UsageAnalyzer()
    return analyzer.analyze_skill(skill_name)


def get_success_rate() -> Dict[str, Any]:
    """获取成功率"""
    analyzer = UsageAnalyzer()
    return analyzer.get_success_rate()


def get_error_report() -> Dict[str, Any]:
    """获取错误报告"""
    analyzer = UsageAnalyzer()
    return analyzer.get_error_report()


def get_performance_report() -> Dict[str, Any]:
    """获取性能报告"""
    analyzer = UsageAnalyzer()
    return analyzer.get_performance_report()


if __name__ == "__main__":
    # 测试脚本
    analyzer = UsageAnalyzer()
    
    print("=" * 60)
    print("Skill 执行成功率追踪和分析")
    print("=" * 60)
    
    # 分析所有执行
    print("\n📊 全体分析:")
    result = analyzer.analyze_all()
    if result["status"] == "success":
        print(f"  总执行数: {result['summary']['total_executions']}")
        print(f"  成功率: {result['summary']['success_rate']}%")
        print(f"  平均耗时: {result['summary']['average_duration']}s")
    else:
        print(f"  {result['message']}")
    
    # 获取成功率
    print("\n📈 成功率:")
    result = analyzer.get_success_rate()
    if result["status"] == "success":
        print(f"  成功率: {result['success_rate']}%")
        print(f"  成功: {result['success_count']}/{result['total_count']}")
    else:
        print(f"  {result['message']}")
    
    # 获取错误报告
    print("\n❌ 错误报告:")
    result = analyzer.get_error_report()
    if result["error_count"] > 0:
        print(f"  错误数: {result['error_count']}")
    else:
        print("  无错误")
    
    # 获取性能报告
    print("\n⚡ 性能报告:")
    result = analyzer.get_performance_report()
    if result["status"] == "success":
        perf = result["performance"]
        print(f"  平均耗时: {perf['average_duration']}s")
        print(f"  最小耗时: {perf['min_duration']}s")
        print(f"  最大耗时: {perf['max_duration']}s")
    else:
        print(f"  {result['message']}")
    
    print("\n✅ 分析工具已就绪")

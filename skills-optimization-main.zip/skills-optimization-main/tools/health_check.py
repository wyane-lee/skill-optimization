#!/usr/bin/env python3
"""
Skill 健康检查工具
用于验证 Skill 的可用性和配置
"""

import json
import os
from pathlib import Path
from typing import Dict, List


class HealthChecker:
    """检查 Skill 的健康状态"""
    
    def __init__(self, skills_dir: str = None):
        """初始化检查器"""
        if skills_dir is None:
            skills_dir = os.path.expanduser("~/.config/opencode/skills")
        self.skills_dir = Path(skills_dir)
    
    def check_all_skills(self) -> Dict[str, Dict]:
        """检查所有 Skill"""
        results = {}
        
        for skill_path in self.skills_dir.iterdir():
            if skill_path.is_dir() and skill_path.name != "skills-optimization":
                skill_name = skill_path.name
                results[skill_name] = self.check_skill(skill_name)
        
        return results
    
    def check_skill(self, skill_name: str) -> Dict:
        """检查单个 Skill"""
        skill_path = self.skills_dir / skill_name
        
        if not skill_path.exists():
            return {
                "status": "missing",
                "issues": ["Skill 目录不存在"]
            }
        
        issues = []
        
        # 检查 SKILL.md
        if not (skill_path / "SKILL.md").exists():
            issues.append("缺失 SKILL.md")
        
        # 检查 README.md
        if not (skill_path / "README.md").exists():
            issues.append("缺失 README.md")
        
        # 检查脚本权限
        for script in skill_path.glob("scripts/*.sh"):
            if not os.access(script, os.X_OK):
                issues.append(f"脚本 {script.name} 没有执行权限")
        
        status = "healthy" if not issues else "warning"
        
        return {
            "status": status,
            "issues": issues,
            "path": str(skill_path)
        }
    
    def is_healthy(self, skill_name: str) -> bool:
        """检查 Skill 是否健康"""
        result = self.check_skill(skill_name)
        return result["status"] == "healthy"
    
    def get_issues(self, skill_name: str) -> List[str]:
        """获取 Skill 的问题列表"""
        result = self.check_skill(skill_name)
        return result.get("issues", [])


if __name__ == "__main__":
    checker = HealthChecker()
    results = checker.check_all_skills()
    
    print("🏥 Skill 健康检查结果:")
    print("")
    
    healthy_count = 0
    warning_count = 0
    
    for skill_name, status in sorted(results.items()):
        if status["status"] == "healthy":
            print(f"  ✅ {skill_name}")
            healthy_count += 1
        else:
            print(f"  ⚠️  {skill_name}")
            for issue in status["issues"]:
                print(f"     - {issue}")
            warning_count += 1
    
    print("")
    print(f"总计: {healthy_count} 个健康, {warning_count} 个警告")

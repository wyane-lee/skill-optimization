#!/usr/bin/env python3
"""
Skill 执行监控模块测试套件

测试覆盖：
- 监控功能（日志记录、分析）
- 报告生成
- 性能分析
- 辅助方法
"""

import sys
import json
import tempfile
from pathlib import Path
from datetime import datetime, timedelta

# 添加 tools 目录到 Python 路径
sys.path.insert(0, str(Path(__file__).parent))

from skill_execution_monitor import SkillExecutionMonitor


class TestSkillExecutionMonitor:
    """测试 SkillExecutionMonitor"""
    
    def __init__(self):
        self.monitor = SkillExecutionMonitor()
        self.test_results = {
            "passed": 0,
            "failed": 0,
            "tests": []
        }
    
    def run_all_tests(self):
        """运行所有测试"""
        print("=" * 70)
        print("Skill 执行监控模块 - 测试套件")
        print("=" * 70)
        print()
        
        # 监控功能测试
        self.test_monitor_execution()
        self.test_log_analysis()
        
        # 报告生成测试
        self.test_generate_report()
        
        # 性能分析测试
        self.test_analyze_performance()
        self.test_filter_by_time_range()
        self.test_calculate_performance_metrics()
        
        # 辅助方法测试
        self.test_list_executions()
        self.test_get_execution_status()
        
        # 打印结果
        self.print_results()
    
    # ==================== 监控功能测试 ====================
    
    def test_monitor_execution(self):
        """测试监控执行"""
        test_name = "test_monitor_execution"
        try:
            log_content = """
            2026-06-17 10:00:00 - Starting skill execution
            2026-06-17 10:00:01 - Processing data
            2026-06-17 10:00:02 - ✅ Success: Operation completed
            """
            
            result = self.monitor.monitor_execution(
                skill_name="test-skill",
                execution_id="exec_test_001",
                log_content=log_content,
                metadata={"duration": 2.5}
            )
            
            assert result["status"] == "success", f"Expected success, got {result['status']}"
            assert "log_file" in result, "Missing log_file in result"
            assert "metadata_file" in result, "Missing metadata_file in result"
            
            self._pass_test(test_name)
        except Exception as e:
            self._fail_test(test_name, str(e))
    
    def test_log_analysis(self):
        """测试日志分析"""
        test_name = "test_log_analysis"
        try:
            log_content = """
            Error: Something went wrong
            Warning: Check this value
            Success: Operation completed
            """
            
            analysis = self.monitor._analyze_log(log_content)
            
            assert analysis["has_errors"] == True, "Should detect errors"
            assert analysis["has_warnings"] == True, "Should detect warnings"
            assert analysis["has_success"] == True, "Should detect success"
            assert analysis["error_count"] == 1, "Should count 1 error"
            assert analysis["warning_count"] == 1, "Should count 1 warning"
            
            self._pass_test(test_name)
        except Exception as e:
            self._fail_test(test_name, str(e))
    
    # ==================== 报告生成测试 ====================
    
    def test_generate_report(self):
        """测试报告生成"""
        test_name = "test_generate_report"
        try:
            # 先创建一个执行
            log_content = "✅ Success: Test completed"
            self.monitor.monitor_execution(
                skill_name="test-skill-2",
                execution_id="exec_test_002",
                log_content=log_content
            )
            
            # 生成报告
            result = self.monitor.generate_report(
                execution_id="exec_test_002",
                skill_name="test-skill-2"
            )
            
            assert result["status"] == "success", f"Expected success, got {result['status']}"
            assert "report_file" in result, "Missing report_file in result"
            assert "report" in result, "Missing report in result"
            
            self._pass_test(test_name)
        except Exception as e:
            self._fail_test(test_name, str(e))
    
    # ==================== 性能分析测试 ====================
    
    def test_analyze_performance(self):
        """测试性能分析"""
        test_name = "test_analyze_performance"
        try:
            # 创建多个执行
            for i in range(3):
                log_content = f"✅ Success: Execution {i}"
                self.monitor.monitor_execution(
                    skill_name="test-skill-3",
                    execution_id=f"exec_test_003_{i}",
                    log_content=log_content
                )
            
            # 分析性能
            result = self.monitor.analyze_performance(skill_name="test-skill-3")
            
            assert result["status"] == "success", f"Expected success, got {result['status']}"
            assert "performance_metrics" in result, "Missing performance_metrics"
            
            metrics = result["performance_metrics"]
            assert metrics["total_executions"] == 3, "Should have 3 executions"
            assert metrics["success_rate"] == 100.0, "Should have 100% success rate"
            
            self._pass_test(test_name)
        except Exception as e:
            self._fail_test(test_name, str(e))
    
    def test_filter_by_time_range(self):
        """测试时间范围过滤"""
        test_name = "test_filter_by_time_range"
        try:
            # 创建执行数据
            executions = [
                {"timestamp": (datetime.now() - timedelta(hours=1)).isoformat()},
                {"timestamp": (datetime.now() - timedelta(hours=25)).isoformat()},
                {"timestamp": (datetime.now() - timedelta(days=8)).isoformat()},
            ]
            
            # 过滤 24 小时内的
            filtered = self.monitor._filter_by_time_range(executions, "24h")
            assert len(filtered) == 1, f"Expected 1 execution in 24h, got {len(filtered)}"
            
            # 过滤 7 天内的
            filtered = self.monitor._filter_by_time_range(executions, "7d")
            assert len(filtered) == 2, f"Expected 2 executions in 7d, got {len(filtered)}"
            
            self._pass_test(test_name)
        except Exception as e:
            self._fail_test(test_name, str(e))
    
    def test_calculate_performance_metrics(self):
        """测试性能指标计算"""
        test_name = "test_calculate_performance_metrics"
        try:
            executions = [
                {
                    "log_analysis": {
                        "has_errors": False,
                        "has_success": True,
                        "warning_count": 0,
                        "total_lines": 10
                    }
                },
                {
                    "log_analysis": {
                        "has_errors": True,
                        "has_success": False,
                        "warning_count": 1,
                        "total_lines": 15
                    }
                },
                {
                    "log_analysis": {
                        "has_errors": False,
                        "has_success": True,
                        "warning_count": 0,
                        "total_lines": 12
                    }
                }
            ]
            
            metrics = self.monitor._calculate_performance_metrics(executions)
            
            assert metrics["total_executions"] == 3, "Should have 3 executions"
            assert metrics["success_count"] == 2, "Should have 2 successes"
            assert metrics["error_count"] == 1, "Should have 1 error"
            assert metrics["success_rate"] == 66.67, f"Expected 66.67% success rate, got {metrics['success_rate']}"
            assert metrics["total_warnings"] == 1, "Should have 1 warning"
            
            self._pass_test(test_name)
        except Exception as e:
            self._fail_test(test_name, str(e))
    
    # ==================== 辅助方法测试 ====================
    
    def test_list_executions(self):
        """测试列出执行"""
        test_name = "test_list_executions"
        try:
            # 创建执行
            for i in range(2):
                log_content = f"✅ Success: Execution {i}"
                self.monitor.monitor_execution(
                    skill_name="test-skill-4",
                    execution_id=f"exec_test_004_{i}",
                    log_content=log_content
                )
            
            # 列出执行
            result = self.monitor.list_executions(skill_name="test-skill-4")
            
            assert result["status"] == "success", f"Expected success, got {result['status']}"
            assert result["total_executions"] >= 2, "Should have at least 2 executions"
            
            self._pass_test(test_name)
        except Exception as e:
            self._fail_test(test_name, str(e))
    
    def test_get_execution_status(self):
        """测试获取执行状态"""
        test_name = "test_get_execution_status"
        try:
            # 创建执行
            log_content = "✅ Success: Test completed"
            self.monitor.monitor_execution(
                skill_name="test-skill-5",
                execution_id="exec_test_005",
                log_content=log_content
            )
            
            # 获取状态
            result = self.monitor.get_execution_status(
                execution_id="exec_test_005",
                skill_name="test-skill-5"
            )
            
            assert result["status"] == "found", f"Expected found, got {result['status']}"
            assert "data" in result, "Missing data in result"
            
            self._pass_test(test_name)
        except Exception as e:
            self._fail_test(test_name, str(e))
    
    # ==================== 辅助方法 ====================
    
    def _pass_test(self, test_name: str):
        """记录通过的测试"""
        self.test_results["passed"] += 1
        self.test_results["tests"].append({
            "name": test_name,
            "status": "✅ PASS"
        })
        print(f"✅ {test_name}")
    
    def _fail_test(self, test_name: str, error: str):
        """记录失败的测试"""
        self.test_results["failed"] += 1
        self.test_results["tests"].append({
            "name": test_name,
            "status": "❌ FAIL",
            "error": error
        })
        print(f"❌ {test_name}: {error}")
    
    def print_results(self):
        """打印测试结果"""
        print()
        print("=" * 70)
        print("测试结果")
        print("=" * 70)
        
        total = self.test_results["passed"] + self.test_results["failed"]
        passed = self.test_results["passed"]
        failed = self.test_results["failed"]
        success_rate = (passed / total * 100) if total > 0 else 0
        
        print(f"总测试数: {total}")
        print(f"通过: {passed}")
        print(f"失败: {failed}")
        print(f"成功率: {success_rate:.2f}%")
        print()
        
        if failed == 0:
            print("🎉 所有测试通过！")
        else:
            print(f"⚠️  有 {failed} 个测试失败")
        
        print()


if __name__ == "__main__":
    tester = TestSkillExecutionMonitor()
    tester.run_all_tests()

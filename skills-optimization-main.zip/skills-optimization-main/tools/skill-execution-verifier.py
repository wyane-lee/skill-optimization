#!/usr/bin/env python3
"""
Skill 执行验证框架
确保 Agent 调用的 Skill 真正执行且产生预期结果
"""
import json
import time
import hashlib
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Any, Optional

class SkillExecutionVerifier:
    """Skill 执行验证器"""
    
    def __init__(self, skill_name: str, execution_id: Optional[str] = None):
        self.skill_name = skill_name
        self.execution_id = execution_id or self._generate_execution_id()
        self.start_time = time.time()
        self.events: List[Dict] = []
        self.state = "initializing"
        self.execution_dir = Path.home() / ".opencode" / "skill-executions" / self.execution_id
        self.execution_dir.mkdir(parents=True, exist_ok=True)
    
    def _generate_execution_id(self) -> str:
        """生成唯一的执行 ID"""
        timestamp = datetime.now().isoformat()
        hash_input = f"{self.skill_name}_{timestamp}".encode()
        hash_hex = hashlib.md5(hash_input).hexdigest()[:8]
        return f"exec_{self.skill_name}_{hash_hex}"
    
    def log_event(self, event_type: str, details: Optional[Dict] = None) -> None:
        """记录执行事件"""
        event = {
            "timestamp": datetime.now().isoformat(),
            "elapsed_seconds": time.time() - self.start_time,
            "type": event_type,
            "details": details or {},
        }
        self.events.append(event)
        
        # 实时写入日志
        self._write_log_file()
    
    def _write_log_file(self) -> None:
        """写入执行日志文件"""
        log_file = self.execution_dir / "execution.log"
        with open(str(log_file), "w") as f:
            for event in self.events:
                f.write(f"[{event['timestamp']}] {event['type']}: {json.dumps(event['details'])}\n")
    
    def verify_preconditions(self, checks: Dict[str, bool]) -> bool:
        """验证前置条件"""
        self.log_event("precondition_check", checks)
        
        if not all(checks.values()):
            failed = [k for k, v in checks.items() if not v]
            self.log_event("precondition_failed", {"failed_checks": failed})
            return False
        
        self.log_event("preconditions_passed")
        return True
    
    def verify_tool_execution(self, tool_name: str, tool_args: Dict, tool_result: str) -> Dict[str, Any]:
        """验证工具是否真的执行了"""
        
        checks = {
            "result_exists": tool_result is not None and tool_result != "",
            "result_not_error": "error" not in tool_result.lower() and "failed" not in tool_result.lower(),
            "result_length": len(tool_result) > 0,
        }
        
        # 特定工具的检查
        if tool_name == "bash":
            checks["no_nonzero_exit"] = "exit code" not in tool_result or "non-zero" not in tool_result
        
        if tool_name == "read":
            checks["result_length"] = len(tool_result) > 10  # 文件内容应该有一定长度
        
        verification = {
            "tool": tool_name,
            "executed": all(checks.values()),
            "checks": checks,
            "result_preview": tool_result[:100] if tool_result else "",
        }
        
        self.log_event("tool_execution", verification)
        
        return verification
    
    def verify_output(self, output: Any, expected_type: Optional[type] = None, required_fields: Optional[List[str]] = None) -> Dict[str, Any]:
        """验证输出"""
        
        checks = {
            "output_exists": output is not None,
            "output_not_empty": len(str(output)) > 0,
        }
        
        if expected_type:
            checks["output_type_correct"] = isinstance(output, expected_type)
        
        if required_fields:
            if isinstance(output, dict):
                checks["required_fields_present"] = all(f in output for f in required_fields)
            else:
                checks["required_fields_present"] = False
        
        verification = {
            "output_valid": all(checks.values()),
            "checks": checks,
            "output_preview": str(output)[:100] if output else "",
        }
        
        self.log_event("output_verification", verification)
        
        return verification
    
    def verify_side_effects(self, expected_files: Optional[List[str]] = None, expected_api_calls: Optional[List[str]] = None) -> Dict[str, Any]:
        """验证副作用（文件创建、API 调用等）"""
        
        effects = {
            "files_created": [],
            "api_calls_made": [],
        }
        
        # 检查文件创建
        if expected_files:
            for file_path in expected_files:
                if Path(file_path).exists():
                    effects["files_created"].append(file_path)
        
        # 检查 API 调用（从日志）
        if expected_api_calls:
            # 这里可以检查网络日志或 API 调用日志
            effects["api_calls_made"] = expected_api_calls  # 简化版本
        
        verification = {
            "side_effects_verified": len(effects["files_created"]) == len(expected_files or []),
            "effects": effects,
        }
        
        self.log_event("side_effects_verification", verification)
        
        return verification
    
    def get_execution_report(self) -> Dict[str, Any]:
        """生成执行报告"""
        
        elapsed = time.time() - self.start_time
        
        # 统计各类事件
        event_counts = {}
        for event in self.events:
            event_type = event["type"]
            event_counts[event_type] = event_counts.get(event_type, 0) + 1
        
        # 检查是否有失败
        has_failures = any("failed" in e["type"] for e in self.events)
        
        report = {
            "execution_id": self.execution_id,
            "skill_name": self.skill_name,
            "status": "failed" if has_failures else "success",
            "start_time": datetime.fromtimestamp(self.start_time).isoformat(),
            "elapsed_seconds": elapsed,
            "event_counts": event_counts,
            "total_events": len(self.events),
            "events": self.events,
        }
        
        # 保存报告
        report_file = self.execution_dir / "execution-report.json"
        with open(report_file, "w") as f:
            json.dump(report, f, indent=2, ensure_ascii=False)
        
        return report
    
    def save_artifacts(self, artifacts: Dict[str, Any]) -> None:
        """保存执行产物"""
        artifacts_dir = self.execution_dir / "artifacts"
        artifacts_dir.mkdir(exist_ok=True)
        
        for name, content in artifacts.items():
            artifact_file = artifacts_dir / name
            if isinstance(content, (dict, list)):
                artifact_file.write_text(json.dumps(content, indent=2, ensure_ascii=False))
            else:
                artifact_file.write_text(str(content))
        
        self.log_event("artifacts_saved", {"count": len(artifacts)})


class SkillExecutionValidator:
    """Skill 执行验证器 - 高级 API"""
    
    @staticmethod
    def validate_skill_call(
        skill_name: str,
        user_request: str,
        preconditions: Dict[str, bool],
        tool_calls: List[Dict],
        output: Any,
        expected_output_type: Optional[type] = None,
        required_fields: Optional[List[str]] = None,
        expected_files: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """验证完整的 Skill 调用"""
        
        verifier = SkillExecutionVerifier(skill_name)
        
        # 1. 验证前置条件
        verifier.log_event("started", {"request": user_request})
        
        if not verifier.verify_preconditions(preconditions):
            return {
                "status": "failed",
                "reason": "preconditions_not_met",
                "execution_id": verifier.execution_id,
                "report": verifier.get_execution_report(),
            }
        
        # 2. 验证工具执行
        all_tools_verified = True
        for tool_call in tool_calls:
            verification = verifier.verify_tool_execution(
                tool_call["name"],
                tool_call.get("args", {}),
                tool_call.get("result", ""),
            )
            if not verification["executed"]:
                all_tools_verified = False
        
        if not all_tools_verified:
            return {
                "status": "failed",
                "reason": "tool_execution_failed",
                "execution_id": verifier.execution_id,
                "report": verifier.get_execution_report(),
            }
        
        # 3. 验证输出
        output_verification = verifier.verify_output(output, expected_output_type, required_fields)
        if not output_verification["output_valid"]:
            return {
                "status": "failed",
                "reason": "output_invalid",
                "execution_id": verifier.execution_id,
                "report": verifier.get_execution_report(),
            }
        
        # 4. 验证副作用
        if expected_files:
            verifier.verify_side_effects(expected_files=expected_files)
        
        # 5. 生成最终报告
        verifier.log_event("completed", {"status": "success"})
        report = verifier.get_execution_report()
        
        return {
            "status": "success",
            "execution_id": verifier.execution_id,
            "report": report,
            "verification": {
                "preconditions": True,
                "tools_executed": all_tools_verified,
                "output_valid": output_verification["output_valid"],
            },
        }


# 示例使用
if __name__ == "__main__":
    # 模拟 Skill 执行
    result = SkillExecutionValidator.validate_skill_call(
        skill_name="second-brain",
        user_request="搜索关于 ISE 的 Webex 讨论",
        preconditions={
            "skill_available": True,
            "webex_token_valid": True,
            "no_conflicts": True,
        },
        tool_calls=[
            {
                "name": "grep",
                "args": {"pattern": "ISE", "path": "/path/to/webex/data"},
                "result": "Found 42 matches in Webex conversations",
            },
            {
                "name": "read",
                "args": {"filePath": "/path/to/results.json"},
                "result": '{"results": [...], "count": 42}',
            },
        ],
        output={"results": ["ISE discussion 1", "ISE discussion 2"], "count": 42},
        expected_output_type=dict,
        required_fields=["results", "count"],
        expected_files=["/path/to/results.json"],
    )
    
    print(json.dumps(result, indent=2, ensure_ascii=False))
    print(f"\n执行日志保存在: ~/.opencode/skill-executions/{result['execution_id']}/")

#!/usr/bin/env python3
"""
智能 Skill 路由引擎

根据用户意图自动选择最合适的 Skill，使用 TF-IDF + 余弦相似度。
"""

import json
import re
from pathlib import Path
from typing import Optional, Dict, Any, List, Tuple
from dataclasses import dataclass
from datetime import datetime


@dataclass
class SkillMatch:
    """Skill 匹配结果"""
    skill_name: str
    similarity_score: float
    priority: str
    data_sources: List[str]
    actions: List[str]
    description: str


class SkillRouter:
    """智能 Skill 路由引擎"""
    
    def __init__(self, matrix_file: Optional[str] = None):
        """
        初始化路由引擎
        
        Args:
            matrix_file: Skills 矩阵文件路径
        """
        if matrix_file is None:
            matrix_file = str(
                Path.home() / ".config" / "opencode" / "skills" / "skill-monitoring" / 
                "data" / "skills-matrix.json"
            )
        
        self.matrix_file = Path(matrix_file)
        self.skills_matrix = self._load_matrix()
        self.execution_history = []
    
    def _load_matrix(self) -> Dict[str, Any]:
        """加载 Skills 矩阵"""
        if not self.matrix_file.exists():
            return {}
        
        try:
            with open(self.matrix_file) as f:
                return json.load(f)
        except Exception as e:
            print(f"⚠️  Failed to load matrix: {e}")
            return {}
    
    def route(self, user_intent: str, top_k: int = 3) -> List[SkillMatch]:
        """
        根据用户意图路由到最合适的 Skill
        
        Args:
            user_intent: 用户意图（自然语言）
            top_k: 返回的最佳匹配数
        
        Returns:
            匹配的 Skill 列表（按相似度排序）
        """
        if not self.skills_matrix:
            return []
        
        # 提取关键词
        keywords = self._extract_keywords(user_intent)
        
        # 计算相似度
        matches = []
        for skill_name, skill_data in self.skills_matrix.items():
            similarity = self._calculate_similarity(keywords, skill_data)
            
            if similarity > 0.3:  # 相似度阈值
                match = SkillMatch(
                    skill_name=skill_name,
                    similarity_score=similarity,
                    priority=skill_data.get("priority", "standard"),
                    data_sources=skill_data.get("data_sources", []),
                    actions=skill_data.get("actions", []),
                    description=skill_data.get("description", "")
                )
                matches.append(match)
        
        # 按相似度排序
        matches.sort(key=lambda x: x.similarity_score, reverse=True)
        
        # 记录路由决策
        self._record_routing(user_intent, matches[:top_k])
        
        return matches[:top_k]
    
    def route_by_action(self, action: str, top_k: int = 3) -> List[SkillMatch]:
        """
        根据操作类型路由到最合适的 Skill
        
        Args:
            action: 操作类型（如 "search", "create", "monitor"）
            top_k: 返回的最佳匹配数
        
        Returns:
            匹配的 Skill 列表
        """
        if not self.skills_matrix:
            return []
        
        matches = []
        for skill_name, skill_data in self.skills_matrix.items():
            actions = skill_data.get("actions", [])
            
            # 检查操作是否匹配
            if any(action.lower() in a.lower() for a in actions):
                match = SkillMatch(
                    skill_name=skill_name,
                    similarity_score=1.0,
                    priority=skill_data.get("priority", "standard"),
                    data_sources=skill_data.get("data_sources", []),
                    actions=actions,
                    description=skill_data.get("description", "")
                )
                matches.append(match)
        
        # 按优先级排序
        priority_order = {"preferred": 0, "standard": 1, "deprecated": 2}
        matches.sort(
            key=lambda x: (
                priority_order.get(x.priority, 3),
                -x.similarity_score
            )
        )
        
        return matches[:top_k]
    
    def route_by_data_source(self, data_source: str, top_k: int = 3) -> List[SkillMatch]:
        """
        根据数据源路由到最合适的 Skill
        
        Args:
            data_source: 数据源（如 "webex", "github", "salesforce"）
            top_k: 返回的最佳匹配数
        
        Returns:
            匹配的 Skill 列表
        """
        if not self.skills_matrix:
            return []
        
        matches = []
        for skill_name, skill_data in self.skills_matrix.items():
            sources = skill_data.get("data_sources", [])
            
            # 检查数据源是否匹配
            if any(data_source.lower() in s.lower() for s in sources):
                match = SkillMatch(
                    skill_name=skill_name,
                    similarity_score=1.0,
                    priority=skill_data.get("priority", "standard"),
                    data_sources=sources,
                    actions=skill_data.get("actions", []),
                    description=skill_data.get("description", "")
                )
                matches.append(match)
        
        # 按优先级排序
        priority_order = {"preferred": 0, "standard": 1, "deprecated": 2}
        matches.sort(
            key=lambda x: (
                priority_order.get(x.priority, 3),
                -x.similarity_score
            )
        )
        
        return matches[:top_k]
    
    def _extract_keywords(self, text: str) -> List[str]:
        """提取关键词"""
        # 转换为小写
        text = text.lower()
        
        # 移除特殊字符
        text = re.sub(r'[^\w\s]', ' ', text)
        
        # 分割成单词
        words = text.split()
        
        # 过滤停用词
        stopwords = {
            'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for',
            'of', 'with', 'by', 'from', 'is', 'are', 'was', 'were', 'be', 'been',
            'being', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would',
            'could', 'should', 'may', 'might', 'must', 'can', 'this', 'that',
            'these', 'those', 'i', 'you', 'he', 'she', 'it', 'we', 'they'
        }
        
        keywords = [w for w in words if w not in stopwords and len(w) > 2]
        
        return keywords
    
    def _calculate_similarity(self, keywords: List[str], skill_data: Dict[str, Any]) -> float:
        """计算相似度（简化的 TF-IDF + 余弦相似度）"""
        if not keywords:
            return 0.0
        
        # 获取 Skill 的所有文本
        skill_text = " ".join([
            skill_data.get("description", "").lower(),
            " ".join(skill_data.get("data_sources", [])).lower(),
            " ".join(skill_data.get("actions", [])).lower(),
            skill_data.get("name", "").lower()
        ])
        
        # 计算匹配的关键词数
        matched_keywords = sum(1 for kw in keywords if kw in skill_text)
        
        # 计算相似度（0-1）
        similarity = matched_keywords / len(keywords) if keywords else 0.0
        
        return similarity
    
    def _record_routing(self, user_intent: str, matches: List[SkillMatch]) -> None:
        """记录路由决策"""
        self.execution_history.append({
            "timestamp": datetime.now().isoformat(),
            "user_intent": user_intent,
            "matches": [
                {
                    "skill_name": m.skill_name,
                    "similarity_score": m.similarity_score,
                    "priority": m.priority
                }
                for m in matches
            ]
        })
    
    def get_routing_history(self, limit: int = 10) -> List[Dict[str, Any]]:
        """获取路由历史"""
        return self.execution_history[-limit:]
    
    def get_skill_info(self, skill_name: str) -> Optional[Dict[str, Any]]:
        """获取 Skill 信息"""
        return self.skills_matrix.get(skill_name)
    
    def list_all_skills(self) -> List[str]:
        """列出所有 Skill"""
        return list(self.skills_matrix.keys())
    
    def get_skills_by_priority(self, priority: str) -> List[str]:
        """按优先级获取 Skill"""
        return [
            name for name, data in self.skills_matrix.items()
            if data.get("priority") == priority
        ]


# 便捷函数
def route_intent(user_intent: str, top_k: int = 3) -> List[Dict[str, Any]]:
    """根据用户意图路由"""
    router = SkillRouter()
    matches = router.route(user_intent, top_k)
    return [
        {
            "skill_name": m.skill_name,
            "similarity_score": m.similarity_score,
            "priority": m.priority,
            "description": m.description
        }
        for m in matches
    ]


def route_action(action: str, top_k: int = 3) -> List[Dict[str, Any]]:
    """根据操作类型路由"""
    router = SkillRouter()
    matches = router.route_by_action(action, top_k)
    return [
        {
            "skill_name": m.skill_name,
            "priority": m.priority,
            "actions": m.actions
        }
        for m in matches
    ]


def route_data_source(data_source: str, top_k: int = 3) -> List[Dict[str, Any]]:
    """根据数据源路由"""
    router = SkillRouter()
    matches = router.route_by_data_source(data_source, top_k)
    return [
        {
            "skill_name": m.skill_name,
            "priority": m.priority,
            "data_sources": m.data_sources
        }
        for m in matches
    ]


if __name__ == "__main__":
    # 测试脚本
    router = SkillRouter()
    
    print("=" * 60)
    print("智能 Skill 路由引擎")
    print("=" * 60)
    
    # 测试意图路由
    test_intents = [
        "我想监控 Skill 的执行",
        "搜索 Webex 消息",
        "创建一个新的 GitHub 仓库",
        "查询 Salesforce 数据"
    ]
    
    print("\n📍 意图路由测试:")
    for intent in test_intents:
        print(f"\n  用户意图: {intent}")
        matches = router.route(intent, top_k=2)
        for match in matches:
            print(f"    ✅ {match.skill_name} (相似度: {match.similarity_score:.2f})")
    
    # 测试操作路由
    print("\n\n📍 操作路由测试:")
    test_actions = ["search", "create", "monitor"]
    for action in test_actions:
        print(f"\n  操作: {action}")
        matches = router.route_by_action(action, top_k=2)
        for match in matches:
            print(f"    ✅ {match.skill_name}")
    
    print("\n✅ 路由引擎已就绪")

#!/usr/bin/env python3
"""
Skill 执行监控、报告生成、性能分析一体化模块

功能：
- 监控 Skill 执行日志
- 生成执行报告
- 分析性能指标（成功率、耗时、错误率等）

用途：
- Phase D 自动化工具的核心模块
- 支持新安装 Skill 的执行验证
- 提供性能基线和趋势分析
"""

import json
import os
import re
from pathlib import Path
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple
from collections import defaultdict
import statistics


class SkillExecutionMonitor:
    """Skill 执行监控和性能分析"""
    
    def __init__(self):
        """初始化监控系统"""
        self.base_dir = Path.home() / "Documents" / "claude_projects" / "skills-optimization"
        self.executions_dir = self.base_dir / "data" / "executions"
        self.reports_dir = self.base_dir / "reports" / "performance"
        self.executions_dir.mkdir(parents=True, exist_ok=True)
        self.reports_dir.mkdir(parents=True, exist_ok=True)
    
    # ==================== 监控功能 ====================
    
    def monitor_execution(self, skill_name: str, execution_id: str, 
                         log_content: str, metadata: Optional[Dict] = None) -> Dict[str, Any]:
        """
        监控 Skill 执行日志
        
        Args:
            skill_name: Skill 名称
            execution_id: 执行 ID
            log_content: 执行日志内容
            metadata: 额外元数据（如开始时间、结束时间等）
        
        Returns:
            监控结果字典
        """
        try:
            # 创建执行目录
            exec_dir = self.executions_dir / skill_name / execution_id
            exec_dir.mkdir(parents=True, exist_ok=True)
            
            # 保存日志
            log_file = exec_dir / "execution.log"
            log_file.write_text(log_content, encoding='utf-8')
            
            # 解析日志
            log_analysis = self._analyze_log(log_content)
            
            # 保存元数据
            execution_data = {
                "skill_name": skill_name,
                "execution_id": execution_id,
                "timestamp": datetime.now().isoformat(),
                "log_analysis": log_analysis,
                "metadata": metadata or {}
            }
            
            metadata_file = exec_dir / "metadata.json"
            metadata_file.write_text(json.dumps(execution_data, indent=2, ensure_ascii=False), 
                                    encoding='utf-8')
            
            return {
                "status": "success",
                "skill_name": skill_name,
                "execution_id": execution_id,
                "log_file": str(log_file),
                "metadata_file": str(metadata_file),
                "log_analysis": log_analysis
            }
        
        except Exception as e:
            return {
                "status": "error",
                "skill_name": skill_name,
                "execution_id": execution_id,
                "error": str(e)
            }
    
    def _analyze_log(self, log_content: str) -> Dict[str, Any]:
        """分析日志内容"""
        analysis = {
            "total_lines": len(log_content.split('\n')),
            "has_errors": bool(re.search(r'error|Error|ERROR', log_content, re.IGNORECASE)),
            "has_warnings": bool(re.search(r'warning|Warning|WARNING', log_content, re.IGNORECASE)),
            "has_success": bool(re.search(r'success|Success|SUCCESS|✅|completed', log_content, re.IGNORECASE)),
            "error_count": len(re.findall(r'error|Error|ERROR', log_content, re.IGNORECASE)),
            "warning_count": len(re.findall(r'warning|Warning|WARNING', log_content, re.IGNORECASE)),
        }
        return analysis
    
    # ==================== 报告生成 ====================
    
    def generate_report(self, execution_id: str, skill_name: Optional[str] = None) -> Dict[str, Any]:
        """
        生成执行报告
        
        Args:
            execution_id: 执行 ID
            skill_name: Skill 名称（可选，用于查找特定 Skill 的执行）
        
        Returns:
            报告字典
        """
        try:
            # 查找执行数据
            if skill_name:
                exec_dir = self.executions_dir / skill_name / execution_id
            else:
                # 搜索所有 Skill 目录
                exec_dir = None
                for skill_dir in self.executions_dir.iterdir():
                    if skill_dir.is_dir():
                        potential_dir = skill_dir / execution_id
                        if potential_dir.exists():
                            exec_dir = potential_dir
                            skill_name = skill_dir.name
                            break
            
            if not exec_dir or not exec_dir.exists():
                return {
                    "status": "error",
                    "error": f"Execution not found: {execution_id}"
                }
            
            # 读取元数据
            metadata_file = exec_dir / "metadata.json"
            if metadata_file.exists():
                execution_data = json.loads(metadata_file.read_text(encoding='utf-8'))
            else:
                execution_data = {}
            
            # 生成报告
            report = {
                "report_type": "execution_report",
                "generated_at": datetime.now().isoformat(),
                "skill_name": skill_name,
                "execution_id": execution_id,
                "execution_data": execution_data,
                "summary": self._generate_summary(execution_data)
            }
            
            # 保存报告
            report_file = self.reports_dir / f"{skill_name}_{execution_id}_report.json"
            report_file.write_text(json.dumps(report, indent=2, ensure_ascii=False), 
                                  encoding='utf-8')
            
            return {
                "status": "success",
                "report_file": str(report_file),
                "report": report
            }
        
        except Exception as e:
            return {
                "status": "error",
                "error": str(e)
            }
    
    def _generate_summary(self, execution_data: Dict) -> Dict[str, Any]:
        """生成执行摘要"""
        log_analysis = execution_data.get("log_analysis", {})
        
        # 判断执行状态
        if log_analysis.get("has_errors"):
            status = "failed"
        elif log_analysis.get("has_success"):
            status = "success"
        else:
            status = "unknown"
        
        return {
            "status": status,
            "total_log_lines": log_analysis.get("total_lines", 0),
            "error_count": log_analysis.get("error_count", 0),
            "warning_count": log_analysis.get("warning_count", 0),
            "has_success_indicator": log_analysis.get("has_success", False)
        }
    
    # ==================== 性能分析 ====================
    
    def analyze_performance(self, skill_name: str, time_range: Optional[str] = None) -> Dict[str, Any]:
        """
        分析 Skill 性能指标
        
        Args:
            skill_name: Skill 名称
            time_range: 时间范围（如 "24h", "7d", "30d"，默认为所有时间）
        
        Returns:
            性能分析结果
        """
        try:
            skill_dir = self.executions_dir / skill_name
            if not skill_dir.exists():
                return {
                    "status": "error",
                    "error": f"No executions found for skill: {skill_name}"
                }
            
            # 收集所有执行数据
            executions = []
            for exec_dir in skill_dir.iterdir():
                if exec_dir.is_dir():
                    metadata_file = exec_dir / "metadata.json"
                    if metadata_file.exists():
                        try:
                            data = json.loads(metadata_file.read_text(encoding='utf-8'))
                            executions.append(data)
                        except:
                            pass
            
            if not executions:
                return {
                    "status": "error",
                    "error": f"No valid execution data found for skill: {skill_name}"
                }
            
            # 过滤时间范围
            if time_range:
                executions = self._filter_by_time_range(executions, time_range)
            
            # 计算性能指标
            performance = self._calculate_performance_metrics(executions)
            
            # 保存分析结果
            analysis_file = self.reports_dir / f"{skill_name}_performance_analysis.json"
            analysis_data = {
                "analysis_type": "performance_analysis",
                "generated_at": datetime.now().isoformat(),
                "skill_name": skill_name,
                "time_range": time_range or "all",
                "total_executions": len(executions),
                "performance_metrics": performance
            }
            analysis_file.write_text(json.dumps(analysis_data, indent=2, ensure_ascii=False), 
                                    encoding='utf-8')
            
            return {
                "status": "success",
                "skill_name": skill_name,
                "analysis_file": str(analysis_file),
                "performance_metrics": performance
            }
        
        except Exception as e:
            return {
                "status": "error",
                "error": str(e)
            }
    
    def _filter_by_time_range(self, executions: List[Dict], time_range: str) -> List[Dict]:
        """按时间范围过滤执行"""
        # 解析时间范围
        match = re.match(r'(\d+)([hdw])', time_range.lower())
        if not match:
            return executions
        
        value, unit = int(match.group(1)), match.group(2)
        if unit == 'h':
            delta = timedelta(hours=value)
        elif unit == 'd':
            delta = timedelta(days=value)
        elif unit == 'w':
            delta = timedelta(weeks=value)
        else:
            return executions
        
        cutoff_time = datetime.now() - delta
        
        filtered = []
        for exec_data in executions:
            try:
                exec_time = datetime.fromisoformat(exec_data.get("timestamp", ""))
                if exec_time >= cutoff_time:
                    filtered.append(exec_data)
            except:
                pass
        
        return filtered
    
    def _calculate_performance_metrics(self, executions: List[Dict]) -> Dict[str, Any]:
        """计算性能指标"""
        if not executions:
            return {}
        
        # 统计成功/失败
        success_count = 0
        error_count = 0
        warning_count = 0
        total_log_lines = []
        
        for exec_data in executions:
            log_analysis = exec_data.get("log_analysis", {})
            
            if log_analysis.get("has_errors"):
                error_count += 1
            elif log_analysis.get("has_success"):
                success_count += 1
            
            warning_count += log_analysis.get("warning_count", 0)
            total_log_lines.append(log_analysis.get("total_lines", 0))
        
        # 计算指标
        total = len(executions)
        success_rate = (success_count / total * 100) if total > 0 else 0
        error_rate = (error_count / total * 100) if total > 0 else 0
        
        metrics = {
            "total_executions": total,
            "success_count": success_count,
            "error_count": error_count,
            "success_rate": round(success_rate, 2),
            "error_rate": round(error_rate, 2),
            "total_warnings": warning_count,
            "avg_log_lines": round(statistics.mean(total_log_lines), 2) if total_log_lines else 0,
            "max_log_lines": max(total_log_lines) if total_log_lines else 0,
            "min_log_lines": min(total_log_lines) if total_log_lines else 0
        }
        
        return metrics
    
    # ==================== 辅助方法 ====================
    
    def list_executions(self, skill_name: Optional[str] = None, limit: int = 10) -> Dict[str, Any]:
        """
        列出执行记录
        
        Args:
            skill_name: Skill 名称（可选，不指定则列出所有 Skill）
            limit: 返回的最大记录数
        
        Returns:
            执行记录列表
        """
        try:
            executions = []
            
            if skill_name:
                skill_dir = self.executions_dir / skill_name
                if skill_dir.exists():
                    for exec_dir in sorted(skill_dir.iterdir(), reverse=True)[:limit]:
                        if exec_dir.is_dir():
                            metadata_file = exec_dir / "metadata.json"
                            if metadata_file.exists():
                                try:
                                    data = json.loads(metadata_file.read_text(encoding='utf-8'))
                                    executions.append(data)
                                except:
                                    pass
            else:
                # 列出所有 Skill 的最新执行
                for skill_dir in self.executions_dir.iterdir():
                    if skill_dir.is_dir():
                        for exec_dir in sorted(skill_dir.iterdir(), reverse=True)[:1]:
                            if exec_dir.is_dir():
                                metadata_file = exec_dir / "metadata.json"
                                if metadata_file.exists():
                                    try:
                                        data = json.loads(metadata_file.read_text(encoding='utf-8'))
                                        executions.append(data)
                                    except:
                                        pass
            
            return {
                "status": "success",
                "skill_name": skill_name,
                "total_executions": len(executions),
                "executions": executions
            }
        
        except Exception as e:
            return {
                "status": "error",
                "error": str(e)
            }
    
    def get_execution_status(self, execution_id: str, skill_name: Optional[str] = None) -> Dict[str, Any]:
        """
        获取执行状态
        
        Args:
            execution_id: 执行 ID
            skill_name: Skill 名称（可选）
        
        Returns:
            执行状态
        """
        try:
            if skill_name:
                exec_dir = self.executions_dir / skill_name / execution_id
            else:
                # 搜索所有 Skill
                exec_dir = None
                for skill_dir in self.executions_dir.iterdir():
                    if skill_dir.is_dir():
                        potential_dir = skill_dir / execution_id
                        if potential_dir.exists():
                            exec_dir = potential_dir
                            break
            
            if not exec_dir or not exec_dir.exists():
                return {
                    "status": "not_found",
                    "execution_id": execution_id
                }
            
            metadata_file = exec_dir / "metadata.json"
            if metadata_file.exists():
                data = json.loads(metadata_file.read_text(encoding='utf-8'))
                return {
                    "status": "found",
                    "execution_id": execution_id,
                    "data": data
                }
            
            return {
                "status": "incomplete",
                "execution_id": execution_id
            }
        
        except Exception as e:
            return {
                "status": "error",
                "error": str(e)
            }


# ==================== CLI 接口 ====================

if __name__ == "__main__":
    import sys
    
    monitor = SkillExecutionMonitor()
    
    if len(sys.argv) < 2:
        print("用法:")
        print("  python3 skill-execution-monitor.py monitor <skill_name> <execution_id> <log_file>")
        print("  python3 skill-execution-monitor.py report <execution_id> [skill_name]")
        print("  python3 skill-execution-monitor.py analyze <skill_name> [time_range]")
        print("  python3 skill-execution-monitor.py list [skill_name] [limit]")
        print("  python3 skill-execution-monitor.py status <execution_id> [skill_name]")
        sys.exit(1)
    
    command = sys.argv[1]
    
    if command == "monitor" and len(sys.argv) >= 5:
        skill_name = sys.argv[2]
        execution_id = sys.argv[3]
        log_file = sys.argv[4]
        
        if Path(log_file).exists():
            log_content = Path(log_file).read_text(encoding='utf-8')
            result = monitor.monitor_execution(skill_name, execution_id, log_content)
            print(json.dumps(result, indent=2, ensure_ascii=False))
        else:
            print(f"错误: 日志文件不存在: {log_file}")
    
    elif command == "report" and len(sys.argv) >= 3:
        execution_id = sys.argv[2]
        skill_name = sys.argv[3] if len(sys.argv) > 3 else None
        result = monitor.generate_report(execution_id, skill_name)
        print(json.dumps(result, indent=2, ensure_ascii=False))
    
    elif command == "analyze" and len(sys.argv) >= 3:
        skill_name = sys.argv[2]
        time_range = sys.argv[3] if len(sys.argv) > 3 else None
        result = monitor.analyze_performance(skill_name, time_range)
        print(json.dumps(result, indent=2, ensure_ascii=False))
    
    elif command == "list":
        skill_name = sys.argv[2] if len(sys.argv) > 2 else None
        limit = int(sys.argv[3]) if len(sys.argv) > 3 else 10
        result = monitor.list_executions(skill_name, limit)
        print(json.dumps(result, indent=2, ensure_ascii=False))
    
    elif command == "status" and len(sys.argv) >= 3:
        execution_id = sys.argv[2]
        skill_name = sys.argv[3] if len(sys.argv) > 3 else None
        result = monitor.get_execution_status(execution_id, skill_name)
        print(json.dumps(result, indent=2, ensure_ascii=False))
    
    else:
        print(f"未知命令: {command}")
        sys.exit(1)

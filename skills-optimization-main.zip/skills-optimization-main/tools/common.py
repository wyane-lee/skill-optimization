#!/usr/bin/env python3
"""skills-optimization 共享常量和工具 - 单一真相源"""
from pathlib import Path

# 项目根目录(单一真相源)
PROJECT_ROOT = Path.home() / ".config" / "opencode" / "skills" / "skills-optimization"

# 执行数据目录(monitor 写 / analyzer 读 必须一致)
EXECUTIONS_DIR = PROJECT_ROOT / "data" / "executions"

# 性能报告目录
REPORTS_DIR = PROJECT_ROOT / "reports" / "performance"

# Skills 矩阵文件
MATRIX_FILE = PROJECT_ROOT / "data" / "skills-matrix.json"

# 统一的执行记录文件名(monitor 写这个,analyzer 读这个)
EXECUTION_RECORD_FILENAME = "metadata.json"

#!/usr/bin/env python3
"""
Skill 监控系统 - 完整测试套件

包括单元测试、集成测试、端到端测试和性能测试。
"""

import sys
import json
import time
import tempfile
from pathlib import Path
from datetime import datetime
from typing import Dict, Any, List, Tuple

# 导入要测试的模块
sys.path.insert(0, str(Path(__file__).parent))

from skill_monitoring import SkillMonitoring
from skill_router import SkillRouter
from usage_analyzer import UsageAnalyzer

# 导入执行验证器（处理连字符文件名）
import sys
import importlib.util
verifier_path = Path(__file__).parent / "skill-execution-verifier.py"
spec = importlib.util.spec_from_file_location("skill_execution_verifier", verifier_path)
if spec and spec.loader:
    skill_exec_verifier = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(skill_exec_verifier)
    SkillExecutionVerifier = skill_exec_verifier.SkillExecutionVerifier
else:
    raise ImportError("Failed to load skill-execution-verifier.py")


class TestResult:
    """测试结果"""
    def __init__(self, name: str):
        self.name = name
        self.passed = 0
        self.failed = 0
        self.errors = []
        self.start_time = time.time()
    
    def add_pass(self):
        self.passed += 1
    
    def add_fail(self, error: str):
        self.failed += 1
        self.errors.append(error)
    
    def get_duration(self) -> float:
        return time.time() - self.start_time
    
    def get_summary(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "passed": self.passed,
            "failed": self.failed,
            "total": self.passed + self.failed,
            "success_rate": round((self.passed / (self.passed + self.failed) * 100), 2) if (self.passed + self.failed) > 0 else 0,
            "duration": round(self.get_duration(), 2),
            "errors": self.errors
        }


class SkillMonitoringTestSuite:
    """Skill 监控系统测试套件"""
    
    def __init__(self):
        self.results = []
    
    def run_all_tests(self) -> Dict[str, Any]:
        """运行所有测试"""
        print("=" * 70)
        print("Skill 监控系统 - 完整测试套件")
        print("=" * 70)
        
        # 单元测试
        print("\n📋 Phase 1: 单元测试")
        print("-" * 70)
        self.test_skill_monitoring()
        self.test_skill_router()
        self.test_usage_analyzer()
        self.test_skill_execution_verifier()
        
        # 集成测试
        print("\n📋 Phase 2: 集成测试")
        print("-" * 70)
        self.test_integration()
        
        # 端到端测试
        print("\n📋 Phase 3: 端到端测试")
        print("-" * 70)
        self.test_end_to_end()
        
        # 性能测试
        print("\n📋 Phase 4: 性能测试")
        print("-" * 70)
        self.test_performance()
        
        # 生成报告
        return self.generate_report()
    
    def test_skill_monitoring(self):
        """测试 Skill 监控模块"""
        result = TestResult("SkillMonitoring")
        
        try:
            monitor = SkillMonitoring()
            
            # 测试 1: 生成执行 ID
            try:
                execution_id = monitor.generate_execution_id()
                assert execution_id.startswith("exec_"), "执行 ID 格式错误"
                result.add_pass()
                print("  ✅ 测试 1: 生成执行 ID")
            except Exception as e:
                result.add_fail(f"生成执行 ID 失败: {e}")
                print(f"  ❌ 测试 1: {e}")
            
            # 测试 2: 列出执行
            try:
                executions = monitor.list_executions(limit=5)
                assert executions["status"] in ["success", "no_data"], "列出执行失败"
                result.add_pass()
                print("  ✅ 测试 2: 列出执行")
            except Exception as e:
                result.add_fail(f"列出执行失败: {e}")
                print(f"  ❌ 测试 2: {e}")
            
            # 测试 3: 获取执行状态
            try:
                status = monitor.get_execution_status("test_exec_id")
                assert "status" in status, "获取执行状态失败"
                result.add_pass()
                print("  ✅ 测试 3: 获取执行状态")
            except Exception as e:
                result.add_fail(f"获取执行状态失败: {e}")
                print(f"  ❌ 测试 3: {e}")
            
        except Exception as e:
            result.add_fail(f"SkillMonitoring 测试异常: {e}")
            print(f"  ❌ 异常: {e}")
        
        self.results.append(result)
    
    def test_skill_router(self):
        """测试智能路由模块"""
        result = TestResult("SkillRouter")
        
        try:
            router = SkillRouter()
            
            # 测试 1: 列出所有 Skill
            try:
                skills = router.list_all_skills()
                assert isinstance(skills, list), "列出 Skill 失败"
                result.add_pass()
                print("  ✅ 测试 1: 列出所有 Skill")
            except Exception as e:
                result.add_fail(f"列出 Skill 失败: {e}")
                print(f"  ❌ 测试 1: {e}")
            
            # 测试 2: 意图路由
            try:
                matches = router.route("监控 Skill 执行", top_k=3)
                assert isinstance(matches, list), "意图路由失败"
                result.add_pass()
                print("  ✅ 测试 2: 意图路由")
            except Exception as e:
                result.add_fail(f"意图路由失败: {e}")
                print(f"  ❌ 测试 2: {e}")
            
            # 测试 3: 操作路由
            try:
                matches = router.route_by_action("search", top_k=3)
                assert isinstance(matches, list), "操作路由失败"
                result.add_pass()
                print("  ✅ 测试 3: 操作路由")
            except Exception as e:
                result.add_fail(f"操作路由失败: {e}")
                print(f"  ❌ 测试 3: {e}")
            
            # 测试 4: 数据源路由
            try:
                matches = router.route_by_data_source("webex", top_k=3)
                assert isinstance(matches, list), "数据源路由失败"
                result.add_pass()
                print("  ✅ 测试 4: 数据源路由")
            except Exception as e:
                result.add_fail(f"数据源路由失败: {e}")
                print(f"  ❌ 测试 4: {e}")
            
        except Exception as e:
            result.add_fail(f"SkillRouter 测试异常: {e}")
            print(f"  ❌ 异常: {e}")
        
        self.results.append(result)
    
    def test_usage_analyzer(self):
        """测试使用情况分析模块"""
        result = TestResult("UsageAnalyzer")
        
        try:
            analyzer = UsageAnalyzer()
            
            # 测试 1: 分析所有执行
            try:
                analysis = analyzer.analyze_all()
                assert "status" in analysis, "分析所有执行失败"
                result.add_pass()
                print("  ✅ 测试 1: 分析所有执行")
            except Exception as e:
                result.add_fail(f"分析所有执行失败: {e}")
                print(f"  ❌ 测试 1: {e}")
            
            # 测试 2: 获取成功率
            try:
                success_rate = analyzer.get_success_rate()
                assert "success_rate" in success_rate, "获取成功率失败"
                result.add_pass()
                print("  ✅ 测试 2: 获取成功率")
            except Exception as e:
                result.add_fail(f"获取成功率失败: {e}")
                print(f"  ❌ 测试 2: {e}")
            
            # 测试 3: 获取错误报告
            try:
                error_report = analyzer.get_error_report()
                assert "error_count" in error_report, "获取错误报告失败"
                result.add_pass()
                print("  ✅ 测试 3: 获取错误报告")
            except Exception as e:
                result.add_fail(f"获取错误报告失败: {e}")
                print(f"  ❌ 测试 3: {e}")
            
            # 测试 4: 获取性能报告
            try:
                perf_report = analyzer.get_performance_report()
                assert "status" in perf_report, "获取性能报告失败"
                result.add_pass()
                print("  ✅ 测试 4: 获取性能报告")
            except Exception as e:
                result.add_fail(f"获取性能报告失败: {e}")
                print(f"  ❌ 测试 4: {e}")
            
        except Exception as e:
            result.add_fail(f"UsageAnalyzer 测试异常: {e}")
            print(f"  ❌ 异常: {e}")
        
        self.results.append(result)
    
    def test_skill_execution_verifier(self):
        """测试执行验证模块"""
        result = TestResult("SkillExecutionVerifier")
        
        try:
            verifier = SkillExecutionVerifier("test_skill")
            
            # 测试 1: 生成执行 ID
            try:
                execution_id = verifier.execution_id
                assert execution_id.startswith("exec_"), "执行 ID 格式错误"
                result.add_pass()
                print("  ✅ 测试 1: 生成执行 ID")
            except Exception as e:
                result.add_fail(f"生成执行 ID 失败: {e}")
                print(f"  ❌ 测试 1: {e}")
            
            # 测试 2: 记录事件
            try:
                verifier.log_event("test_event", {"key": "value"})
                assert len(verifier.events) > 0, "记录事件失败"
                result.add_pass()
                print("  ✅ 测试 2: 记录事件")
            except Exception as e:
                result.add_fail(f"记录事件失败: {e}")
                print(f"  ❌ 测试 2: {e}")
            
            # 测试 3: 验证前置条件
            try:
                checks = {"check1": True, "check2": True}
                passed = verifier.verify_preconditions(checks)
                assert passed, "验证前置条件失败"
                result.add_pass()
                print("  ✅ 测试 3: 验证前置条件")
            except Exception as e:
                result.add_fail(f"验证前置条件失败: {e}")
                print(f"  ❌ 测试 3: {e}")
            
            # 测试 4: 验证工具执行
            try:
                verification = verifier.verify_tool_execution("bash", {}, "success output")
                assert "executed" in verification, "验证工具执行失败"
                result.add_pass()
                print("  ✅ 测试 4: 验证工具执行")
            except Exception as e:
                result.add_fail(f"验证工具执行失败: {e}")
                print(f"  ❌ 测试 4: {e}")
            
        except Exception as e:
            result.add_fail(f"SkillExecutionVerifier 测试异常: {e}")
            print(f"  ❌ 异常: {e}")
        
        self.results.append(result)
    
    def test_integration(self):
        """集成测试"""
        result = TestResult("Integration")
        
        try:
            # 测试 1: 监控 + 路由集成
            try:
                monitor = SkillMonitoring()
                router = SkillRouter()
                
                execution_id = monitor.generate_execution_id()
                matches = router.route("监控执行", top_k=1)
                
                assert execution_id, "生成执行 ID 失败"
                assert isinstance(matches, list), "路由失败"
                result.add_pass()
                print("  ✅ 测试 1: 监控 + 路由集成")
            except Exception as e:
                result.add_fail(f"监控 + 路由集成失败: {e}")
                print(f"  ❌ 测试 1: {e}")
            
            # 测试 2: 监控 + 分析集成
            try:
                monitor = SkillMonitoring()
                analyzer = UsageAnalyzer()
                
                executions = monitor.list_executions(limit=5)
                analysis = analyzer.analyze_all()
                
                assert executions["status"] in ["success", "no_data"], "列出执行失败"
                assert analysis["status"] in ["success", "no_data"], "分析失败"
                result.add_pass()
                print("  ✅ 测试 2: 监控 + 分析集成")
            except Exception as e:
                result.add_fail(f"监控 + 分析集成失败: {e}")
                print(f"  ❌ 测试 2: {e}")
            
            # 测试 3: 验证 + 分析集成
            try:
                verifier = SkillExecutionVerifier("test_skill")
                analyzer = UsageAnalyzer()
                
                verifier.log_event("test", {})
                analysis = analyzer.analyze_all()
                
                assert len(verifier.events) > 0, "记录事件失败"
                assert analysis["status"] in ["success", "no_data"], "分析失败"
                result.add_pass()
                print("  ✅ 测试 3: 验证 + 分析集成")
            except Exception as e:
                result.add_fail(f"验证 + 分析集成失败: {e}")
                print(f"  ❌ 测试 3: {e}")
            
        except Exception as e:
            result.add_fail(f"集成测试异常: {e}")
            print(f"  ❌ 异常: {e}")
        
        self.results.append(result)
    
    def test_end_to_end(self):
        """端到端测试"""
        result = TestResult("EndToEnd")
        
        try:
            # 测试 1: 完整工作流程
            try:
                monitor = SkillMonitoring()
                router = SkillRouter()
                verifier = SkillExecutionVerifier("test_skill")
                analyzer = UsageAnalyzer()
                
                # 1. 生成执行 ID
                execution_id = monitor.generate_execution_id()
                
                # 2. 路由到合适的 Skill
                matches = router.route("监控执行", top_k=1)
                
                # 3. 验证执行
                verifier.log_event("execution_start", {"execution_id": execution_id})
                verifier.verify_preconditions({"ready": True})
                verifier.verify_tool_execution("bash", {}, "success")
                
                # 4. 分析结果
                analysis = analyzer.analyze_all()
                
                assert execution_id, "执行 ID 生成失败"
                assert isinstance(matches, list), "路由失败"
                assert len(verifier.events) > 0, "验证失败"
                assert analysis["status"] in ["success", "no_data"], "分析失败"
                
                result.add_pass()
                print("  ✅ 测试 1: 完整工作流程")
            except Exception as e:
                result.add_fail(f"完整工作流程失败: {e}")
                print(f"  ❌ 测试 1: {e}")
            
        except Exception as e:
            result.add_fail(f"端到端测试异常: {e}")
            print(f"  ❌ 异常: {e}")
        
        self.results.append(result)
    
    def test_performance(self):
        """性能测试"""
        result = TestResult("Performance")
        
        try:
            # 测试 1: 监控性能
            try:
                monitor = SkillMonitoring()
                start = time.time()
                
                for _ in range(10):
                    monitor.generate_execution_id()
                
                duration = time.time() - start
                assert duration < 1.0, f"生成执行 ID 太慢: {duration}s"
                result.add_pass()
                print(f"  ✅ 测试 1: 监控性能 ({duration:.3f}s)")
            except Exception as e:
                result.add_fail(f"监控性能测试失败: {e}")
                print(f"  ❌ 测试 1: {e}")
            
            # 测试 2: 路由性能
            try:
                router = SkillRouter()
                start = time.time()
                
                for _ in range(10):
                    router.route("测试意图", top_k=3)
                
                duration = time.time() - start
                assert duration < 2.0, f"路由太慢: {duration}s"
                result.add_pass()
                print(f"  ✅ 测试 2: 路由性能 ({duration:.3f}s)")
            except Exception as e:
                result.add_fail(f"路由性能测试失败: {e}")
                print(f"  ❌ 测试 2: {e}")
            
            # 测试 3: 分析性能
            try:
                analyzer = UsageAnalyzer()
                start = time.time()
                
                analyzer.analyze_all()
                
                duration = time.time() - start
                assert duration < 5.0, f"分析太慢: {duration}s"
                result.add_pass()
                print(f"  ✅ 测试 3: 分析性能 ({duration:.3f}s)")
            except Exception as e:
                result.add_fail(f"分析性能测试失败: {e}")
                print(f"  ❌ 测试 3: {e}")
            
        except Exception as e:
            result.add_fail(f"性能测试异常: {e}")
            print(f"  ❌ 异常: {e}")
        
        self.results.append(result)
    
    def generate_report(self) -> Dict[str, Any]:
        """生成测试报告"""
        print("\n" + "=" * 70)
        print("测试报告")
        print("=" * 70)
        
        summaries = [r.get_summary() for r in self.results]
        
        total_passed = sum(s["passed"] for s in summaries)
        total_failed = sum(s["failed"] for s in summaries)
        total_tests = total_passed + total_failed
        overall_success_rate = (total_passed / total_tests * 100) if total_tests > 0 else 0
        
        print(f"\n📊 总体统计:")
        print(f"  总测试数: {total_tests}")
        print(f"  通过: {total_passed}")
        print(f"  失败: {total_failed}")
        print(f"  成功率: {overall_success_rate:.2f}%")
        
        print(f"\n📋 详细结果:")
        for summary in summaries:
            status = "✅" if summary["failed"] == 0 else "❌"
            print(f"  {status} {summary['name']}: {summary['passed']}/{summary['total']} ({summary['success_rate']:.2f}%)")
        
        report = {
            "timestamp": datetime.now().isoformat(),
            "summary": {
                "total_tests": total_tests,
                "passed": total_passed,
                "failed": total_failed,
                "success_rate": round(overall_success_rate, 2)
            },
            "details": summaries
        }
        
        # 保存报告
        report_file = Path(__file__).parent / "test-report.json"
        with open(report_file, "w") as f:
            json.dump(report, f, indent=2, ensure_ascii=False)
        
        print(f"\n✅ 测试报告已保存: {report_file}")
        
        return report


if __name__ == "__main__":
    suite = SkillMonitoringTestSuite()
    report = suite.run_all_tests()
    
    # 返回退出码
    sys.exit(0 if report["summary"]["failed"] == 0 else 1)

#!/usr/bin/env python3
"""
Skill 重叠检测工具
用于识别功能相似的 Skill，避免重复和冗余
"""

import json
import os
from pathlib import Path
from typing import List, Dict, Tuple, Optional


class OverlapDetector:
    """检测 Skill 之间的功能重叠"""
    
    def __init__(self, skills_dir: Optional[str] = None):
        """初始化检测器"""
        if skills_dir is None:
            skills_dir = os.path.expanduser("~/.config/opencode/skills")
        self.skills_dir = Path(skills_dir)
        self.skills = self._load_skills()
    
    def _load_skills(self) -> Dict:
        """加载所有 Skill 元数据"""
        skills = {}
        if not self.skills_dir.exists():
            return {}
        for skill_path in self.skills_dir.iterdir():
            if skill_path.is_dir():
                skill_md = skill_path / "SKILL.md"
                if skill_md.exists():
                    skills[skill_path.name] = {
                        "path": skill_path,
                        "description": self._extract_description(skill_md)
                    }
        return skills
    
    def _extract_description(self, skill_md: Path) -> str:
        """从 SKILL.md 提取描述(优先 YAML frontmatter 的 description 字段)"""
        try:
            with open(skill_md, 'r', encoding='utf-8') as f:
                content = f.read()
        except OSError:
            return ""
        
        lines = content.split('\n')
        
        # 情况1: YAML frontmatter (--- 开头)
        if lines and lines[0].strip() == '---':
            in_frontmatter = True
            desc_parts = []
            collecting = False
            for line in lines[1:]:
                if line.strip() == '---':
                    break
                # description: 字段(可能多行)
                if line.lower().startswith('description:'):
                    collecting = True
                    desc_parts.append(line.split(':', 1)[1].strip())
                elif collecting and (line.startswith('  ') or line.startswith('\t')):
                    desc_parts.append(line.strip())
                elif collecting and line and not line[0].isspace():
                    collecting = False
            if desc_parts:
                return ' '.join(desc_parts).strip()
        
        # 情况2: 无 frontmatter,取第一个非空非标题非分隔符行
        for line in lines:
            stripped = line.strip()
            if stripped and not stripped.startswith('#') and stripped != '---':
                return stripped
        
        return ""
    
    def detect_overlaps(self, threshold: float = 0.6) -> List[Dict]:
        """检测重叠的 Skill"""
        overlaps = []
        skill_names = list(self.skills.keys())
        
        for i, skill_a in enumerate(skill_names):
            for skill_b in skill_names[i+1:]:
                similarity = self._calculate_similarity(
                    self.skills[skill_a]["description"],
                    self.skills[skill_b]["description"]
                )
                
                if similarity >= threshold:
                    overlaps.append({
                        "skill_a": skill_a,
                        "skill_b": skill_b,
                        "similarity": round(similarity * 100, 1),
                        "recommendation": self._get_recommendation(skill_a, skill_b)
                    })
        
        return sorted(overlaps, key=lambda x: x["similarity"], reverse=True)
    
    def _calculate_similarity(self, desc_a: str, desc_b: str) -> float:
        """计算两个描述的相似度"""
        if not desc_a or not desc_b:
            return 0.0
        
        words_a = set(desc_a.lower().split())
        words_b = set(desc_b.lower().split())
        
        if not words_a or not words_b:
            return 0.0
        
        intersection = len(words_a & words_b)
        union = len(words_a | words_b)
        
        return intersection / union if union > 0 else 0.0
    
    def _get_recommendation(self, skill_a: str, skill_b: str) -> str:
        """获取优化建议"""
        return f"考虑合并 {skill_a} 和 {skill_b}，或明确划分职责"
    
    def get_recommendations(self) -> List[Dict]:
        """获取所有优化建议"""
        overlaps = self.detect_overlaps()
        return [
            {
                "issue": f"{o['skill_a']} 和 {o['skill_b']} 相似度 {o['similarity']}%",
                "recommendation": o["recommendation"]
            }
            for o in overlaps
        ]


if __name__ == "__main__":
    detector = OverlapDetector()
    overlaps = detector.detect_overlaps()
    
    if overlaps:
        print("🔍 检测到的 Skill 重叠:")
        print("")
        for overlap in overlaps:
            print(f"  {overlap['skill_a']} <-> {overlap['skill_b']}")
            print(f"    相似度: {overlap['similarity']}%")
            print(f"    建议: {overlap['recommendation']}")
            print("")
    else:
        print("✅ 未检测到 Skill 重叠")

#!/usr/bin/env python3
"""
A3 + B2: 合并 Skills 数据并执行重叠检测
- 合并 skills-inventory.json (73 runtime skills) + skills-documentation.json (64 AGENTS.md skills)
- 用 TF-IDF + 余弦相似度 + 维度匹配做重叠检测
- 输出 skills-matrix.json 和 overlaps-detected.json
"""
import json, re, math
from pathlib import Path
from collections import Counter

ROOT = Path("/Users/wenfeli/Documents/claude_projects/skills-optimization")
DATA = ROOT / "data"

inv = json.loads((DATA / "skills-inventory.json").read_text())
doc = json.loads((DATA / "skills-documentation.json").read_text())

# 索引
inv_by_name = {s["name"]: s for s in inv["skills"]}
# doc 结构可能不同，尝试几种
doc_skills = doc.get("skills") or doc.get("categories") or doc
doc_by_name = {}
if isinstance(doc_skills, list):
    for s in doc_skills:
        if isinstance(s, dict) and "name" in s:
            doc_by_name[s["name"]] = s
elif isinstance(doc_skills, dict):
    # 可能是按 category 分组
    for cat, items in doc_skills.items():
        if isinstance(items, list):
            for s in items:
                if isinstance(s, dict) and "name" in s:
                    s["_category"] = cat
                    doc_by_name[s["name"]] = s

# 维度推断
DATA_SOURCES = {
    "webex": ["webex"], "email": ["email", "outlook", "mail"],
    "github": ["github", "git", "repo"], "radkit": ["radkit"],
    "salesforce": ["salesforce", "sfdc", "sf "], "cdets": ["cdets", "bug"],
    "techzone": ["techzone"], "browser": ["browser", "chrome", "cdp", "playwright"],
    "filesystem": ["file", "directory", "filesystem"], "cisco-internal": ["cisco", "circuit"],
    "presentation": ["pptx", "presentation", "slide", "marp", "deck"],
    "code": ["code", "programming", "python", "kotlin", "rust", "java", "go "],
    "csone": ["csone", "cs1", "sr "], "quicker": ["quicker"],
    "calendar": ["calendar", "meeting"],
}
ACTIONS = {
    "search": ["search", "query", "find", "look up", "rag", "retrieve"],
    "export": ["dump", "download", "export", "extract", "save"],
    "create": ["create", "generate", "build", "make", "new ", "spawn"],
    "manage": ["manage", "configure", "setup", "install", "grant", "add"],
    "convert": ["convert", "transform", "markdown", "format"],
    "analyze": ["analyze", "review", "audit", "check", "report"],
}

def infer_dims(name, desc, content):
    text = f"{name} {desc} {content}".lower()
    sources = [k for k, kws in DATA_SOURCES.items() if any(kw in text for kw in kws)]
    actions = [k for k, kws in ACTIONS.items() if any(kw in text for kw in kws)]
    return sources or ["other"], actions or ["other"]

# 构建统一矩阵
matrix = []
for name, s in inv_by_name.items():
    desc = s.get("description", "") or ""
    content = s.get("content_summary", "") or ""
    doc_entry = doc_by_name.get(name, {})
    sources, actions = infer_dims(name, desc, content)
    
    # 优先级（从 doc 推断）
    priority = "standard"
    doc_desc = (doc_entry.get("description") or "").lower()
    if doc_entry.get("deprecated") or "deprecated" in doc_desc:
        priority = "deprecated"
    elif doc_entry.get("priority") == "PREFERRED" or "preferred" in doc_desc:
        priority = "preferred"
    elif name not in doc_by_name:
        priority = "undocumented"
    
    matrix.append({
        "name": name,
        "category": doc_entry.get("category") or doc_entry.get("_category") or "uncategorized",
        "description": desc[:300],
        "data_sources": sources,
        "actions": actions,
        "priority": priority,
        "in_runtime": True,
        "in_agents_md": name in doc_by_name,
        "tags": s.get("tags", []),
    })

(DATA / "skills-matrix.json").write_text(json.dumps({
    "generated_at": "2026-06-17",
    "total": len(matrix),
    "skills": matrix,
}, indent=2, ensure_ascii=False))

# ---------- 重叠检测 ----------
STOP = set("the a an and or of to in for with on at by is are was were be been use used uses skill agent when user task description name file files data".split())

def tokens(text):
    return [w for w in re.findall(r"[a-z]+", text.lower()) if w not in STOP and len(w) > 2]

def tfidf_vectors(docs):
    df = Counter()
    doc_tokens = [tokens(d) for d in docs]
    for toks in doc_tokens:
        for t in set(toks):
            df[t] += 1
    N = len(docs)
    vectors = []
    for toks in doc_tokens:
        tf = Counter(toks)
        vec = {t: (c / len(toks)) * math.log(N / df[t]) for t, c in tf.items() if df[t] > 0}
        vectors.append(vec)
    return vectors

def cosine(a, b):
    common = set(a) & set(b)
    if not common: return 0.0
    dot = sum(a[t] * b[t] for t in common)
    na = math.sqrt(sum(v*v for v in a.values()))
    nb = math.sqrt(sum(v*v for v in b.values()))
    return dot / (na * nb) if na and nb else 0.0

docs_text = [f"{m['name']} {m['description']}" for m in matrix]
vecs = tfidf_vectors(docs_text)

overlaps = []
for i in range(len(matrix)):
    for j in range(i + 1, len(matrix)):
        a, b = matrix[i], matrix[j]
        text_sim = cosine(vecs[i], vecs[j])
        src_overlap = len(set(a["data_sources"]) & set(b["data_sources"])) / max(len(set(a["data_sources"]) | set(b["data_sources"])), 1)
        act_overlap = len(set(a["actions"]) & set(b["actions"])) / max(len(set(a["actions"]) | set(b["actions"])), 1)
        combined = 0.5 * text_sim + 0.3 * src_overlap + 0.2 * act_overlap
        
        if combined >= 0.35:
            if combined >= 0.7: rec = "考虑合并或弃用其中一个"
            elif combined >= 0.5: rec = "明确优先级，标记 primary/alternative"
            else: rec = "补充文档，说明使用场景差异"
            overlaps.append({
                "skill_a": a["name"], "skill_b": b["name"],
                "similarity": round(combined, 3),
                "text_sim": round(text_sim, 3),
                "shared_sources": list(set(a["data_sources"]) & set(b["data_sources"])),
                "shared_actions": list(set(a["actions"]) & set(b["actions"])),
                "recommendation": rec,
            })

overlaps.sort(key=lambda x: -x["similarity"])

(DATA / "overlaps-detected.json").write_text(json.dumps({
    "generated_at": "2026-06-17",
    "threshold": 0.35,
    "total_overlaps": len(overlaps),
    "high_severity": sum(1 for o in overlaps if o["similarity"] >= 0.7),
    "medium_severity": sum(1 for o in overlaps if 0.5 <= o["similarity"] < 0.7),
    "low_severity": sum(1 for o in overlaps if o["similarity"] < 0.5),
    "overlaps": overlaps,
}, indent=2, ensure_ascii=False))

# 摘要
print(f"=== Skills Matrix ===")
print(f"Total skills: {len(matrix)}")
print(f"Preferred: {sum(1 for m in matrix if m['priority'] == 'preferred')}")
print(f"Deprecated: {sum(1 for m in matrix if m['priority'] == 'deprecated')}")
print(f"Undocumented (in runtime, not in AGENTS.md): {sum(1 for m in matrix if m['priority'] == 'undocumented')}")
print()
print(f"=== Overlaps (similarity >= 0.35) ===")
print(f"Total: {len(overlaps)}")
print(f"High (>=0.7): {sum(1 for o in overlaps if o['similarity'] >= 0.7)}")
print(f"Medium (0.5-0.7): {sum(1 for o in overlaps if 0.5 <= o['similarity'] < 0.7)}")
print(f"Low (0.35-0.5): {sum(1 for o in overlaps if o['similarity'] < 0.5)}")
print()
print("=== Top 15 Overlaps ===")
for o in overlaps[:15]:
    print(f"  {o['similarity']:.2f}  {o['skill_a']:35s} <-> {o['skill_b']:35s}  [{','.join(o['shared_sources'])}]")

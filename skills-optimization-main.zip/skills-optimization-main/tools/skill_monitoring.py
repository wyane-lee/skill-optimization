#!/usr/bin/env python3
"""
Skill 监控 Agent 集成接口

提供 Python API 让 Agent 可以调用监控功能，自动提供 execution_id。
"""

import os
import json
import subprocess
import uuid
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict, Any, List


class SkillMonitoring:
    """Skill 监控工具 - Agent 集成接口"""
    
    def __init__(self):
        """初始化监控工具"""
        self.base_dir = Path.home() / ".config" / "opencode" / "skills" / "skill-monitoring"
        self.executions_dir = Path.home() / ".opencode" / "skill-executions"
        self.executions_dir.mkdir(parents=True, exist_ok=True)
        
    def generate_execution_id(self) -> str:
        """生成唯一的执行 ID"""
        return f"exec_{uuid.uuid4().hex[:12]}_{int(datetime.now().timestamp())}"
    
    def setup(self, execution_id: Optional[str] = None) -> Dict[str, Any]:
        """
        一键启动监控机制
        
        Args:
            execution_id: 执行 ID（如果为 None，自动生成）
        
        Returns:
            执行结果字典
        """
        if execution_id is None:
            execution_id = self.generate_execution_id()
        
        exec_dir = self.executions_dir / execution_id
        exec_dir.mkdir(parents=True, exist_ok=True)
        
        try:
            script = self.base_dir / "scripts" / "setup-skill-monitoring.sh"
            if not script.exists():
                return {
                    "status": "error",
                    "execution_id": execution_id,
                    "error": f"Setup script not found: {script}",
                    "timestamp": datetime.now().isoformat()
                }
            
            result = subprocess.run(
                ["bash", str(script)],
                capture_output=True,
                text=True,
                timeout=300
            )
            
            output = {
                "status": "success" if result.returncode == 0 else "error",
                "execution_id": execution_id,
                "returncode": result.returncode,
                "stdout": result.stdout,
                "stderr": result.stderr,
                "timestamp": datetime.now().isoformat()
            }
            
            # 保存执行日志
            self._save_execution_log(execution_id, output)
            
            return output
            
        except subprocess.TimeoutExpired:
            return {
                "status": "error",
                "execution_id": execution_id,
                "error": "Setup timeout (>300s)",
                "timestamp": datetime.now().isoformat()
            }
        except Exception as e:
            return {
                "status": "error",
                "execution_id": execution_id,
                "error": str(e),
                "timestamp": datetime.now().isoformat()
            }
    
    def watch(self, execution_id: Optional[str] = None, lines: int = 50) -> Dict[str, Any]:
        """
        实时监控执行日志
        
        Args:
            execution_id: 执行 ID（如果为 None，监控最新执行）
            lines: 显示的日志行数
        
        Returns:
            日志内容字典
        """
        if execution_id is None:
            # 获取最新的执行 ID
            execution_id = self._get_latest_execution_id()
        
        if execution_id is None:
            return {
                "status": "error",
                "error": "No execution found",
                "timestamp": datetime.now().isoformat()
            }
        
        try:
            script = self.base_dir / "scripts" / "skill-watch.sh"
            if not script.exists():
                return {
                    "status": "error",
                    "execution_id": execution_id,
                    "error": f"Watch script not found: {script}",
                    "timestamp": datetime.now().isoformat()
                }
            
            result = subprocess.run(
                ["bash", str(script), execution_id, str(lines)],
                capture_output=True,
                text=True,
                timeout=30
            )
            
            return {
                "status": "success" if result.returncode == 0 else "error",
                "execution_id": execution_id,
                "logs": result.stdout,
                "errors": result.stderr if result.stderr else None,
                "timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            return {
                "status": "error",
                "execution_id": execution_id,
                "error": str(e),
                "timestamp": datetime.now().isoformat()
            }
    
    def dashboard(self) -> Dict[str, Any]:
        """
        显示实时仪表板
        
        Returns:
            仪表板数据字典
        """
        try:
            script = self.base_dir / "scripts" / "skill-dashboard.sh"
            if not script.exists():
                return {
                    "status": "error",
                    "error": f"Dashboard script not found: {script}",
                    "timestamp": datetime.now().isoformat()
                }
            
            result = subprocess.run(
                ["bash", str(script)],
                capture_output=True,
                text=True,
                timeout=30
            )
            
            return {
                "status": "success" if result.returncode == 0 else "error",
                "dashboard": result.stdout,
                "errors": result.stderr if result.stderr else None,
                "timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            return {
                "status": "error",
                "error": str(e),
                "timestamp": datetime.now().isoformat()
            }
    
    def report(self, execution_id: Optional[str] = None) -> Dict[str, Any]:
        """
        生成执行报告
        
        Args:
            execution_id: 执行 ID（如果为 None，生成最新执行的报告）
        
        Returns:
            报告数据字典
        """
        if execution_id is None:
            execution_id = self._get_latest_execution_id()
        
        if execution_id is None:
            return {
                "status": "error",
                "error": "No execution found",
                "timestamp": datetime.now().isoformat()
            }
        
        try:
            script = self.base_dir / "scripts" / "skill-report.sh"
            if not script.exists():
                return {
                    "status": "error",
                    "execution_id": execution_id,
                    "error": f"Report script not found: {script}",
                    "timestamp": datetime.now().isoformat()
                }
            
            result = subprocess.run(
                ["bash", str(script), execution_id],
                capture_output=True,
                text=True,
                timeout=30
            )
            
            # 尝试解析 JSON 报告
            report_data = None
            try:
                report_data = json.loads(result.stdout)
            except json.JSONDecodeError:
                pass
            
            return {
                "status": "success" if result.returncode == 0 else "error",
                "execution_id": execution_id,
                "report": report_data or result.stdout,
                "errors": result.stderr if result.stderr else None,
                "timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            return {
                "status": "error",
                "execution_id": execution_id,
                "error": str(e),
                "timestamp": datetime.now().isoformat()
            }
    
    def get_execution_status(self, execution_id: str) -> Dict[str, Any]:
        """
        获取执行状态
        
        Args:
            execution_id: 执行 ID
        
        Returns:
            执行状态字典
        """
        exec_dir = self.executions_dir / execution_id
        
        if not exec_dir.exists():
            return {
                "status": "not_found",
                "execution_id": execution_id,
                "timestamp": datetime.now().isoformat()
            }
        
        try:
            # 读取执行报告
            report_file = exec_dir / "execution-report.json"
            if report_file.exists():
                with open(report_file) as f:
                    report = json.load(f)
                return {
                    "status": "success",
                    "execution_id": execution_id,
                    "report": report,
                    "timestamp": datetime.now().isoformat()
                }
            
            # 读取执行日志
            log_file = exec_dir / "execution.log"
            if log_file.exists():
                with open(log_file) as f:
                    logs = f.read()
                return {
                    "status": "running",
                    "execution_id": execution_id,
                    "logs": logs,
                    "timestamp": datetime.now().isoformat()
                }
            
            return {
                "status": "pending",
                "execution_id": execution_id,
                "timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            return {
                "status": "error",
                "execution_id": execution_id,
                "error": str(e),
                "timestamp": datetime.now().isoformat()
            }
    
    def list_executions(self, limit: int = 10) -> Dict[str, Any]:
        """
        列出最近的执行
        
        Args:
            limit: 返回的最大执行数
        
        Returns:
            执行列表字典
        """
        try:
            executions = []
            
            if self.executions_dir.exists():
                # 获取所有执行目录
                exec_dirs = sorted(
                    self.executions_dir.iterdir(),
                    key=lambda x: x.stat().st_mtime,
                    reverse=True
                )[:limit]
                
                for exec_dir in exec_dirs:
                    execution_id = exec_dir.name
                    
                    # 读取报告或日志
                    report_file = exec_dir / "execution-report.json"
                    if report_file.exists():
                        with open(report_file) as f:
                            report = json.load(f)
                        executions.append({
                            "execution_id": execution_id,
                            "status": report.get("status", "unknown"),
                            "timestamp": report.get("timestamp"),
                            "duration": report.get("duration")
                        })
                    else:
                        executions.append({
                            "execution_id": execution_id,
                            "status": "running",
                            "timestamp": datetime.fromtimestamp(
                                exec_dir.stat().st_mtime
                            ).isoformat()
                        })
            
            return {
                "status": "success",
                "executions": executions,
                "count": len(executions),
                "timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            return {
                "status": "error",
                "error": str(e),
                "timestamp": datetime.now().isoformat()
            }
    
    def _save_execution_log(self, execution_id: str, output: Dict[str, Any]) -> None:
        """保存执行日志"""
        exec_dir = self.executions_dir / execution_id
        exec_dir.mkdir(parents=True, exist_ok=True)
        
        log_file = exec_dir / "execution.log"
        with open(log_file, "w") as f:
            f.write(json.dumps(output, indent=2, ensure_ascii=False))
    
    def _get_latest_execution_id(self) -> Optional[str]:
        """获取最新的执行 ID"""
        if not self.executions_dir.exists():
            return None
        
        exec_dirs = list(self.executions_dir.iterdir())
        if not exec_dirs:
            return None
        
        latest = max(exec_dirs, key=lambda x: x.stat().st_mtime)
        return latest.name


# 便捷函数 - 让 Agent 可以直接调用
def setup_monitoring(execution_id: Optional[str] = None) -> Dict[str, Any]:
    """一键启动监控"""
    monitor = SkillMonitoring()
    return monitor.setup(execution_id)


def watch_monitoring(execution_id: Optional[str] = None, lines: int = 50) -> Dict[str, Any]:
    """实时监控"""
    monitor = SkillMonitoring()
    return monitor.watch(execution_id, lines)


def show_dashboard() -> Dict[str, Any]:
    """显示仪表板"""
    monitor = SkillMonitoring()
    return monitor.dashboard()


def generate_report(execution_id: Optional[str] = None) -> Dict[str, Any]:
    """生成报告"""
    monitor = SkillMonitoring()
    return monitor.report(execution_id)


def get_status(execution_id: str) -> Dict[str, Any]:
    """获取执行状态"""
    monitor = SkillMonitoring()
    return monitor.get_execution_status(execution_id)


def list_recent_executions(limit: int = 10) -> Dict[str, Any]:
    """列出最近的执行"""
    monitor = SkillMonitoring()
    return monitor.list_executions(limit)


if __name__ == "__main__":
    # 测试脚本
    monitor = SkillMonitoring()
    
    print("=" * 60)
    print("Skill 监控 Agent 集成接口")
    print("=" * 60)
    
    # 生成执行 ID
    execution_id = monitor.generate_execution_id()
    print(f"\n✅ 生成执行 ID: {execution_id}")
    
    # 列出最近的执行
    print("\n📋 最近的执行:")
    result = monitor.list_executions(5)
    if result["status"] == "success":
        for exec_info in result["executions"]:
            print(f"  - {exec_info['execution_id']}: {exec_info['status']}")
    
    print("\n✅ Agent 集成接口已就绪")

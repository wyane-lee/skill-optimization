# 项目索引：AI Agent Skills 调用优化系统

## 🎯 项目目标

解决 AI Agent 中 Skills 功能重叠导致调用失效的问题，通过构建结构化的 Skills 管理系统来提升 Agent 的 Skill 选择准确率和调用成功率。

---

## 📚 文档导航

### 快速开始
1. **[QUICK-REFERENCE.md](QUICK-REFERENCE.md)** — 快速参考卡片（5 分钟快速了解）
2. **[README.md](README.md)** — 项目说明（10 分钟了解项目）
3. **[DELIVERABLES.md](DELIVERABLES.md)** — 交付清单（查看已完成的工作）

### 深入理解
4. **[PROJECT-OVERVIEW.md](PROJECT-OVERVIEW.md)** — 完整架构设计（30 分钟深入理解）
5. **[PROJECT-SUMMARY.md](PROJECT-SUMMARY.md)** — 项目完成总结（20 分钟了解成果）

### 技术细节
6. **[docs/SKILL-EXECUTION-VERIFICATION.md](docs/SKILL-EXECUTION-VERIFICATION.md)** — 验证机制设计（40 分钟学习验证框架）
7. **[rpi/skills-dedup-system/research.md](rpi/skills-dedup-system/research.md)** — 问题分析（15 分钟了解问题）
8. **[rpi/skills-dedup-system/plan.md](rpi/skills-dedup-system/plan.md)** — 解决方案设计（20 分钟了解方案）

### 项目管理
9. **[STATUS.md](STATUS.md)** — 进度跟踪（实时项目状态）

---

## 📊 数据文件

### 核心数据
| 文件 | 大小 | 说明 |
|------|------|------|
| [data/skills-inventory.json](data/skills-inventory.json) | 110 KB | 73 个 Skills 的完整库存 |
| [data/skills-matrix.json](data/skills-matrix.json) | 49 KB | Skills 功能矩阵（维度：data_sources, actions, priority） |
| [data/overlaps-detected.json](data/overlaps-detected.json) | 24 KB | 73 对重叠分析（8 中等，65 低） |
| [data/skills-documentation.json](data/skills-documentation.json) | 22 KB | AGENTS.md 中的 Skills 文档 |

### 数据统计
```
总 Skills：73
├── 已文档化（AGENTS.md）：64
├── 未文档化（runtime）：15
├── PREFERRED：1（second-brain）
├── deprecated：2
└── 重叠对：73（8 中等，65 低）
```

---

## 🛠️ 工具脚本

### 1. 矩阵构建 + 重叠检测
**文件**：[tools/build-matrix-and-detect.py](tools/build-matrix-and-detect.py)  
**用途**：生成 Skills 功能矩阵和重叠分析  
**使用**：
```bash
python3 tools/build-matrix-and-detect.py
```
**输出**：
- `data/skills-matrix.json` — 功能矩阵
- `data/overlaps-detected.json` — 重叠分析

### 2. Skill 执行验证框架
**文件**：[tools/skill-execution-verifier.py](tools/skill-execution-verifier.py)  
**用途**：验证 Skill 是否真正执行  
**使用**：
```python
from tools.skill_execution_verifier import SkillExecutionValidator

result = SkillExecutionValidator.validate_skill_call(
    skill_name="second-brain",
    user_request="搜索关于 ISE 的 Webex 讨论",
    preconditions={...},
    tool_calls=[...],
    output={...},
)
```
**输出**：`~/.opencode/skill-executions/{execution_id}/`

---

## 🔍 关键发现

### 最严重的重叠（Top 5）
| 相似度 | Skill A | Skill B | 建议 |
|--------|---------|---------|------|
| 0.63 | cisco-branding | cisco-html-report | 明确边界 |
| 0.57 | github-repo-management | wwwin-github-search | 标记优先级 |
| 0.52 | github-pages-hosting | github-repo-management | 补充文档 |
| 0.51 | radkit-grant-access | radkit-management | 整合工具族 |
| 0.51 | radkit-device-inventory | radkit-swagger-api | 明确边界 |

### 优先级体系缺失
- ✅ PREFERRED：1 个（second-brain）
- ⚠️ standard：71 个（无标记）
- ⚠️ deprecated：2 个（email-rag 等）

### 文档化不完整
- ✅ 已文档化：64 个（AGENTS.md）
- ⚠️ 未文档化：15 个（runtime 存在但未在 AGENTS.md 中）

---

## 🚀 立即可用的功能

### 1. 查看 Skills 矩阵
```bash
# 查看所有 Skills 的优先级和数据源
cat data/skills-matrix.json | jq '.skills[] | {name, priority, data_sources}'

# 查看特定 Skill
cat data/skills-matrix.json | jq '.skills[] | select(.name == "second-brain")'
```

### 2. 查看重叠分析
```bash
# 查看所有中等重叠
cat data/overlaps-detected.json | jq '.overlaps[] | select(.similarity >= 0.5)'

# 查看特定 Skill 的重叠
cat data/overlaps-detected.json | jq '.overlaps[] | select(.skill_a == "cisco-branding")'
```

### 3. 验证 Skill 执行
```python
from tools.skill_execution_verifier import SkillExecutionValidator

# 验证 Skill 调用
result = SkillExecutionValidator.validate_skill_call(...)

# 查看执行日志
cat ~/.opencode/skill-executions/{execution_id}/execution.log
```

### 4. 生成新的分析
```bash
# 重新生成矩阵和重叠分析
python3 tools/build-matrix-and-detect.py
```

---

## 📖 使用场景

### 场景 1：Agent 选择 Skill
**问题**：Agent 不知道选哪个 Skill  
**解决**：
1. 查看 `data/skills-matrix.json` 中的优先级
2. 选择 priority 为 "preferred" 的 Skill
3. 确认 data_sources 和 actions 匹配

**示例**：
```bash
# 查看搜索类 Skills
cat data/skills-matrix.json | jq '.skills[] | select(.actions[] == "search")'
```

### 场景 2：验证 Skill 执行
**问题**：不知道 Skill 是否真的执行了  
**解决**：
1. 使用 skill-execution-verifier.py 验证
2. 查看 `~/.opencode/skill-executions/{execution_id}/` 中的日志
3. 检查验证报告

**示例**：
```python
result = SkillExecutionValidator.validate_skill_call(...)
if result["status"] == "success":
    print(f"Skill 执行成功，execution_id: {result['execution_id']}")
else:
    print(f"Skill 执行失败：{result['reason']}")
```

### 场景 3：处理 Skill 重叠
**问题**：多个 Skill 都能做同一件事  
**解决**：
1. 查看 `data/overlaps-detected.json` 中的重叠分析
2. 选择 priority 最高的 Skill
3. 如果失败，尝试替代 Skill

**示例**：
```bash
# 查看 cisco-branding 的替代方案
cat data/overlaps-detected.json | jq '.overlaps[] | select(.skill_a == "cisco-branding")'
```

### 场景 4：新增 Skill 时检查重复
**问题**：新增 Skill 时不知道是否与现有 Skill 重复  
**解决**：
1. 运行 `python3 tools/build-matrix-and-detect.py`
2. 查看新 Skill 的重叠分析
3. 如果相似度 > 0.7，考虑合并或删除

---

## 🎓 学习路径

### 初级（15 分钟）
1. 阅读 [QUICK-REFERENCE.md](QUICK-REFERENCE.md)
2. 查看 `data/skills-matrix.json` 的结构
3. 运行一次 `skill-execution-verifier.py`

### 中级（1 小时）
1. 阅读 [PROJECT-OVERVIEW.md](PROJECT-OVERVIEW.md)
2. 理解三层验证架构
3. 学习如何使用重叠检测工具

### 高级（2 小时）
1. 阅读 [docs/SKILL-EXECUTION-VERIFICATION.md](docs/SKILL-EXECUTION-VERIFICATION.md)
2. 理解 Skill 选择算法
3. 学习如何集成验证框架到 Agent

---

## 🔗 相关资源

### 项目文件
- **项目目录**：`/Users/wenfeli/Documents/claude_projects/skills-optimization/`
- **数据目录**：`data/`
- **工具目录**：`tools/`
- **文档目录**：`docs/` 和 `rpi/`

### 外部资源
- **AGENTS.md**：`~/.config/opencode/AGENTS.md`
- **Skills 目录**：`~/.config/opencode/skills/`
- **执行日志**：`~/.opencode/skill-executions/`

---

## 📞 获取帮助

### 查看执行日志
```bash
# 查看最新执行的日志
ls -lt ~/.opencode/skill-executions/ | head -5

# 查看特定执行的日志
cat ~/.opencode/skill-executions/{execution_id}/execution.log
```

### 查看验证报告
```bash
# 查看验证报告
cat ~/.opencode/skill-executions/{execution_id}/execution-report.json | jq
```

### 查看 Skills 矩阵
```bash
# 查看所有 Skills
cat data/skills-matrix.json | jq '.skills | length'

# 查看特定类别的 Skills
cat data/skills-matrix.json | jq '.skills[] | select(.data_sources[] == "webex")'
```

---

## ✅ 项目状态

| 阶段 | 状态 | 完成度 |
|------|------|--------|
| Phase A：数据收集 | ✅ 完成 | 100% |
| Phase B：功能矩阵 | ✅ 完成 | 100% |
| Phase C：智能路由 | 🔄 设计完成 | 50% |
| Phase D：自动化工具 | 🔄 部分完成 | 50% |
| Phase E：文档交付 | ✅ 完成 | 100% |

---

## 🎯 下一步

### 立即（1 周内）
- [ ] 集成验证框架到 Agent 决策流程
- [ ] 更新 AGENTS.md 添加 15 个未文档化的 Skills
- [ ] 为所有 Skills 添加 priority 标记

### 短期（1-2 周）
- [ ] 创建 Agent 提示词（如何使用矩阵）
- [ ] 编写 Skills 使用指南
- [ ] 编写 Skills 维护指南

### 中期（1-2 个月）
- [ ] 实现智能路由引擎
- [ ] 建立 Skill 成功率追踪
- [ ] 优化重叠检测算法

---

## 📝 最后更新

- **项目启动**：2026-06-17
- **项目完成**：2026-06-17
- **最后更新**：2026-06-17
- **项目所有者**：wenfeli
- **项目状态**：✅ **完成**

---

**开始探索**：从 [QUICK-REFERENCE.md](QUICK-REFERENCE.md) 开始，5 分钟快速了解项目！

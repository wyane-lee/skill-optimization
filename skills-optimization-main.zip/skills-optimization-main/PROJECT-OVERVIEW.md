# 项目概览：AI Agent Skills 调用优化系统

## 执行摘要

### 问题陈述
AI Agent 安装了 150+ 个 Skills，存在以下问题：
1. **功能重叠** — 多个 Skills 提供相似功能
2. **调用失效** — Agent 无法有效驱动 Skills 的完整功能
3. **维护困难** — 新增 Skill 时难以判断是否重复

### 解决方案
构建一个三层系统来优化 Skills 管理和调用：
1. **数据层** — 统一的 Skills 元数据和分类
2. **分析层** — 功能矩阵和优先级排序
3. **应用层** — 智能路由引擎和 Agent 培训

### 预期成果
- ✅ 100% Skills 分类覆盖
- ✅ ≥95% 重叠检测准确率
- ✅ ≥90% Agent Skill 选择准确率
- ✅ <30 分钟新增 Skill 审查时间

---

## 项目架构

### 系统设计图

```
┌─────────────────────────────────────────────────────────────┐
│                    AI Agent 决策流程                         │
└─────────────────────────────────────────────────────────────┘
                              ↓
                    ┌─────────────────────┐
                    │  用户请求解析       │
                    │  (意图识别)         │
                    └─────────────────────┘
                              ↓
        ┌─────────────────────────────────────────────┐
        │         Skill 智能路由引擎 (C2)             │
        │  ┌──────────────────────────────────────┐  │
        │  │ 1. 功能匹配 (skills-matrix.json)    │  │
        │  │ 2. 优先级排序 (priority-ranking)    │  │
        │  │ 3. 替代方案推荐                     │  │
        │  └──────────────────────────────────────┘  │
        └─────────────────────────────────────────────┘
                              ↓
                    ┌─────────────────────┐
                    │  选择最优 Skill     │
                    │  + 替代方案         │
                    └─────────────────────┘
                              ↓
                    ┌─────────────────────┐
                    │  执行 Skill         │
                    │  (完整功能驱动)     │
                    └─────────────────────┘
```

### 数据流

```
Skills 源数据
├── ~/.config/opencode/skills/     (A1 扫描)
├── AGENTS.md                      (A2 提取)
└── 使用日志                       (D3 分析)
        ↓
    ┌─────────────────────────────┐
    │  数据层 (Phase A)           │
    │  - skills-inventory.json    │
    │  - skills-documentation.json│
    └─────────────────────────────┘
        ↓
    ┌─────────────────────────────┐
    │  分析层 (Phase B)           │
    │  - skills-matrix.json       │
    │  - overlaps-detected.json   │
    │  - priority-ranking.json    │
    └─────────────────────────────┘
        ↓
    ┌─────────────────────────────┐
    │  应用层 (Phase C)           │
    │  - skill-router.py          │
    │  - Agent 提示词             │
    └─────────────────────────────┘
        ↓
    ┌─────────────────────────────┐
    │  维护层 (Phase D)           │
    │  - 自动化检测工具           │
    │  - 健康检查工具             │
    │  - 使用统计分析             │
    └─────────────────────────────┘
        ↓
    ┌─────────────────────────────┐
    │  交付层 (Phase E)           │
    │  - 使用指南                 │
    │  - 培训提示词               │
    │  - 项目总结                 │
    └─────────────────────────────┘
```

---

## 核心组件详解

### 1. Skills 功能矩阵 (Phase B)

#### 维度定义

**维度 1：功能类别**
- 搜索/查询 (Search)
- 数据导出 (Export)
- 创建/生成 (Create)
- 管理/配置 (Manage)
- 分析/报告 (Analyze)
- 工具/集成 (Tool)

**维度 2：数据源**
- Webex
- 邮件 (Email)
- GitHub
- RADKit
- Salesforce
- CDETS
- TechZone
- 浏览器 (Browser)
- 文件系统 (Filesystem)
- 其他 (Other)

**维度 3：操作类型**
- 读 (Read)
- 写 (Write)
- 转换 (Transform)
- 验证 (Validate)
- 监控 (Monitor)

**维度 4：优先级**
- 首选 (Primary) — 该功能的最佳选择
- 备选 (Alternative) — 可用但不是最优
- 已弃用 (Deprecated) — 不推荐使用
- 实验 (Experimental) — 新增或测试中

#### 示例：Webex 相关 Skills 矩阵

| Skill | 功能类别 | 数据源 | 操作 | 优先级 | 说明 |
|-------|---------|--------|------|--------|------|
| `second-brain` | 搜索 | Webex+邮件+日历 | 读 | 首选 | 统一语义搜索，最强大 |
| `webex-rag-query` | 搜索 | Webex知识库 | 读 | 备选 | 特定知识库查询 |
| `webex-space-dump` | 导出 | Webex空间 | 读 | 首选 | 导出空间消息 |
| `webex-transcript-download` | 导出 | Webex会议 | 读 | 首选 | 下载会议记录 |
| `webex-calendar` | 查询 | Webex日历 | 读 | 首选 | 访问日历信息 |
| `directory-parser` | 查询 | Webex目录 | 读 | 首选 | 查询员工信息 |
| `email-rag` | 搜索 | 邮件 | 读 | 已弃用 | 使用 second-brain 替代 |

### 2. Skill 选择算法 (Phase C1)

#### 算法流程

```
输入：用户请求
  ↓
1. 意图识别
   - 提取关键词：动作、数据源、操作类型
   - 示例："搜索 Webex 中关于 ISE 的讨论"
     → 动作: 搜索, 数据源: Webex, 主题: ISE
  ↓
2. 功能匹配
   - 在 skills-matrix.json 中查找匹配的 Skills
   - 按优先级排序（首选 > 备选 > 已弃用）
   - 示例：匹配到 [second-brain, webex-rag-query]
  ↓
3. 优先级排序
   - 首选 Skill 排在前面
   - 考虑 Agent 的历史成功率
   - 示例：second-brain (首选) > webex-rag-query (备选)
  ↓
4. 替代方案推荐
   - 提供 2-3 个替代方案
   - 说明为什么首选更优
   - 示例：
     主选：second-brain (最强大的统一搜索)
     备选：webex-rag-query (仅限 Webex 知识库)
  ↓
输出：[首选 Skill, 替代方案列表, 选择理由]
```

#### 示例场景

**场景 1：搜索邮件**
```
用户："找一下关于 COAR 续期的邮件"

意图识别：
  - 动作: 搜索
  - 数据源: 邮件
  - 主题: COAR 续期

功能匹配：
  - second-brain (搜索, 邮件, 首选)
  - email-rag (搜索, 邮件, 已弃用)

输出：
  主选：second-brain
  备选：email-rag (已弃用，不推荐)
  理由：second-brain 是统一搜索的首选，支持邮件、Webex、日历等多源搜索
```

**场景 2：下载 Webex 会议记录**
```
用户："下载这个 Webex 会议的记录"

意图识别：
  - 动作: 导出
  - 数据源: Webex 会议
  - 操作: 下载

功能匹配：
  - webex-transcript-download (导出, Webex会议, 首选)
  - webex-space-dump (导出, Webex空间, 备选)

输出：
  主选：webex-transcript-download
  备选：webex-space-dump (用于导出空间消息，不是会议记录)
  理由：webex-transcript-download 专门用于下载会议记录和转录文本
```

**场景 3：RADKit 设备管理**
```
用户："添加一个新设备到 RADKit"

意图识别：
  - 动作: 管理
  - 数据源: RADKit
  - 操作: 创建

功能匹配：
  - radkit-device-inventory (管理, RADKit, 首选)
  - radkit-management (管理, RADKit, 备选)

输出：
  主选：radkit-device-inventory
  备选：radkit-management (通用管理，不如专用工具)
  理由：radkit-device-inventory 专门用于设备库存管理，功能更完整
```

### 3. 重叠检测工具 (Phase D1)

#### 检测方法

```python
# 伪代码
def detect_overlaps(skills_matrix):
    overlaps = []
    
    for skill_a in skills_matrix:
        for skill_b in skills_matrix:
            if skill_a.id < skill_b.id:  # 避免重复
                # 计算相似度
                similarity = calculate_similarity(
                    skill_a.description,
                    skill_b.description,
                    skill_a.triggers,
                    skill_b.triggers,
                    skill_a.dimensions,
                    skill_b.dimensions
                )
                
                if similarity > THRESHOLD:  # 0.7
                    overlaps.append({
                        'skill_a': skill_a.name,
                        'skill_b': skill_b.name,
                        'similarity': similarity,
                        'recommendation': recommend_action(skill_a, skill_b)
                    })
    
    return overlaps
```

#### 相似度计算

- **描述相似度** — 使用 TF-IDF + 余弦相似度
- **触发条件相似度** — 关键词匹配
- **维度重叠** — 共同的功能类别、数据源、操作类型
- **综合相似度** — 加权平均

#### 建议行动

| 相似度 | 建议 |
|--------|------|
| > 0.9 | 考虑合并或删除其中一个 |
| 0.7-0.9 | 明确优先级，标记为首选/备选 |
| 0.5-0.7 | 补充文档，说明使用场景差异 |
| < 0.5 | 无重叠，保持独立 |

---

## 实现时间表

### Week 1（第一周）
- **Day 1-2**：Phase A（数据收集）
  - A1：扫描 Skills 库存
  - A2：提取 Skills 文档
  - A3：构建矩阵模板

- **Day 3-4**：Phase B（功能矩阵）
  - B1：手工分类 20+ 关键 Skills
  - B2：识别功能重叠
  - B3：创建优先级排序

- **Day 5**：Phase B 完成
  - B4：生成可视化

### Week 2（第二周）
- **Day 1-2**：Phase C（智能路由）
  - C1：设计选择算法
  - C2：实现路由引擎
  - C3：创建提示词模板

- **Day 3**：Phase C 完成
  - C4：集成到 Agent

- **Day 4-5**：Phase D + E（工具和文档）
  - D1-D4：自动化工具
  - E1-E3：文档和培训

---

## 成功指标

### 定量指标
| 指标 | 目标 | 验证方法 |
|------|------|---------|
| Skills 分类覆盖率 | 100% | 检查 skills-matrix.json 中的 Skill 数量 |
| 重叠检测准确率 | ≥95% | 对比自动检测与手工审查结果 |
| Agent Skill 选择准确率 | ≥90% | 测试 50+ 个真实用户请求 |
| 新增 Skill 审查时间 | <30 分钟 | 使用维护指南审查新 Skill |

### 定性指标
| 指标 | 目标 | 验证方法 |
|------|------|---------|
| Agent 决策透明度 | 提供清晰的选择理由 | 用户反馈 |
| 文档完整性 | 覆盖所有常见场景 | 用户测试 |
| 系统可维护性 | 易于添加新 Skill | 新增 Skill 的审查流程 |

---

## 风险管理

### 高风险项

| 风险 | 概率 | 影响 | 缓解策略 |
|------|------|------|---------|
| B1 手工分类耗时过长 | 中 | 高 | 优先分类高频 Skills，其他使用自动化辅助 |
| Skills 数量增长快 | 中 | 中 | 建立自动化检测流程，定期更新矩阵 |
| Agent 不采纳新路由 | 低 | 中 | 在提示词中明确说明 Skill 选择的理由 |

### 低风险项

| 风险 | 概率 | 影响 | 缓解策略 |
|------|------|------|---------|
| 分类标准不一致 | 低 | 中 | 建立分类规范文档，由 oracle 审查 |
| 数据格式不一致 | 低 | 低 | 使用 JSON Schema 验证 |

---

## 后续工作

### 短期（1-2 周）
- ✅ 完成 Phase A-E 的所有任务
- ✅ 生成 Skills 功能矩阵和优先级排序
- ✅ 实现 Skill 选择路由引擎
- ✅ 编写 Skills 使用指南和维护指南

### 中期（1-2 个月）
- 在实际 Agent 会话中测试路由引擎
- 收集 Agent 和用户的反馈
- 优化 Skill 选择算法
- 更新 Skills 优先级排序

### 长期（持续）
- 定期更新 Skills 功能矩阵（每月）
- 监控新增 Skills 的重叠情况
- 改进自动化检测工具
- 维护 Skills 使用统计报告

---

## 相关资源

- **项目目录**：`/Users/wenfeli/Documents/claude_projects/skills-optimization/`
- **RPI 文档**：`rpi/skills-dedup-system/`
- **AGENTS.md**：`~/.config/opencode/AGENTS.md`
- **Skills 目录**：`~/.config/opencode/skills/`

---

**项目启动时间**：2026-06-17
**预计完成时间**：2026-06-24
**项目所有者**：wenfeli

# Plan: AI Agent Skills 调用优化系统

## 实现概述

构建一个三层系统来解决 Skills 调用失效问题：
1. **Skills 功能矩阵** — 结构化分类所有 Skills
2. **智能路由引擎** — 基于用户意图选择最优 Skill
3. **自动化检测工具** — 识别和报告功能重叠

## 任务分解

### Phase A：数据收集与分析（基础层）

- [ ] **A1** — 扫描 `~/.config/opencode/skills/` 目录，提取所有 Skills 元数据
  - 输入：Skills 目录结构
  - 输出：`skills-inventory.json`（包含名称、描述、触发条件、文件路径）
  - 验证：检查 JSON 完整性，确保覆盖 100% Skills

- [ ] **A2** — 从 AGENTS.md 提取 Skills 文档和分类信息
  - 输入：`~/.config/opencode/AGENTS.md`
  - 输出：`skills-documentation.json`（包含官方描述、分类、优先级）
  - 验证：对比 A1 和 A2 的 Skills 列表，确保一致性

- [ ] **A3** — 构建 Skills 功能矩阵数据结构
  - 输入：A1 + A2 的数据
  - 输出：`skills-matrix.json`（维度：功能类别、数据源、操作类型、优先级）
  - 验证：矩阵覆盖所有 Skills，每个 Skill 至少有 3 个维度标签

### Phase B：功能矩阵构建（核心层）

- [ ] **B1** — 手工分类关键 Skills（20+ 个）
  - 输入：`skills-inventory.json` + `skills-documentation.json`
  - 输出：`skills-matrix-manual.json`（手工标注的分类）
  - 验证：由 oracle 审查分类准确性

- [ ] **B2** — 识别功能重叠的 Skill 对
  - 输入：`skills-matrix-manual.json`
  - 输出：`overlaps-detected.json`（包含重叠 Skill 对、重叠程度、建议）
  - 验证：生成重叠报告，确保无遗漏

- [ ] **B3** — 创建 Skills 优先级排序
  - 输入：`overlaps-detected.json` + 使用频率数据
  - 输出：`skills-priority-ranking.json`（每个功能类别的首选/备选 Skill）
  - 验证：验证排序逻辑，确保首选 Skill 确实更优

- [ ] **B4** — 生成 Skills 功能矩阵可视化
  - 输入：`skills-matrix-manual.json`
  - 输出：`skills-matrix.html`（交互式矩阵表格）
  - 验证：在浏览器中验证可视化效果

### Phase C：智能路由引擎（应用层）

- [ ] **C1** — 设计 Skill 选择算法
  - 输入：用户请求、`skills-priority-ranking.json`
  - 输出：`skill-selection-algorithm.md`（算法设计文档）
  - 验证：算法覆盖 5+ 个常见场景

- [ ] **C2** — 实现 Skill 选择函数
  - 输入：`skill-selection-algorithm.md`
  - 输出：`skill-router.py`（Python 实现）
  - 验证：单元测试覆盖 ≥80%

- [ ] **C3** — 创建 Skill 选择提示词模板
  - 输入：`skills-priority-ranking.json`
  - 输出：`skill-selection-prompt.md`（Agent 使用的提示词）
  - 验证：提示词清晰、无歧义

- [ ] **C4** — 集成到 Agent 决策流程
  - 输入：`skill-router.py` + `skill-selection-prompt.md`
  - 输出：修改后的 Agent 配置
  - 验证：Agent 能正确调用路由引擎

### Phase D：自动化检测工具（维护层）

- [ ] **D1** — 开发 Skills 重叠检测脚本
  - 输入：`skills-inventory.json` + `skills-documentation.json`
  - 输出：`overlap-detector.py`（自动检测工具）
  - 验证：检测结果与手工分析一致

- [ ] **D2** — 创建 Skills 健康检查工具
  - 输入：所有 Skills 文件
  - 输出：`skills-health-check.py`（检查缺失文档、触发条件等）
  - 验证：能识别 5+ 种常见问题

- [ ] **D3** — 生成 Skills 使用统计报告
  - 输入：Agent 会话日志
  - 输出：`skills-usage-report.html`（使用频率、成功率等）
  - 验证：报告包含 ≥10 个关键指标

- [ ] **D4** — 创建 Skills 维护指南
  - 输入：B1-B3 的分析结果
  - 输出：`SKILLS-MAINTENANCE.md`（新增 Skill 时的检查清单）
  - 验证：指南覆盖所有重叠检测场景

### Phase E：文档与培训（交付层）

- [ ] **E1** — 编写 Skills 使用指南
  - 输入：`skills-matrix.html` + `skills-priority-ranking.json`
  - 输出：`SKILLS-GUIDE.md`（按场景的 Skill 选择指南）
  - 验证：覆盖 20+ 个常见用户场景

- [ ] **E2** — 创建 Agent 培训提示词
  - 输入：`skills-matrix.json` + `skill-selection-algorithm.md`
  - 输出：`agent-training-prompt.md`（Agent 学习如何选择 Skill）
  - 验证：提示词能有效改进 Agent 的 Skill 选择

- [ ] **E3** — 生成项目总结报告
  - 输入：所有前期阶段的输出
  - 输出：`PROJECT-SUMMARY.md`（项目成果、关键发现、建议）
  - 验证：报告清晰、可操作

## 代码参考

### 受影响的文件
- `~/.config/opencode/skills/` — Skills 目录（读取）
- `~/.config/opencode/opencode.json` — Skills 配置（读取）
- `~/.config/opencode/AGENTS.md` — Skills 文档（读取）
- `~/.config/opencode/skills/agent-sort/SKILL.md` — 参考现有 Skill 分类方法

### 新增文件
- `skills-optimization/` — 项目目录
  - `data/` — 数据文件（JSON）
  - `tools/` — 工具脚本（Python）
  - `docs/` — 文档（Markdown）
  - `reports/` — 报告（HTML）

## 测试计划

### A 阶段测试
- [ ] 验证 `skills-inventory.json` 包含所有 Skills
- [ ] 验证 `skills-documentation.json` 与 AGENTS.md 一致

### B 阶段测试
- [ ] 手工审查 20+ Skills 的分类准确性
- [ ] 验证重叠检测覆盖所有已知重叠对
- [ ] 验证优先级排序的合理性

### C 阶段测试
- [ ] 单元测试：`skill-router.py` 覆盖 ≥80%
- [ ] 集成测试：50+ 个真实用户请求的 Skill 选择准确率 ≥90%
- [ ] Agent 测试：验证 Agent 能正确使用路由引擎

### D 阶段测试
- [ ] 验证自动检测结果与手工分析一致
- [ ] 验证健康检查工具能识别已知问题
- [ ] 验证使用统计报告的准确性

### E 阶段测试
- [ ] 用户反馈：20+ 个用户测试使用指南的有效性
- [ ] Agent 反馈：Agent 使用培训提示词后的改进程度

## FACTS 评分

| 维度 | 分数 | 理由 |
|------|------|------|
| **Feasible** | 4 | 任务明确，工具和数据可获得，但需要手工分类工作 |
| **Actionable** | 5 | 每个任务都有清晰的输入、输出和验证标准 |
| **Completeness** | 4 | 覆盖问题的三个层面（检测、路由、维护），但可能遗漏边界情况 |
| **Testable** | 5 | 每个任务都有明确的测试标准 |
| **Sequenced** | 4 | 任务有清晰的依赖关系，但 B 阶段的手工工作可能成为瓶颈 |
| **Mean** | **4.40** | ✓ 通过 FACTS 验证（≥3.0） |

## 依赖关系与顺序

```
A1 → A2 → A3 ↓
           ↓
B1 ← A3 → B2 → B3 → B4
           ↓
C1 ← B3 → C2 → C3 → C4
           ↓
D1 ← A3 → D2 → D3 → D4
           ↓
E1 ← B4 + C3 + D4 → E2 → E3
```

**关键路径**：A1 → A2 → A3 → B1 → B2 → B3 → C1 → C2 → C3 → C4 → E3

## 风险缓解

| 风险 | 概率 | 影响 | 缓解策略 |
|------|------|------|---------|
| B1 手工分类耗时过长 | 中 | 高 | 优先分类高频 Skills，其他使用自动化辅助 |
| Skills 数量增长快 | 中 | 中 | 建立自动化检测流程，定期更新矩阵 |
| Agent 不采纳新路由 | 低 | 中 | 在提示词中明确说明 Skill 选择的理由 |
| 分类标准不一致 | 低 | 中 | 建立分类规范文档，由 oracle 审查 |

## 回滚策略

- **A 阶段失败** — 删除生成的 JSON 文件，重新扫描
- **B 阶段失败** — 恢复到 A3 的数据，重新分类
- **C 阶段失败** — 保留现有 Agent 配置，不集成路由引擎
- **D 阶段失败** — 保留手工分类结果，跳过自动化工具
- **E 阶段失败** — 保留前期文档，重新编写指南

---

**计划完成时间**：2026-06-17
**预计实现时间**：5-7 天（取决于 B1 的手工工作量）
**下一步**：进入 Implement 阶段，执行所有任务

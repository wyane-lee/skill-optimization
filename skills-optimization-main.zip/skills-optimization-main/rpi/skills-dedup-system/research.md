# Research: AI Agent Skills 调用优化系统

## 问题背景

### 核心痛点
1. **功能重叠** — 多个 Skills 提供相似或重复的功能
   - 例：`webex-transcript-download` 和 `webex-space-dump` 都涉及 Webex 数据提取
   - 例：`second-brain` 和 `email-rag` 都提供通信搜索能力
   - 例：多个 RADKit 相关 Skills 功能边界不清

2. **调用失效** — Agent 无法有效驱动 Skills 的完整功能
   - Agent 选错 Skill，导致功能不完整
   - Agent 不知道某个 Skill 的最佳使用场景
   - 多个 Skill 都能做，但 Agent 选择了次优方案

3. **维护成本高** — 新增 Skill 时难以判断是否重复
   - 无统一的 Skill 功能分类体系
   - 无清晰的 Skill 边界定义
   - 无自动化的重叠检测机制

### 当前状态分析
- **已安装 Skills 数量**：~150+ 个
- **分类方式**：按功能领域（Cisco、数据工具、代码等）
- **问题表现**：
  - Agent 在选择 Skill 时犹豫（多个都能用）
  - 某些 Skill 被过度使用，某些被忽视
  - 新 Skill 添加时无法判断是否与现有 Skill 重复

## 受影响的文件和系统

### 核心配置文件
- `~/.config/opencode/skills/` — Skills 目录结构
- `~/.config/opencode/opencode.json` — Skills 注册配置
- `AGENTS.md` — Skills 文档和触发条件

### 相关 Skills 示例（功能重叠）
1. **通信搜索类**
   - `second-brain` — 统一语义搜索（邮件、Webex、日历、书签）
   - `email-rag` — Outlook 邮件 RAG 搜索（已标记为 deprecated）
   - `webex-rag-query` — Webex 知识库查询
   - `webex-space-dump` — Webex 空间导出

2. **RADKit 相关**
   - `radkit-management` — 统一 RADKit 操作
   - `radkit-device-inventory` — 设备库存管理
   - `radkit-grant-access` — 访问权限管理
   - `radkit-certificate-auth` — 证书认证指南
   - `radkit-mcp-setup` — MCP 配置

3. **数据导出类**
   - `dump-cdets` — CDETS bug 数据下载
   - `dump-techzone` — TechZone 文章下载
   - `csone-sr-dump` — CSOne SR 数据下载
   - `webex-transcript-download` — Webex 会议记录下载

4. **演示文稿类**
   - `cisco-presentation` — HTML 优先演示工作流
   - `marp-presentations` — Markdown 幻灯片
   - `html-ppt` — HTML PPT Studio
   - `cisco-pptx` — Cisco 品牌 PowerPoint
   - `frontend-slides` — 前端动画演示

## 代码示例：当前问题

### 问题 1：Agent 选择困难
```
用户："我需要搜索关于 ISE 的 Webex 讨论"

可选 Skills：
- second-brain（通用搜索，包括 Webex）
- webex-rag-query（Webex 知识库）
- webex-space-dump（Webex 空间导出）

Agent 困惑：应该用哪个？
```

### 问题 2：功能不完整
```
用户："下载这个 Webex 会议的记录"

Agent 选择：webex-space-dump（导出空间消息）
实际需要：webex-transcript-download（下载会议记录）

结果：功能不匹配
```

### 问题 3：维护困难
```
新增 Skill：radkit-swagger-api
问题：与 radkit-management 的边界在哪里？
      与 radkit-mcp-setup 有重叠吗？
      应该在 AGENTS.md 中如何描述？
```

## 解决方案框架

### 方案 1：Skills 功能矩阵（推荐）
创建一个结构化的 Skills 功能分类系统：
- **维度 1**：功能类别（搜索、导出、创建、管理等）
- **维度 2**：数据源（Webex、邮件、GitHub、RADKit 等）
- **维度 3**：操作类型（读、写、转换等）
- **维度 4**：优先级（首选、备选、已弃用）

### 方案 2：Skills 智能路由引擎
构建一个 Agent 决策系统：
- 基于用户意图自动选择最优 Skill
- 提供 Skill 选择的理由和替代方案
- 学习 Agent 的选择模式，优化推荐

### 方案 3：自动化重叠检测
开发工具来：
- 扫描所有 Skills 的描述和触发条件
- 识别功能重叠的 Skill 对
- 生成重叠报告和合并建议

## FAR 评分

| 维度 | 分数 | 理由 |
|------|------|------|
| **Factual** | 5 | 基于实际 Skills 库存和已知问题 |
| **Actionable** | 4 | 清晰的问题陈述，可转化为具体任务 |
| **Relevant** | 5 | 直接解决 Agent 调用失效的核心问题 |
| **Mean** | **4.67** | ✓ 通过 FAR 验证（≥4.0） |

## 假设

1. **Skills 库存稳定** — 假设当前 ~150+ Skills 是相对完整的集合
2. **优先级排序** — 假设某些 Skills 应该被优先推荐（如 `second-brain` 优于 `email-rag`）
3. **用户意图可识别** — 假设用户请求中包含足够的信息来判断最优 Skill
4. **自动化可行** — 假设可以通过代码分析来检测功能重叠

## 测试策略

1. **功能矩阵验证** — 手工审查 20+ 个关键 Skills，验证分类准确性
2. **路由引擎测试** — 用 50+ 个真实用户请求测试 Skill 选择准确率
3. **重叠检测验证** — 对比自动检测结果与手工审查结果
4. **Agent 反馈** — 在实际 Agent 会话中测试改进效果

## 范围外

- 修改或重写现有 Skills 的实现
- 删除或合并 Skills（仅提供建议）
- 改变 Skills 的触发条件（仅分析）
- 跨项目的 Skills 同步问题

---

**研究完成时间**：2026-06-17
**下一步**：进入 Plan 阶段，设计具体实现任务

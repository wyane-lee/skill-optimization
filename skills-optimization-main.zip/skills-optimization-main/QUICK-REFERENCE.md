# 快速参考：Agent Skills 调用优化

## 🎯 核心问题与解决方案

### 问题 1：Skills 功能重叠
**症状**：Agent 不知道选哪个 Skill  
**解决**：Skills 功能矩阵 + 智能路由  
**数据**：73 Skills，8 对中等重叠已识别

### 问题 2：无法确保 Skills 真正执行
**症状**：Skill 调用了但不知道是否真的执行  
**解决**：三层验证架构（执行前/中/后）  
**工具**：skill-execution-verifier.py

### 问题 3：维护困难
**症状**：新增 Skill 时无法判断是否重复  
**解决**：自动化重叠检测 + 维护指南  
**脚本**：build-matrix-and-detect.py

---

## 📊 关键数据

```
总 Skills：73
├── 已文档化：64（AGENTS.md）
├── 未文档化：15（runtime 存在）
├── PREFERRED：1（second-brain）
├── deprecated：2
└── 重叠对：73（8 个中等，65 个低）
```

---

## 🔍 最严重的重叠（需要处理）

| Skill A | Skill B | 相似度 | 建议 |
|---------|---------|--------|------|
| cisco-branding | cisco-html-report | 0.63 | 明确边界 |
| github-repo-management | wwwin-github-search | 0.57 | 标记优先级 |
| github-pages-hosting | github-repo-management | 0.52 | 补充文档 |
| radkit-grant-access | radkit-management | 0.51 | 整合工具族 |
| radkit-device-inventory | radkit-swagger-api | 0.51 | 明确边界 |

---

## ✅ Agent 调用 Skills 的检查清单

### 选择 Skill 时
- [ ] 查看 skills-matrix.json 中的优先级
- [ ] 确认 data_sources 和 actions 匹配用户请求
- [ ] 优先选择 PREFERRED Skills
- [ ] 避免使用 deprecated Skills

### 调用 Skill 时
- [ ] 验证前置条件（token、权限等）
- [ ] 记录 execution_id 用于追踪
- [ ] 检查工具是否返回了结果
- [ ] 验证输出格式和完整性

### 处理失败时
- [ ] 查看 ~/.opencode/skill-executions/{execution_id}/ 中的日志
- [ ] 从 overlaps-detected.json 中查找替代 Skill
- [ ] 重试或升级为人工处理
- [ ] 记录失败原因用于改进

---

## 🛠️ 可用工具

### 1. 执行验证框架
```bash
python3 tools/skill-execution-verifier.py
```
输出：`~/.opencode/skill-executions/{execution_id}/`

### 2. 重叠检测
```bash
python3 tools/build-matrix-and-detect.py
```
输出：`data/skills-matrix.json` + `data/overlaps-detected.json`

### 3. 查看 Skills 矩阵
```bash
cat data/skills-matrix.json | jq '.skills[] | {name, priority, data_sources, actions}'
```

### 4. 查看重叠分析
```bash
cat data/overlaps-detected.json | jq '.overlaps[] | select(.similarity >= 0.5)'
```

---

## 📚 文档导航

| 文档 | 用途 |
|------|------|
| research.md | 问题分析（为什么有这个问题） |
| plan.md | 解决方案设计（如何解决） |
| SKILL-EXECUTION-VERIFICATION.md | 验证机制详解 |
| PROJECT-OVERVIEW.md | 完整的架构和时间表 |
| 本文档 | 快速参考 |

---

## 🚀 立即行动

### 第 1 步：理解现状
```bash
# 查看 Skills 库存
cat data/skills-inventory.json | jq '.total_skills'

# 查看重叠分析
cat data/overlaps-detected.json | jq '.high_severity, .medium_severity'
```

### 第 2 步：集成验证框架
```python
from tools.skill_execution_verifier import SkillExecutionValidator

# 在 Agent 调用 Skill 时使用
result = SkillExecutionValidator.validate_skill_call(...)
```

### 第 3 步：更新 AGENTS.md
- 添加 15 个未文档化的 Skills
- 为所有 Skills 添加 priority 标记
- 明确重叠 Skills 的优先级

### 第 4 步：创建 Agent 提示词
- 教 Agent 如何使用 skills-matrix.json
- 提供 Skill 选择的决策规则
- 包含常见场景的 Skill 推荐

---

## 💡 关键洞察

1. **优先级体系缺失** — 只有 1 个 PREFERRED，需要为所有 Skills 标注
2. **文档化不完整** — 15 个 Skills 在 runtime 但未在 AGENTS.md 中
3. **重叠可以接受** — 8 对中等重叠是正常的，关键是明确优先级
4. **验证很重要** — 三层验证能确保 Skill 真正执行
5. **自动化是关键** — 手工审查不可扩展，需要自动化工具

---

## 📞 获取帮助

- **查看执行日志**：`~/.opencode/skill-executions/{execution_id}/execution.log`
- **查看验证报告**：`~/.opencode/skill-executions/{execution_id}/execution-report.json`
- **查看 Skills 矩阵**：`data/skills-matrix.json`
- **查看重叠分析**：`data/overlaps-detected.json`

---

**最后更新**：2026-06-17  
**项目状态**：✅ 完成  
**下一步**：集成验证框架，更新 AGENTS.md

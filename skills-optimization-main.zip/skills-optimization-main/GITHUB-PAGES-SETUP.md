# GitHub Pages 设置指南

## 问题诊断

✅ **已完成:**
- 所有 5 个 WebGUI 仪表板已创建并推送到 GitHub
- `docs/index.html` 登陆页面已创建
- 所有文件都在 `main` 分支的 `docs/` 目录中

❌ **缺失:**
- GitHub Pages 还未启用
- 仪表板 URL 返回 404

## 文件清单

```
docs/
├── index.html                                    ✅ 登陆页面
├── _theme.css                                   ✅ 共享主题样式
└── screenshots/
    ├── project-overview-dashboard.html          ✅ 项目总览
    ├── skill-execution-dashboard.html           ✅ 执行监控
    ├── skill-router-results.html                ✅ 路由引擎
    ├── overlaps-detection-report.html           ✅ 重叠检测
    ├── skills-matrix-visualization.html         ✅ 功能矩阵
    └── _theme.css                               ✅ 主题样式
```

所有文件已推送到 GitHub: https://wwwin-github.cisco.com/wenfeli/skills-optimization

## 启用 GitHub Pages

### 步骤 1: 打开设置页面

访问仓库的 Pages 设置:
```
https://wwwin-github.cisco.com/wenfeli/skills-optimization/settings/pages
```

### 步骤 2: 配置 Source

在 **Build and deployment** 部分:

1. **Source** 下拉菜单选择: `Deploy from a branch`
2. **Branch** 下拉菜单选择: `main`
3. **Folder** 下拉菜单选择: `/docs`
4. 点击 **Save** 按钮

### 步骤 3: 等待构建

GitHub 会自动构建并部署，通常需要 5-10 分钟。

完成后会显示:
```
Your site is live at https://wwwin-github.cisco.com/pages/wenfeli/skills-optimization/
```

### 步骤 4: 验证

访问以下 URL 验证仪表板:

- **主页**: https://wwwin-github.cisco.com/pages/wenfeli/skills-optimization/
- **项目总览**: https://wwwin-github.cisco.com/pages/wenfeli/skills-optimization/screenshots/project-overview-dashboard.html
- **执行监控**: https://wwwin-github.cisco.com/pages/wenfeli/skills-optimization/screenshots/skill-execution-dashboard.html
- **路由引擎**: https://wwwin-github.cisco.com/pages/wenfeli/skills-optimization/screenshots/skill-router-results.html
- **重叠检测**: https://wwwin-github.cisco.com/pages/wenfeli/skills-optimization/screenshots/overlaps-detection-report.html
- **功能矩阵**: https://wwwin-github.cisco.com/pages/wenfeli/skills-optimization/screenshots/skills-matrix-visualization.html

## 故障排除

### 问题: Pages 设置页面不显示 Source 选项

**解决方案:**
1. 确保仓库是 Public（不是 Private）
2. 刷新页面
3. 检查浏览器控制台是否有错误

### 问题: 构建失败

**解决方案:**
1. 检查 `docs/` 目录中是否有 `index.html`
2. 确保所有 HTML 文件都有正确的相对路径
3. 查看 Pages 设置页面的构建日志

### 问题: 仪表板加载但样式不正确

**解决方案:**
1. 检查浏览器控制台的 CSS 加载错误
2. 确保 `_theme.css` 在正确的位置
3. 清除浏览器缓存并重新加载

## 技术细节

### 仪表板架构

- **登陆页面** (`index.html`): 5 个仪表板的导航中心
- **项目总览**: KPI 环形图、5 阶段卡片、时间线、交付物清单
- **执行监控**: 24h 实时指标、7 天趋势、Top 排行、告警
- **路由引擎**: 查询输入、Top-5 推荐、决策树、权重分解
- **重叠检测**: 热力矩阵、网络拓扑、重叠卡片、关系分析
- **功能矩阵**: 73 个 Skill 热力网格、类别分布、搜索过滤

### 设计系统

- **主题**: Cisco 蓝色 (#0066CC) + 现代渐变
- **字体**: Space Grotesk (标题) + IBM Plex Sans (正文)
- **布局**: 响应式网格 (4→2→1 列)
- **图表**: 内联 SVG (无外部依赖)

## 相关链接

- **GitHub 仓库**: https://wwwin-github.cisco.com/wenfeli/skills-optimization
- **README**: https://wwwin-github.cisco.com/wenfeli/skills-optimization/blob/main/README.md
- **GitHub Pages 文档**: https://docs.github.com/en/pages

## 后续步骤

启用 Pages 后:

1. ✅ 验证所有 5 个仪表板都可以访问
2. ✅ 测试仪表板之间的导航链接
3. ✅ 在 README 中更新 Pages URL
4. ✅ 分享仪表板链接给团队

---

**最后更新**: 2026-06-18
**状态**: 等待 GitHub Pages 启用

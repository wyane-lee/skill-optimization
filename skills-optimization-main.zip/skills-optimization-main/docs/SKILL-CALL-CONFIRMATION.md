# Skill 调用确认机制：用户如何验证 Skill 是否成功执行

## 问题背景

当 Agent 调用一个 Skill 时，用户面临三个关键问题：

1. **Skill 是否真的被调用了？** — 还是 Agent 只是说"我调用了"但实际没有？
2. **Skill 是否成功执行了？** — 还是执行失败了但 Agent 没有报告？
3. **Skill 的输出是否可信？** — 还是 Agent 编造了结果？

本文档提供了三层确认机制，让用户能够独立验证 Skill 的执行。

---

## 三层确认机制

### 第 1 层：实时确认（执行时）

#### 1.1 观察 Agent 的工具调用

**方式**：在 OpenCode/Claude Code 中观察 Agent 的工具调用日志

**步骤**：
1. 打开 OpenCode/Claude Code 的工具调用面板
2. 查看 Agent 是否调用了 `skill` 工具
3. 确认 `skill_name` 参数是否正确

**示例**：
```
[Tool Call] skill
├── skill_name: "second-brain"
├── prompt: "搜索关于 ISE 的 Webex 讨论"
└── [Status] ✓ Completed
```

**优点**：
- ✅ 实时可见
- ✅ 无需额外工具
- ✅ 可以看到 Skill 的输入参数

**缺点**：
- ❌ 只能看到 Skill 被调用，看不到内部执行细节
- ❌ 无法验证 Skill 的前置条件是否满足
- ❌ 无法验证 Skill 的输出是否真实

---

### 第 2 层：执行日志确认（执行后）

#### 2.1 查看 Skill 执行日志

**位置**：`~/.opencode/skill-executions/{execution_id}/`

**步骤**：
1. 获取 execution_id（从 Agent 输出或日志中）
2. 查看执行日志目录
3. 检查执行日志和验证报告

**示例**：
```bash
# 查看最新执行的 Skill
ls -lt ~/.opencode/skill-executions/ | head -5

# 查看特定 Skill 的执行日志
cat ~/.opencode/skill-executions/exec_second-brain_52098672/execution.log

# 查看验证报告
cat ~/.opencode/skill-executions/exec_second-brain_52098672/execution-report.json | jq
```

**执行日志内容**：
```
[2026-06-17 14:23:45.123] Skill execution started
  execution_id: exec_second-brain_52098672
  skill_name: second-brain
  user_request: 搜索关于 ISE 的 Webex 讨论

[2026-06-17 14:23:45.124] Precondition check started
  - skill_available: ✓ PASS
  - webex_token_valid: ✓ PASS
  - no_conflicts: ✓ PASS

[2026-06-17 14:23:45.125] Tool execution started
  - Tool 1: webex_search
    Input: {"query": "ISE", "space_type": "webex"}
    Output: {"results": [...], "count": 42}
  - Tool 2: second_brain_index
    Input: {"results": [...]}
    Output: {"indexed": 42}

[2026-06-17 14:23:45.200] Output verification started
  - Output format: ✓ PASS
  - Output completeness: ✓ PASS
  - Output accuracy: ✓ PASS

[2026-06-17 14:23:45.201] Side effects verification started
  - Files created: ✓ PASS (1 file)
  - Database updated: ✓ PASS
  - External API called: ✓ PASS

[2026-06-17 14:23:45.202] Skill execution completed
  status: SUCCESS
  elapsed_time: 0.079 seconds
```

**验证报告内容**（JSON）：
```json
{
  "execution_id": "exec_second-brain_52098672",
  "skill_name": "second-brain",
  "status": "success",
  "elapsed_seconds": 0.079,
  "event_counts": {
    "started": 1,
    "precondition_check": 1,
    "preconditions_passed": 1,
    "tool_execution": 2,
    "output_verification": 1,
    "side_effects_verification": 1,
    "completed": 1
  },
  "preconditions": {
    "skill_available": true,
    "webex_token_valid": true,
    "no_conflicts": true
  },
  "tool_calls": [
    {
      "tool_name": "webex_search",
      "input": {"query": "ISE", "space_type": "webex"},
      "output": {"results": [...], "count": 42},
      "status": "success"
    },
    {
      "tool_name": "second_brain_index",
      "input": {"results": [...]},
      "output": {"indexed": 42},
      "status": "success"
    }
  ],
  "output_verification": {
    "format_valid": true,
    "completeness_valid": true,
    "accuracy_valid": true
  },
  "side_effects": {
    "files_created": ["~/.opencode/skill-executions/exec_second-brain_52098672/artifacts/search-results.json"],
    "database_updated": true,
    "external_api_called": true
  }
}
```

**优点**：
- ✅ 详细的执行步骤
- ✅ 可以看到每个工具调用的输入和输出
- ✅ 可以验证前置条件和后置条件
- ✅ 可以看到执行时间和性能指标

**缺点**：
- ❌ 需要手动查看日志文件
- ❌ 需要理解日志格式
- ❌ 无法实时查看（只能事后查看）

---

### 第 3 层：工件确认（输出验证）

#### 3.1 查看 Skill 生成的工件

**位置**：`~/.opencode/skill-executions/{execution_id}/artifacts/`

**步骤**：
1. 查看执行目录中的 artifacts 文件夹
2. 检查 Skill 生成的文件
3. 验证文件内容是否符合预期

**示例**：
```bash
# 查看 Skill 生成的工件
ls -la ~/.opencode/skill-executions/exec_second-brain_52098672/artifacts/

# 查看工件内容
cat ~/.opencode/skill-executions/exec_second-brain_52098672/artifacts/search-results.json | jq

# 验证工件的完整性
wc -l ~/.opencode/skill-executions/exec_second-brain_52098672/artifacts/search-results.json
```

**工件类型**：
- 搜索结果（JSON）
- 生成的文档（Markdown）
- 下载的文件（PDF、CSV 等）
- 生成的报告（HTML）
- 数据库导出（JSON、CSV）

**优点**：
- ✅ 可以直接查看 Skill 的实际输出
- ✅ 可以验证输出的完整性和准确性
- ✅ 可以用于后续处理或分析

**缺点**：
- ❌ 需要理解工件的格式
- ❌ 大文件可能难以查看

---

## 快速确认清单

### 用户快速确认 Skill 是否成功执行

#### ✅ 步骤 1：观察工具调用（实时）
```
在 OpenCode/Claude Code 中查看：
□ Agent 是否调用了 skill 工具？
□ skill_name 参数是否正确？
□ 工具调用是否显示 ✓ Completed？
```

#### ✅ 步骤 2：查看执行日志（事后）
```bash
# 获取 execution_id（从 Agent 输出中）
execution_id="exec_second-brain_52098672"

# 查看执行日志
cat ~/.opencode/skill-executions/$execution_id/execution.log

# 检查以下内容：
□ 是否显示 "Skill execution completed"？
□ 是否显示 "status: SUCCESS"？
□ 所有前置条件是否都通过（✓ PASS）？
□ 所有工具调用是否都成功？
```

#### ✅ 步骤 3：查看验证报告（详细）
```bash
# 查看验证报告
cat ~/.opencode/skill-executions/$execution_id/execution-report.json | jq

# 检查以下内容：
□ "status": "success"？
□ "preconditions_passed": 1？
□ 所有工具调用的 "status": "success"？
□ "output_verification" 中所有项都是 true？
□ "side_effects_verification" 中所有项都是 true？
```

#### ✅ 步骤 4：查看工件（验证输出）
```bash
# 查看工件列表
ls -la ~/.opencode/skill-executions/$execution_id/artifacts/

# 查看工件内容
cat ~/.opencode/skill-executions/$execution_id/artifacts/search-results.json | jq

# 检查以下内容：
□ 是否生成了预期的文件？
□ 文件大小是否合理？
□ 文件内容是否符合预期？
```

---

## 常见场景和确认方法

### 场景 1：Agent 说"我调用了 second-brain Skill"

**用户想确认**：Skill 是否真的被调用了？

**确认方法**：
```bash
# 1. 查看最新的执行日志
ls -lt ~/.opencode/skill-executions/ | head -1

# 2. 查看执行日志
cat ~/.opencode/skill-executions/exec_second-brain_*/execution.log | tail -20

# 3. 检查是否显示 "Skill execution completed"
grep "Skill execution completed" ~/.opencode/skill-executions/exec_second-brain_*/execution.log
```

**确认标准**：
- ✅ 如果找到 "Skill execution completed" → Skill 被调用了
- ❌ 如果找不到 → Skill 没有被调用

---

### 场景 2：Agent 说"搜索找到了 42 个结果"

**用户想确认**：搜索结果是否真实？

**确认方法**：
```bash
# 1. 查看验证报告
cat ~/.opencode/skill-executions/exec_second-brain_*/execution-report.json | jq '.tool_calls[] | select(.tool_name == "webex_search")'

# 2. 查看搜索结果工件
cat ~/.opencode/skill-executions/exec_second-brain_*/artifacts/search-results.json | jq '.results | length'

# 3. 验证结果数量
# 应该显示 42
```

**确认标准**：
- ✅ 如果工件中的结果数量 == Agent 报告的数量 → 结果真实
- ❌ 如果不匹配 → Agent 可能编造了结果

---

### 场景 3：Agent 说"Skill 执行失败"

**用户想确认**：失败的原因是什么？

**确认方法**：
```bash
# 1. 查看执行日志
cat ~/.opencode/skill-executions/exec_*/execution.log | grep -A 5 "FAIL\|ERROR"

# 2. 查看验证报告中的错误信息
cat ~/.opencode/skill-executions/exec_*/execution-report.json | jq '.errors'

# 3. 查看前置条件检查结果
cat ~/.opencode/skill-executions/exec_*/execution-report.json | jq '.preconditions'
```

**确认标准**：
- ✅ 如果前置条件失败 → 需要修复前置条件（如 Webex token 过期）
- ✅ 如果工具调用失败 → 需要检查工具配置
- ✅ 如果输出验证失败 → Skill 可能有 bug

---

## 自动化确认工具

### 工具 1：快速检查脚本

```bash
#!/bin/bash
# 快速检查最新的 Skill 执行是否成功

execution_id=$(ls -t ~/.opencode/skill-executions/ | head -1)

echo "=== Skill 执行确认 ==="
echo "Execution ID: $execution_id"
echo ""

# 检查执行日志
if grep -q "Skill execution completed" ~/.opencode/skill-executions/$execution_id/execution.log; then
    echo "✅ Skill 被调用了"
else
    echo "❌ Skill 没有被调用"
    exit 1
fi

# 检查执行状态
status=$(cat ~/.opencode/skill-executions/$execution_id/execution-report.json | jq -r '.status')
if [ "$status" = "success" ]; then
    echo "✅ Skill 执行成功"
else
    echo "❌ Skill 执行失败: $status"
    exit 1
fi

# 检查前置条件
preconditions=$(cat ~/.opencode/skill-executions/$execution_id/execution-report.json | jq '.preconditions | all')
if [ "$preconditions" = "true" ]; then
    echo "✅ 所有前置条件通过"
else
    echo "❌ 前置条件检查失败"
    exit 1
fi

# 检查工具调用
tool_failures=$(cat ~/.opencode/skill-executions/$execution_id/execution-report.json | jq '.tool_calls[] | select(.status != "success") | length')
if [ -z "$tool_failures" ] || [ "$tool_failures" = "0" ]; then
    echo "✅ 所有工具调用成功"
else
    echo "❌ 有 $tool_failures 个工具调用失败"
    exit 1
fi

# 检查输出验证
output_valid=$(cat ~/.opencode/skill-executions/$execution_id/execution-report.json | jq '.output_verification | all')
if [ "$output_valid" = "true" ]; then
    echo "✅ 输出验证通过"
else
    echo "❌ 输出验证失败"
    exit 1
fi

echo ""
echo "=== 总结 ==="
echo "✅ Skill 执行成功，所有验证通过"
```

### 工具 2：详细报告脚本

```bash
#!/bin/bash
# 生成详细的 Skill 执行报告

execution_id=$1

if [ -z "$execution_id" ]; then
    execution_id=$(ls -t ~/.opencode/skill-executions/ | head -1)
fi

echo "=== Skill 执行详细报告 ==="
echo "Execution ID: $execution_id"
echo ""

# 基本信息
echo "=== 基本信息 ==="
cat ~/.opencode/skill-executions/$execution_id/execution-report.json | jq '{
    skill_name: .skill_name,
    status: .status,
    elapsed_seconds: .elapsed_seconds,
    timestamp: .timestamp
}'

echo ""
echo "=== 前置条件 ==="
cat ~/.opencode/skill-executions/$execution_id/execution-report.json | jq '.preconditions'

echo ""
echo "=== 工具调用 ==="
cat ~/.opencode/skill-executions/$execution_id/execution-report.json | jq '.tool_calls[] | {
    tool_name: .tool_name,
    status: .status,
    input: .input,
    output: .output
}'

echo ""
echo "=== 输出验证 ==="
cat ~/.opencode/skill-executions/$execution_id/execution-report.json | jq '.output_verification'

echo ""
echo "=== 副作用验证 ==="
cat ~/.opencode/skill-executions/$execution_id/execution-report.json | jq '.side_effects'

echo ""
echo "=== 生成的工件 ==="
ls -lh ~/.opencode/skill-executions/$execution_id/artifacts/
```

---

## 集成到 Agent 的确认机制

### Agent 应该在调用 Skill 后自动提供

#### 1. 执行 ID
```
我调用了 second-brain Skill 来搜索关于 ISE 的 Webex 讨论。
执行 ID：exec_second-brain_52098672
```

#### 2. 快速确认链接
```
你可以通过以下命令验证执行结果：
cat ~/.opencode/skill-executions/exec_second-brain_52098672/execution-report.json | jq
```

#### 3. 执行摘要
```
执行摘要：
- 状态：✅ 成功
- 耗时：0.079 秒
- 工具调用：2 个（都成功）
- 前置条件：3 个（都通过）
- 生成工件：1 个（search-results.json）
```

#### 4. 结果验证
```
搜索结果：
- 找到 42 个结果
- 来源：Webex 讨论
- 已索引到 Second Brain

你可以通过以下命令查看详细结果：
cat ~/.opencode/skill-executions/exec_second-brain_52098672/artifacts/search-results.json | jq
```

---

## 总结：用户如何确认 Skill 执行

| 确认方式 | 时机 | 方法 | 可信度 |
|---------|------|------|--------|
| **工具调用观察** | 实时 | 观察 Agent 的工具调用面板 | ⭐⭐ |
| **执行日志** | 事后 | 查看 `execution.log` | ⭐⭐⭐⭐ |
| **验证报告** | 事后 | 查看 `execution-report.json` | ⭐⭐⭐⭐⭐ |
| **工件验证** | 事后 | 查看 `artifacts/` 中的文件 | ⭐⭐⭐⭐⭐ |

**最可靠的确认方式**：
1. ✅ 查看验证报告（execution-report.json）
2. ✅ 查看生成的工件（artifacts/）
3. ✅ 验证工件内容是否符合预期

**最快的确认方式**：
1. ✅ 观察工具调用面板（实时）
2. ✅ 运行快速检查脚本（1 秒）

---

## 下一步

### 用户可以立即做的事情

1. **设置快速检查脚本**
   ```bash
   cp docs/SKILL-CALL-CONFIRMATION.md ~/bin/skill-check.sh
   chmod +x ~/bin/skill-check.sh
   ```

2. **创建别名**
   ```bash
   alias skill-check='cat ~/.opencode/skill-executions/$(ls -t ~/.opencode/skill-executions/ | head -1)/execution-report.json | jq'
   ```

3. **监控 Skill 执行**
   ```bash
   watch -n 1 'ls -lt ~/.opencode/skill-executions/ | head -5'
   ```

### Agent 应该实现的功能

1. **自动提供 execution_id** — 每次调用 Skill 后
2. **自动生成执行摘要** — 显示关键指标
3. **提供验证命令** — 让用户可以自己验证
4. **处理验证失败** — 如果验证失败，自动重试或报告错误

---

## 参考资源

- [SKILL-EXECUTION-VERIFICATION.md](SKILL-EXECUTION-VERIFICATION.md) — 验证机制设计
- [skill-execution-verifier.py](../tools/skill-execution-verifier.py) — 验证框架实现
- [INDEX.md](../INDEX.md) — 项目索引

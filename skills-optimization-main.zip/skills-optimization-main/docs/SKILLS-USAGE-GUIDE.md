# Skills 使用指南 - 按类别和场景

## 概述

本指南提供了 73 个已安装 Skill 的完整使用指南，按类别和场景组织。

---

## 第一部分：Skill 分类

### 1.1 通信和搜索类 (8 个 Skill)

#### 1. second-brain
**用途**：统一搜索所有通信和项目文档  
**触发词**：搜索邮件、查找 Webex、查找项目文档  
**使用场景**：
- 查找过去的邮件或 Webex 消息
- 搜索项目文档和报告
- 回顾会议记录

**基本用法**：
```python
from second_brain import SecondBrainSearch

search = SecondBrainSearch()
results = search.query("关键词", source="all")  # all, email, webex, projects
```

#### 2. webex-transcript-download
**用途**：下载 Webex 会议转录  
**触发词**：下载转录、保存会议记录  
**使用场景**：
- 保存重要会议的转录
- 建立知识库
- 审计和合规

**基本用法**：
```bash
# 下载转录
python3 skills/webex-transcript-download/download.py \
    --recording-url "https://..." \
    --output-dir ~/Documents/transcripts/
```

#### 3. webex-space-dump
**用途**：导出 Webex 空间的所有消息  
**触发词**：导出 Webex 空间、备份对话  
**使用场景**：
- 备份重要的 Webex 空间
- 导出对话用于分析
- 归档项目讨论

#### 4. webex-calendar
**用途**：访问和查询 Outlook 日历  
**触发词**：查看日历、查找会议、列出参与者  
**使用场景**：
- 查看日程安排
- 找到会议参与者
- 分析会议时间

#### 5. directory-parser
**用途**：研究 Cisco 员工和组织结构  
**触发词**：查找员工、组织结构、团队成员  
**使用场景**：
- 查找员工信息
- 生成组织图
- 分析团队结构

#### 6. email-rag
**用途**：搜索 Outlook 邮件  
**触发词**：搜索邮件、查找邮件  
**使用场景**：
- 查找特定邮件
- 搜索邮件历史
- 提取邮件信息

#### 7. webex-rag-query
**用途**：查询 Cisco Webex 知识库  
**触发词**：查询 Webex 知识库、搜索技术信息  
**使用场景**：
- 查找技术信息
- 搜索 Cisco 产品知识
- 获取最佳实践

#### 8. search-bookmarks
**用途**：搜索 Chrome 书签  
**触发词**：搜索书签、查找保存的链接  
**使用场景**：
- 查找保存的网站
- 搜索书签历史
- 组织书签

---

### 1.2 数据和分析类 (7 个 Skill)

#### 1. dump-cdets
**用途**：下载 CDETS 错误数据  
**触发词**：下载 bug、获取 bug 详情  
**使用场景**：
- 查看 bug 详情
- 下载 bug 数据
- 分析 bug 趋势

#### 2. dump-techzone
**用途**：下载 Cisco TechZone 文章  
**触发词**：下载 TechZone、获取文章内容  
**使用场景**：
- 获取技术文章
- 下载参考资料
- 建立知识库

#### 3. csone-sr-dump
**用途**：下载 Cisco CSOne 服务请求数据  
**触发词**：下载 SR、获取 SR 详情  
**使用场景**：
- 查看 SR 详情
- 下载 SR 数据
- 分析 SR 趋势

#### 4. mr-sr-case-list
**用途**：下载 Quicker 积压中的 SR 案例列表  
**触发词**：下载 SR 列表、获取案例列表  
**使用场景**：
- 查看合同的所有 SR
- 分析 SR 分布
- 生成报告

#### 5. opencode-cost-calculator
**用途**：计算 OpenCode 使用成本  
**触发词**：计算成本、查看使用统计  
**使用场景**：
- 了解 API 成本
- 优化使用
- 生成成本报告

#### 6. opencode-session-manager
**用途**：管理 OpenCode 会话  
**触发词**：列出会话、会话总结  
**使用场景**：
- 查看活跃会话
- 生成会话报告
- 清理旧会话

#### 7. circuit-cost-relief
**用途**：报告 Circuit 节省的成本  
**触发词**：查看成本节省、Circuit 使用统计  
**使用场景**：
- 了解 Circuit 节省
- 验证使用情况
- 生成成本报告

---

### 1.3 代码和开发类 (12 个 Skill)

#### 1. github-repo-management
**用途**：管理 Cisco 内部 GitHub 仓库  
**触发词**：创建仓库、推送代码  
**使用场景**：
- 创建新仓库
- 管理仓库设置
- 推送代码

#### 2. github-pages-hosting
**用途**：在 GitHub Pages 上托管静态网站  
**触发词**：发布网站、托管 HTML  
**使用场景**：
- 发布文档
- 托管报告
- 创建网站

#### 3. wwwin-github-search
**用途**：搜索 Cisco 内部 GitHub  
**触发词**：搜索代码、查找仓库  
**使用场景**：
- 查找代码示例
- 搜索仓库
- 查找脚本

#### 4. secure-git-push
**用途**：安全检查后推送代码  
**触发词**：推送代码、检查安全  
**使用场景**：
- 确保没有泄露密钥
- 验证代码质量
- 安全推送

#### 5. clonedeps
**用途**：克隆项目依赖源代码  
**触发词**：克隆依赖、查看库源码  
**使用场景**：
- 查看库的实现
- 调试库问题
- 学习库代码

#### 6. code-tour
**用途**：创建代码导览  
**触发词**：创建导览、代码讲解  
**使用场景**：
- 创建代码导览
- 讲解架构
- 培训新人

#### 7. codemap
**用途**：生成代码库地图  
**触发词**：生成代码地图、项目结构  
**使用场景**：
- 了解项目结构
- 生成文档
- 分析代码库

#### 8. simplify
**用途**：简化代码  
**触发词**：简化代码、提高可读性  
**使用场景**：
- 重构代码
- 提高可读性
- 减少复杂度

#### 9. diagram-generation
**用途**：生成 Mermaid 图表  
**触发词**：生成图表、创建流程图  
**使用场景**：
- 创建架构图
- 生成流程图
- 可视化数据

#### 10. drawio-toolkit
**用途**：生成 draw.io 网络拓扑图  
**触发词**：生成拓扑图、网络图  
**使用场景**：
- 创建网络拓扑
- 设计 ACI 租户
- 可视化基础设施

#### 11. markitdown-converter
**用途**：将文档转换为 Markdown  
**触发词**：转换文档、PDF 转 Markdown  
**使用场景**：
- 转换 PDF 到 Markdown
- 转换 Office 文档
- 提取文本

#### 12. workarounds
**用途**：OpenCode 工具故障的解决方案  
**触发词**：工具错误、故障排除  
**使用场景**：
- 解决工具问题
- 绕过 bug
- 找到替代方案

---

### 1.4 文档和报告类 (8 个 Skill)

#### 1. cisco-html-report
**用途**：生成 Cisco 品牌的 HTML 报告  
**触发词**：生成报告、创建 HTML  
**使用场景**：
- 生成技术报告
- 创建仪表板
- 发布文档

#### 2. cisco-presentation
**用途**：创建 Cisco 品牌的 HTML 演示文稿  
**触发词**：创建演示、生成幻灯片  
**使用场景**：
- 创建演讲稿
- 生成演示文稿
- 创建培训材料

#### 3. cisco-pptx
**用途**：创建 Cisco 品牌的 PowerPoint  
**触发词**：创建 PPT、生成演示文稿  
**使用场景**：
- 创建 PowerPoint 演示
- 编辑现有演示
- 导出为 PPTX

#### 4. marp-presentations
**用途**：从 Markdown 生成演示文稿  
**触发词**：Markdown 幻灯片、快速演示  
**使用场景**：
- 快速创建演示
- 从 Markdown 生成幻灯片
- 转换 PPT 到 Markdown

#### 5. html-ppt
**用途**：创建 HTML 演示文稿  
**触发词**：HTML 演示、网页幻灯片  
**使用场景**：
- 创建网页演示
- 交互式幻灯片
- 在线演示

#### 6. frontend-slides
**用途**：创建动画丰富的 HTML 演示  
**触发词**：创建动画演示、美观幻灯片  
**使用场景**：
- 创建高质量演示
- 添加动画效果
- 专业演示

#### 7. pptx
**用途**：处理 PowerPoint 文件  
**触发词**：编辑 PPT、处理演示文稿  
**使用场景**：
- 编辑 PowerPoint
- 提取内容
- 转换格式

#### 8. pdf
**用途**：处理 PDF 文件  
**触发词**：处理 PDF、提取内容  
**使用场景**：
- 合并 PDF
- 提取文本
- 转换格式

---

### 1.5 RADKit 和网络类 (5 个 Skill)

#### 1. radkit-management
**用途**：统一 RADKit 管理  
**触发词**：RADKit 访问、设备管理  
**使用场景**：
- 授予 RADKit 访问权限
- 管理设备
- 查看清单

#### 2. radkit-device-inventory
**用途**：管理 RADKit 设备清单  
**触发词**：添加设备、查询设备  
**使用场景**：
- 添加新设备
- 查询设备信息
- 管理标签

#### 3. radkit-grant-access
**用途**：授予 RADKit 访问权限  
**触发词**：授予访问、添加用户  
**使用场景**：
- 为 TAC 工程师授予访问权限
- 管理用户权限
- 审计访问

#### 4. radkit-certificate-auth
**用途**：RADKit 证书认证指南  
**触发词**：证书认证、登录 RADKit  
**使用场景**：
- 设置证书认证
- 避免 SSO 提示
- 自动化认证

#### 5. radkit-swagger-api
**用途**：通过 RADKit 调用 Swagger API  
**触发词**：API 调用、REST 请求  
**使用场景**：
- 调用设备 API
- 查询 DNAC
- 自动化操作

---

### 1.6 Cisco 特定类 (6 个 Skill)

#### 1. cisco-branding
**用途**：应用 Cisco 品牌指南  
**触发词**：Cisco 品牌、品牌指南  
**使用场景**：
- 应用品牌样式
- 使用 Cisco 颜色
- 遵循品牌规范

#### 2. cisco-gen-account
**用途**：创建 Cisco 通用账户  
**触发词**：创建服务账户、.gen 账户  
**使用场景**：
- 为 MCP 创建账户
- 为自动化创建身份
- 管理服务账户

#### 3. cisco-ai-usecases
**用途**：搜索 Cisco AI 用例  
**触发词**：AI 用例、时间节省  
**使用场景**：
- 查找 AI 用例
- 跟踪时间节省
- 生成用例报告

#### 4. cisco-internal-research
**用途**：使用 Cisco 内部资源进行研究  
**触发词**：Cisco 研究、内部知识  
**使用场景**：
- 查询 Cisco 知识库
- 搜索内部资源
- 获取 Cisco 信息

#### 5. cx-compass-css
**用途**：应用 CX Compass 样式  
**触发词**：CX Compass 样式、深色主题  
**使用场景**：
- 应用 Compass 样式
- 创建 Compass 风格的页面
- 匹配 Compass 外观

#### 6. salesforce-mcp
**用途**：查询 Cisco Salesforce  
**触发词**：Salesforce 查询、机会、账户  
**使用场景**：
- 查询机会
- 查看账户信息
- 生成管道报告

---

### 1.7 开发工具和框架类 (15 个 Skill)

#### 1. frontend-patterns
**用途**：前端开发模式  
**触发词**：React、Next.js、前端架构  
**使用场景**：
- 学习前端模式
- 设计 React 组件
- 优化性能

#### 2. backend-patterns
**用途**：后端开发模式  
**触发词**：API 设计、后端架构  
**使用场景**：
- 设计 API
- 优化数据库
- 实现缓存

#### 3. api-design
**用途**：REST API 设计  
**触发词**：API 设计、REST 规范  
**使用场景**：
- 设计 API
- 定义端点
- 处理错误

#### 4. python-patterns
**用途**：Python 最佳实践  
**触发词**：Python 代码、Pythonic  
**使用场景**：
- 编写 Python 代码
- 遵循 PEP 8
- 使用类型提示

#### 5. python-testing
**用途**：Python 测试模式  
**触发词**：Python 测试、pytest  
**使用场景**：
- 编写测试
- 测试驱动开发
- 覆盖率分析

#### 6. golang-patterns
**用途**：Go 最佳实践  
**触发词**：Go 代码、Golang  
**使用场景**：
- 编写 Go 代码
- 遵循 Go 规范
- 并发编程

#### 7. golang-testing
**用途**：Go 测试模式  
**触发词**：Go 测试、table-driven  
**使用场景**：
- 编写 Go 测试
- 基准测试
- 模糊测试

#### 8. rust-patterns
**用途**：Rust 最佳实践  
**触发词**：Rust 代码、所有权  
**使用场景**：
- 编写 Rust 代码
- 错误处理
- 并发编程

#### 9. rust-testing
**用途**：Rust 测试模式  
**触发词**：Rust 测试、单元测试  
**使用场景**：
- 编写 Rust 测试
- 集成测试
- 属性测试

#### 10. kotlin-patterns
**用途**：Kotlin 最佳实践  
**触发词**：Kotlin 代码、KMP  
**使用场景**：
- 编写 Kotlin 代码
- 使用协程
- 函数式编程

#### 11. kotlin-testing
**用途**：Kotlin 测试模式  
**触发词**：Kotlin 测试、Kotest  
**使用场景**：
- 编写 Kotlin 测试
- 属性测试
- 覆盖率分析

#### 12. java-coding-standards
**用途**：Java 编码标准  
**触发词**：Java 代码、Spring Boot  
**使用场景**：
- 编写 Java 代码
- 遵循标准
- 使用 Optional

#### 13. springboot-patterns
**用途**：Spring Boot 模式  
**触发词**：Spring Boot、REST API  
**使用场景**：
- 设计 Spring Boot 应用
- 配置依赖注入
- 实现 REST API

#### 14. springboot-tdd
**用途**：Spring Boot 测试驱动开发  
**触发词**：Spring Boot 测试、JUnit  
**使用场景**：
- 编写 Spring Boot 测试
- 模拟依赖
- 集成测试

#### 15. springboot-verification
**用途**：Spring Boot 验证流程  
**触发词**：Spring Boot 验证、构建检查  
**使用场景**：
- 验证构建
- 运行测试
- 安全扫描

---

### 1.8 AI 和学习类 (8 个 Skill)

#### 1. know-yourself
**用途**：构建用户心理档案  
**触发词**：构建档案、自我认识  
**使用场景**：
- 构建个人档案
- 改进决策
- 自动化选择

#### 2. write-like-me
**用途**：用用户风格重写文本  
**触发词**：用我的风格写、语音转移  
**使用场景**：
- 重写文本
- 匹配风格
- 个性化输出

#### 3. rpi-strategy
**用途**：研究→计划→实现框架  
**触发词**：RPI、结构化开发  
**使用场景**：
- 结构化问题解决
- 分阶段实现
- 验证每个阶段

#### 4. council
**用途**：四声议会进行决策  
**触发词**：决策、权衡  
**使用场景**：
- 做出困难决定
- 权衡选项
- 获得多个观点

#### 5. reflect
**用途**：回顾工作并建议改进  
**触发词**：反思、学习、改进  
**使用场景**：
- 回顾会话
- 识别模式
- 建议改进

#### 6. ai-regression-testing
**用途**：AI 代码的回归测试  
**触发词**：回归测试、AI 测试  
**使用场景**：
- 测试 AI 生成的代码
- 检测盲点
- 验证行为

#### 7. eval-harness
**用途**：评估驱动开发框架  
**触发词**：评估、EDD  
**使用场景**：
- 定义评估标准
- 驱动开发
- 验证质量

#### 8. continuous-learning
**用途**：从会话中学习  
**触发词**：学习、技能提取  
**使用场景**：
- 提取可重用模式
- 创建技能
- 持续改进

---

### 1.9 UI/UX 和设计类 (4 个 Skill)

#### 1. impeccable
**用途**：UI/UX 设计和改进  
**触发词**：设计、UI 改进、美观  
**使用场景**：
- 设计界面
- 改进 UX
- 优化布局

#### 2. frontend-design
**用途**：前端设计和实现  
**触发词**：前端设计、组件设计  
**使用场景**：
- 设计组件
- 创建界面
- 实现设计

#### 3. diplomatic-review
**用途**：内容的外交审查  
**触发词**：审查、专业沟通  
**使用场景**：
- 审查文档
- 改进沟通
- 确保专业性

#### 4. quality-checker-ai
**用途**：意图驱动的质量检查  
**触发词**：质量检查、验证  
**使用场景**：
- 检查质量
- 验证完整性
- 自动修复

---

### 1.10 项目管理和工作流类 (6 个 Skill)

#### 1. project-management
**用途**：长期项目管理  
**触发词**：项目管理、恢复项目  
**使用场景**：
- 管理项目
- 跟踪进度
- 恢复工作

#### 2. deepwork
**用途**：深度工作编排  
**触发词**：深度工作、复杂任务  
**使用场景**：
- 规划复杂工作
- 多阶段实现
- 风险管理

#### 3. concierge-orchestration
**用途**：多 AI 代理编排  
**触发词**：打开项目、生成代理  
**使用场景**：
- 在新标签中打开项目
- 生成多个代理
- 代理间通信

#### 4. new-project
**用途**：创建新项目  
**触发词**：创建项目、新项目  
**使用场景**：
- 创建新项目
- 初始化仓库
- 设置环境

#### 5. post-restart-recovery
**用途**：重启后恢复会话  
**触发词**：重启后、恢复会话  
**使用场景**：
- 恢复工作
- 重建上下文
- 继续任务

#### 6. statusline-setup
**用途**：配置任务状态行  
**触发词**：设置任务、更新状态  
**使用场景**：
- 设置任务描述
- 更新进度
- 跟踪工作

---

## 第二部分：按场景使用 Skill

### 场景 1：研究和学习

**目标**：深入了解一个主题

**推荐 Skill 组合**：
1. `second-brain` — 搜索过去的相关讨论
2. `research-with-sources` — 进行深度研究
3. `webex-rag-query` — 查询 Cisco 知识库
4. `dump-techzone` — 获取技术文章
5. `code-tour` — 创建代码导览（如果涉及代码）

**工作流**：
```
搜索过去的讨论 → 进行深度研究 → 查询知识库 → 获取文章 → 创建导览
```

### 场景 2：创建演示文稿

**目标**：创建专业的演示文稿

**推荐 Skill 组合**：
1. `cisco-branding` — 应用 Cisco 品牌
2. `cisco-presentation` 或 `marp-presentations` — 创建演示
3. `diagram-generation` — 添加图表
4. `diplomatic-review` — 审查内容

**工作流**：
```
应用品牌 → 创建演示 → 添加图表 → 审查内容 → 发布
```

### 场景 3：开发新功能

**目标**：实现新的代码功能

**推荐 Skill 组合**：
1. `rpi-strategy` — 研究→计划→实现
2. `<language>-patterns` — 遵循最佳实践
3. `<language>-testing` — 编写测试
4. `<language>-verification` — 验证代码
5. `secure-git-push` — 安全推送

**工作流**：
```
研究 → 计划 → 实现 → 测试 → 验证 → 推送
```

### 场景 4：故障排除

**目标**：诊断和修复问题

**推荐 Skill 组合**：
1. `second-brain` — 搜索过去的问题
2. `webex-rag-query` — 查询知识库
3. `dump-cdets` — 查看相关 bug
4. `simplify` — 简化代码以找到问题
5. `<language>-testing` — 编写测试验证修复

**工作流**：
```
搜索历史 → 查询知识库 → 查看 bug → 简化代码 → 测试修复
```

### 场景 5：生成报告

**目标**：创建数据驱动的报告

**推荐 Skill 组合**：
1. `dump-cdets` 或 `csone-sr-dump` — 获取数据
2. `second-brain` — 添加上下文
3. `cisco-html-report` — 创建报告
4. `github-pages-hosting` — 发布报告
5. `diplomatic-review` — 审查报告

**工作流**：
```
获取数据 → 添加上下文 → 创建报告 → 发布 → 审查
```

---

## 第三部分：Skill 选择决策树

### 我想要搜索信息

```
是否关于通信（邮件、Webex）？
├─ 是 → second-brain
└─ 否 → 是否关于代码？
    ├─ 是 → wwwin-github-search
    └─ 否 → 是否关于 Cisco 产品？
        ├─ 是 → webex-rag-query 或 dump-techzone
        └─ 否 → 是否关于 bug？
            ├─ 是 → dump-cdets
            └─ 否 → search-bookmarks
```

### 我想要创建文档

```
是否需要演示文稿？
├─ 是 → 是否需要 PowerPoint？
│   ├─ 是 → cisco-pptx 或 marp-presentations
│   └─ 否 → cisco-presentation 或 html-ppt
└─ 否 → 是否需要报告？
    ├─ 是 → cisco-html-report
    └─ 否 → 是否需要代码文档？
        ├─ 是 → code-tour 或 codemap
        └─ 否 → 其他文档类 Skill
```

### 我想要开发代码

```
使用什么语言？
├─ Python → python-patterns, python-testing
├─ Go → golang-patterns, golang-testing
├─ Rust → rust-patterns, rust-testing
├─ Kotlin → kotlin-patterns, kotlin-testing
├─ Java → java-coding-standards, springboot-patterns
├─ JavaScript/TypeScript → frontend-patterns, backend-patterns
└─ 其他 → 查看相应的 Skill

然后：
1. 遵循 <language>-patterns
2. 编写 <language>-testing
3. 运行 <language>-verification（如果有）
4. 使用 secure-git-push 推送
```

---

## 总结

本指南提供了：
- **73 个 Skill 的分类** — 按类别和功能组织
- **按场景的推荐** — 常见工作流的 Skill 组合
- **决策树** — 快速选择合适的 Skill

通过使用本指南，您可以快速找到合适的 Skill 来完成任务。

---

**版本**：1.0.0  
**发布日期**：2026-06-17  
**状态**：生产就绪

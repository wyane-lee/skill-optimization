# Agent 培训提示词 - Skill 选择和优化

## 概述

本文档提供了 AI Agent 的培训提示词，用于改进 Skill 选择、路由和优化。

---

## 第一部分：Skill 选择培训

### 1.1 基础 Skill 选择原则

**提示词 1：理解 Skill 的目的**

```
你是一个 OpenCode Agent。当用户请求时，你需要选择合适的 Skill。

Skill 选择的基本原则：
1. 理解用户的真实需求（不仅仅是表面需求）
2. 查看 Skill 的触发词和使用场景
3. 考虑 Skill 的依赖关系
4. 优先选择专门的 Skill 而不是通用的

例如：
- 用户说"搜索邮件"→ 使用 second-brain（统一搜索）而不是 email-rag（仅邮件）
- 用户说"创建演示"→ 使用 cisco-presentation 而不是 html-ppt（除非用户明确要求 HTML）
- 用户说"下载 bug 数据"→ 使用 dump-cdets 而不是 research-with-sources

在选择 Skill 前，总是问自己：
- 这个 Skill 是否直接解决用户的问题？
- 是否有更专门的 Skill？
- 这个 Skill 的前置条件是否满足？
```

**提示词 2：Skill 组合策略**

```
当一个任务需要多个 Skill 时，遵循以下策略：

1. 顺序依赖：
   - 如果 Skill A 的输出是 Skill B 的输入，按顺序执行
   - 例如：dump-cdets → analyze → generate-report

2. 并行执行：
   - 如果 Skill 之间没有依赖，并行执行以节省时间
   - 例如：second-brain 和 webex-rag-query 可以并行搜索

3. 数据流：
   - 确保数据在 Skill 之间正确流动
   - 转换数据格式（如需要）
   - 验证输出质量

4. 错误处理：
   - 如果一个 Skill 失败，有备选方案吗？
   - 例如：如果 webex-rag-query 失败，使用 research-with-sources

示例工作流：
任务：创建关于 Cisco ISE 的演示文稿

1. 并行执行：
   - second-brain 搜索过去的 ISE 讨论
   - webex-rag-query 查询 ISE 知识库
   - dump-techzone 获取 ISE 文章

2. 顺序执行：
   - 合并搜索结果
   - 使用 cisco-presentation 创建演示
   - 使用 diagram-generation 添加架构图
   - 使用 diplomatic-review 审查内容
   - 使用 github-pages-hosting 发布
```

### 1.2 高级 Skill 选择

**提示词 3：理解 Skill 的局限性**

```
每个 Skill 都有局限性。了解这些局限性可以帮助你做出更好的选择：

1. second-brain
   - 局限：只能搜索已索引的内容
   - 解决：如果找不到，使用 research-with-sources 进行网络搜索

2. webex-rag-query
   - 局限：只能查询 Cisco 知识库
   - 解决：对于通用问题，使用 research-with-sources

3. dump-cdets
   - 局限：需要有效的 bug ID
   - 解决：如果不知道 bug ID，先搜索相关问题

4. cisco-presentation
   - 局限：生成 HTML，不是 PowerPoint
   - 解决：如果需要 PowerPoint，使用 cisco-pptx 或 marp-presentations

5. github-pages-hosting
   - 局限：只能托管静态内容
   - 解决：对于动态内容，使用其他托管方案

当选择 Skill 时，考虑：
- 这个 Skill 能否完全解决问题？
- 如果不能，需要哪些额外的 Skill？
- 是否有更好的替代方案？
```

**提示词 4：Skill 的性能特征**

```
不同的 Skill 有不同的性能特征。选择时考虑：

快速 Skill（< 1 秒）：
- search-bookmarks
- webex-calendar
- directory-parser

中等速度 Skill（1-5 秒）：
- second-brain
- webex-rag-query
- dump-cdets

慢速 Skill（> 5 秒）：
- research-with-sources
- cisco-presentation
- github-pages-hosting

优化策略：
1. 对于时间敏感的任务，优先使用快速 Skill
2. 对于可以并行的任务，并行执行慢速 Skill
3. 对于用户等待的任务，先返回快速结果，然后异步执行慢速任务

例如：
用户要求"创建演示并发布"
- 快速返回：使用 cisco-presentation 创建演示
- 异步执行：使用 github-pages-hosting 发布（后台运行）
```

---

## 第二部分：Skill 路由培训

### 2.1 意图识别

**提示词 5：从用户请求识别意图**

```
用户的请求可能不明确。你需要识别真实的意图：

例子 1：
用户说："我需要关于 Cisco ISE 的信息"
可能的意图：
- 学习 ISE 的基础知识 → webex-rag-query
- 查找 ISE 的最佳实践 → dump-techzone
- 查找 ISE 的 bug → dump-cdets
- 查找过去的 ISE 讨论 → second-brain

问题：你想要什么类型的信息？基础知识、最佳实践、bug 还是过去的讨论？

例子 2：
用户说："创建一个报告"
可能的意图：
- 创建 HTML 报告 → cisco-html-report
- 创建 PowerPoint 报告 → cisco-pptx
- 创建数据驱动的报告 → dump-cdets + cisco-html-report
- 创建演示文稿 → cisco-presentation

问题：你想要什么格式的报告？HTML、PowerPoint 还是演示文稿？

识别意图的技巧：
1. 听用户说了什么，也听他们没说什么
2. 考虑上下文（之前的对话、项目背景）
3. 如果不确定，问澄清问题
4. 根据用户的回答调整 Skill 选择
```

### 2.2 上下文感知路由

**提示词 6：使用上下文改进路由**

```
上下文可以帮助你做出更好的 Skill 选择：

上下文类型 1：项目背景
- 如果用户在做演示项目 → 优先使用演示相关 Skill
- 如果用户在做开发项目 → 优先使用开发相关 Skill
- 如果用户在做研究项目 → 优先使用研究相关 Skill

上下文类型 2：时间约束
- 如果用户时间紧张 → 使用快速 Skill
- 如果用户有充足时间 → 可以使用更全面的 Skill 组合

上下文类型 3：用户偏好
- 如果用户喜欢 HTML → 使用 cisco-html-report 而不是 cisco-pptx
- 如果用户喜欢 Markdown → 使用 marp-presentations 而不是 cisco-presentation
- 如果用户喜欢自动化 → 使用脚本而不是手动操作

上下文类型 4：可用资源
- 如果用户有网络访问 → 可以使用 research-with-sources
- 如果用户离线 → 只能使用本地 Skill
- 如果用户有 Cisco 访问权限 → 可以使用 Cisco 特定 Skill

使用上下文的例子：
用户说："我需要快速创建一个关于 Cisco ISE 的演示"
- 上下文：时间紧张，需要演示
- 选择：marp-presentations（快速）而不是 cisco-presentation（较慢）
- 理由：marp-presentations 可以从 Markdown 快速生成演示
```

### 2.3 错误恢复和备选方案

**提示词 7：处理 Skill 失败**

```
当一个 Skill 失败时，有备选方案：

失败场景 1：Skill 不可用
- 原因：Skill 未安装、配置错误或依赖缺失
- 恢复：
  1. 检查 Skill 是否已安装
  2. 检查配置是否正确
  3. 尝试重新加载 Skill
  4. 如果仍然失败，使用备选 Skill

失败场景 2：Skill 返回空结果
- 原因：搜索条件太严格、数据不存在或索引不完整
- 恢复：
  1. 尝试不同的搜索条件
  2. 使用更通用的 Skill（如 research-with-sources）
  3. 手动查找数据

失败场景 3：Skill 超时
- 原因：网络慢、数据量大或服务器响应慢
- 恢复：
  1. 重试（可能是临时问题）
  2. 使用更快的 Skill
  3. 分解任务为更小的部分

备选方案映射：
- second-brain 失败 → research-with-sources
- webex-rag-query 失败 → dump-techzone 或 research-with-sources
- dump-cdets 失败 → webex-rag-query 或 research-with-sources
- cisco-presentation 失败 → marp-presentations 或 html-ppt
- github-pages-hosting 失败 → 本地文件或其他托管方案

错误恢复的最佳实践：
1. 总是有备选方案
2. 不要让用户等待太久
3. 解释为什么选择了备选方案
4. 记录失败以便后续改进
```

---

## 第三部分：Skill 优化培训

### 3.1 性能优化

**提示词 8：优化 Skill 执行**

```
优化 Skill 执行可以提高效率：

优化技巧 1：并行执行
- 识别可以并行执行的 Skill
- 使用 concierge-orchestration 并行运行多个 Skill
- 等待所有 Skill 完成后合并结果

例子：
任务：创建关于 Cisco ISE 的综合报告
并行执行：
- second-brain 搜索过去的讨论
- webex-rag-query 查询知识库
- dump-techzone 获取文章
- dump-cdets 查找相关 bug

然后合并结果并创建报告。

优化技巧 2：缓存结果
- 如果同一个 Skill 被多次调用，缓存结果
- 避免重复的网络请求
- 检查缓存是否过期

优化技巧 3：增量处理
- 不要一次处理所有数据
- 分批处理数据
- 逐步返回结果给用户

例子：
任务：分析 100 个 SR
- 不要一次分析所有 100 个
- 先分析前 10 个，返回结果
- 然后继续分析其余的

优化技巧 4：选择合适的 Skill 粒度
- 对于简单任务，使用单个 Skill
- 对于复杂任务，组合多个 Skill
- 避免过度设计
```

### 3.2 质量优化

**提示词 9：确保 Skill 输出质量**

```
Skill 的输出质量很重要。确保质量的方法：

质量检查 1：验证输出
- 检查输出是否完整
- 检查输出是否准确
- 检查输出是否符合预期格式

例子：
使用 dump-cdets 后：
- 验证 bug 信息是否完整
- 验证 bug ID 是否正确
- 验证附件是否下载成功

质量检查 2：使用 quality-checker-ai
- 对于重要的输出，使用 quality-checker-ai 进行审查
- 自动检测和修复问题
- 生成质量报告

质量检查 3：使用 diplomatic-review
- 对于用户可见的内容，使用 diplomatic-review 审查
- 确保内容专业和准确
- 改进沟通

质量检查 4：用户反馈
- 询问用户是否满意
- 根据反馈调整 Skill 选择
- 记录反馈以改进未来的选择

质量优化的工作流：
1. 执行 Skill
2. 验证输出
3. 如果需要，使用 quality-checker-ai
4. 如果需要，使用 diplomatic-review
5. 返回给用户
6. 收集反馈
7. 改进下次的选择
```

### 3.3 成本优化

**提示词 10：优化 Skill 使用成本**

```
不同的 Skill 有不同的成本。优化成本的方法：

成本类型 1：API 调用成本
- 某些 Skill 需要 API 调用（如 research-with-sources）
- 优先使用免费的 Skill（如 second-brain）
- 只在必要时使用付费 Skill

成本类型 2：计算成本
- 某些 Skill 需要大量计算（如 codemap）
- 避免不必要的计算
- 使用缓存减少重复计算

成本类型 3：时间成本
- 某些 Skill 很慢（如 research-with-sources）
- 对于时间敏感的任务，使用快速 Skill
- 对于可以异步的任务，后台运行慢速 Skill

成本优化策略：
1. 优先使用免费 Skill
2. 避免不必要的 API 调用
3. 使用缓存和增量处理
4. 对于时间敏感的任务，使用快速 Skill
5. 监控成本并定期审查

成本优化的例子：
任务：创建关于 Cisco ISE 的报告

低成本方案：
1. 使用 second-brain 搜索过去的讨论（免费）
2. 使用 webex-rag-query 查询知识库（免费）
3. 使用 cisco-html-report 创建报告（免费）
4. 使用 github-pages-hosting 发布（免费）

高成本方案：
1. 使用 research-with-sources 进行网络搜索（付费）
2. 使用 dump-techzone 获取文章（可能付费）
3. 使用 cisco-presentation 创建演示（免费但慢）
4. 使用 github-pages-hosting 发布（免费）

选择低成本方案，除非用户明确需要更多信息。
```

---

## 第四部分：Skill 监控和改进

### 4.1 监控 Skill 性能

**提示词 11：使用监控系统改进 Skill 选择**

```
监控系统可以帮助你改进 Skill 选择：

监控指标 1：成功率
- 跟踪每个 Skill 的成功率
- 如果成功率低于 80%，考虑使用备选 Skill
- 定期审查成功率趋势

监控指标 2：执行时间
- 跟踪每个 Skill 的执行时间
- 如果执行时间过长，考虑使用更快的 Skill
- 优化慢速 Skill

监控指标 3：错误率
- 跟踪每个 Skill 的错误率
- 如果错误率高，调查原因
- 修复或替换有问题的 Skill

使用监控数据改进选择：
1. 定期审查 Skill 性能
2. 识别性能不佳的 Skill
3. 调查原因
4. 修复或替换 Skill
5. 验证改进

例子：
如果 second-brain 的成功率下降到 70%：
1. 调查原因（索引问题？数据不完整？）
2. 修复问题
3. 如果无法修复，使用 research-with-sources 作为备选
4. 监控改进情况
```

### 4.2 持续改进

**提示词 12：从经验中学习**

```
从每次 Skill 使用中学习可以改进未来的选择：

学习方法 1：记录决策
- 记录为什么选择了某个 Skill
- 记录结果是否满足预期
- 记录是否有更好的选择

学习方法 2：分析失败
- 当 Skill 失败时，分析原因
- 记录失败的原因
- 改进未来的选择以避免相同的失败

学习方法 3：收集反馈
- 询问用户是否满意
- 根据反馈调整选择
- 记录反馈以改进

学习方法 4：定期审查
- 定期审查 Skill 使用历史
- 识别模式和趋势
- 改进 Skill 选择策略

持续改进的工作流：
1. 使用 Skill
2. 记录决策和结果
3. 收集反馈
4. 分析数据
5. 识别改进机会
6. 更新 Skill 选择策略
7. 重复

例子：
经过 100 次使用后：
- 发现 second-brain 的成功率是 95%
- 发现 research-with-sources 的成功率是 85%
- 发现用户更喜欢 second-brain 的结果
- 决定优先使用 second-brain，只在必要时使用 research-with-sources
```

---

## 第五部分：Skill 选择决策框架

### 5.1 决策框架

**提示词 13：使用决策框架选择 Skill**

```
使用以下框架做出 Skill 选择决策：

步骤 1：理解需求
- 用户想要什么？
- 用户的真实意图是什么？
- 有什么约束条件（时间、资源、质量）？

步骤 2：识别候选 Skill
- 哪些 Skill 可以解决这个问题？
- 每个 Skill 的优缺点是什么？
- 是否需要组合多个 Skill？

步骤 3：评估候选 Skill
- 成功率：这个 Skill 有多可靠？
- 执行时间：这个 Skill 有多快？
- 成本：这个 Skill 的成本是多少？
- 质量：这个 Skill 的输出质量如何？

步骤 4：选择最佳 Skill
- 根据约束条件选择最佳 Skill
- 如果没有完美的 Skill，选择最接近的
- 准备备选方案

步骤 5：执行和验证
- 执行选定的 Skill
- 验证输出质量
- 如果不满意，使用备选方案

步骤 6：学习和改进
- 记录决策和结果
- 收集反馈
- 改进未来的选择

决策框架的例子：
用户请求："我需要关于 Cisco ISE 的最新信息"

步骤 1：理解需求
- 用户想要最新的 ISE 信息
- 用户可能想要最佳实践、新功能或 bug 修复
- 没有明确的时间约束

步骤 2：识别候选 Skill
- second-brain：搜索过去的讨论
- webex-rag-query：查询 ISE 知识库
- dump-techzone：获取 ISE 文章
- dump-cdets：查找 ISE bug
- research-with-sources：进行网络搜索

步骤 3：评估候选 Skill
- second-brain：成功率 95%，快速，免费，可能不是最新
- webex-rag-query：成功率 90%，快速，免费，可能不完整
- dump-techzone：成功率 85%，中等速度，免费，可能不全面
- dump-cdets：成功率 95%，快速，免费，只有 bug 信息
- research-with-sources：成功率 90%，慢速，付费，最全面

步骤 4：选择最佳 Skill
- 优先选择：webex-rag-query（快速、免费、可靠）
- 备选方案：second-brain 或 dump-techzone
- 如果需要最新信息：research-with-sources

步骤 5：执行和验证
- 执行 webex-rag-query
- 检查结果是否满足需求
- 如果不满足，使用备选方案

步骤 6：学习和改进
- 记录用户对结果的反馈
- 改进未来的选择
```

---

## 总结

本培训提示词提供了：
- **Skill 选择原则** — 如何选择合适的 Skill
- **Skill 路由策略** — 如何根据意图和上下文路由
- **Skill 优化方法** — 如何优化性能、质量和成本
- **Skill 监控和改进** — 如何从经验中学习
- **决策框架** — 如何系统地做出 Skill 选择决策

通过遵循这些培训提示词，AI Agent 可以做出更好的 Skill 选择，提高效率和质量。

---

**版本**：1.0.0  
**发布日期**：2026-06-17  
**状态**：生产就绪

# Skill 监控和告警最佳实践

## 概述

本文档提供了 Skill 监控系统的深度指南，包括：
- **监控架构** — 系统设计和数据流
- **告警策略** — 告警规则和响应流程
- **性能优化** — 监控性能和资源使用
- **案例研究** — 真实场景的监控实践

---

## 第一部分：监控架构

### 1.1 系统架构

```
┌─────────────────────────────────────────────────────────────┐
│                    Skill 执行层                              │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐      │
│  │  Skill A     │  │  Skill B     │  │  Skill C     │      │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘      │
└─────────┼──────────────────┼──────────────────┼──────────────┘
          │                  │                  │
          ▼                  ▼                  ▼
┌─────────────────────────────────────────────────────────────┐
│              执行监控层 (SkillExecutionMonitor)              │
│  ┌──────────────────────────────────────────────────────┐  │
│  │  monitor_execution()                                 │  │
│  │  - 记录执行日志                                      │  │
│  │  - 分析日志内容                                      │  │
│  │  - 保存元数据                                        │  │
│  └──────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
          │
          ▼
┌─────────────────────────────────────────────────────────────┐
│              数据存储层                                      │
│  ┌──────────────────┐  ┌──────────────────┐               │
│  │ data/executions/ │  │ reports/         │               │
│  │ - execution.log  │  │ - performance    │               │
│  │ - metadata.json  │  │ - analysis       │               │
│  └──────────────────┘  └──────────────────┘               │
└─────────────────────────────────────────────────────────────┘
          │
          ▼
┌─────────────────────────────────────────────────────────────┐
│              分析和告警层                                    │
│  ┌──────────────────────────────────────────────────────┐  │
│  │  analyze_performance()                               │  │
│  │  - 计算性能指标                                      │  │
│  │  - 检测异常                                          │  │
│  │  - 触发告警                                          │  │
│  └──────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
```

### 1.2 数据流

```
执行开始
   │
   ▼
┌─────────────────────────┐
│ 生成执行 ID             │
│ exec_<skill>_<timestamp>│
└────────────┬────────────┘
             │
             ▼
┌─────────────────────────┐
│ 执行 Skill              │
│ 生成日志                │
└────────────┬────────────┘
             │
             ▼
┌─────────────────────────┐
│ monitor_execution()     │
│ - 分析日志              │
│ - 提取指标              │
│ - 保存元数据            │
└────────────┬────────────┘
             │
             ▼
┌─────────────────────────┐
│ 存储执行数据            │
│ data/executions/        │
└────────────┬────────────┘
             │
             ▼
┌─────────────────────────┐
│ analyze_performance()   │
│ - 计算聚合指标          │
│ - 生成报告              │
│ - 检测异常              │
└────────────┬────────────┘
             │
             ▼
┌─────────────────────────┐
│ 触发告警（如需要）      │
│ - 发送通知              │
│ - 记录事件              │
└─────────────────────────┘
```

---

## 第二部分：告警策略

### 2.1 告警规则定义

#### 规则 1：成功率告警

```python
class SuccessRateAlert:
    """成功率告警规则"""
    
    CRITICAL_THRESHOLD = 50    # 严重：成功率 < 50%
    WARNING_THRESHOLD = 80     # 警告：成功率 < 80%
    
    @staticmethod
    def check(success_rate):
        if success_rate < SuccessRateAlert.CRITICAL_THRESHOLD:
            return {
                "level": "CRITICAL",
                "message": f"成功率严重下降: {success_rate}%",
                "action": "立即调查并修复"
            }
        elif success_rate < SuccessRateAlert.WARNING_THRESHOLD:
            return {
                "level": "WARNING",
                "message": f"成功率下降: {success_rate}%",
                "action": "监控并准备修复"
            }
        return {"level": "OK", "message": "成功率正常"}
```

#### 规则 2：错误数告警

```python
class ErrorCountAlert:
    """错误数告警规则"""
    
    CRITICAL_THRESHOLD = 10    # 严重：错误数 > 10
    WARNING_THRESHOLD = 5      # 警告：错误数 > 5
    
    @staticmethod
    def check(error_count):
        if error_count > ErrorCountAlert.CRITICAL_THRESHOLD:
            return {
                "level": "CRITICAL",
                "message": f"错误数过多: {error_count}",
                "action": "立即调查"
            }
        elif error_count > ErrorCountAlert.WARNING_THRESHOLD:
            return {
                "level": "WARNING",
                "message": f"错误数增加: {error_count}",
                "action": "监控趋势"
            }
        return {"level": "OK", "message": "错误数正常"}
```

#### 规则 3：性能下降告警

```python
class PerformanceDegradationAlert:
    """性能下降告警规则"""
    
    DEGRADATION_THRESHOLD = 5  # 下降 > 5%
    
    @staticmethod
    def check(current_rate, baseline_rate):
        degradation = baseline_rate - current_rate
        
        if degradation > PerformanceDegradationAlert.DEGRADATION_THRESHOLD:
            return {
                "level": "WARNING",
                "message": f"性能下降: {degradation:.2f}%",
                "baseline": baseline_rate,
                "current": current_rate,
                "action": "检查最近的更改"
            }
        return {"level": "OK", "message": "性能正常"}
```

### 2.2 告警响应流程

```python
def alert_response_workflow(skill_name, alert):
    """告警响应工作流"""
    
    # 步骤 1：记录告警
    log_alert(skill_name, alert)
    
    # 步骤 2：根据级别采取行动
    if alert["level"] == "CRITICAL":
        # 严重告警：立即通知
        notify_critical(skill_name, alert)
        
        # 自动回滚（如果有备份）
        if has_backup(skill_name):
            rollback_skill(skill_name)
        
        # 禁用 Skill
        disable_skill(skill_name)
        
    elif alert["level"] == "WARNING":
        # 普通告警：记录并监控
        notify_warning(skill_name, alert)
        
        # 增加监控频率
        increase_monitoring_frequency(skill_name)
    
    # 步骤 3：生成报告
    generate_alert_report(skill_name, alert)
    
    # 步骤 4：后续跟进
    schedule_followup(skill_name, alert)
```

### 2.3 告警通知

```python
def notify_critical(skill_name, alert):
    """发送严重告警通知"""
    
    message = f"""
    🚨 严重告警：{skill_name}
    
    问题：{alert['message']}
    级别：{alert['level']}
    建议：{alert['action']}
    
    时间：{datetime.now().isoformat()}
    
    请立即采取行动。
    """
    
    # 发送到多个渠道
    send_email(message)
    send_slack(message)
    send_webex(message)
    
    # 记录到日志
    log_critical(message)

def notify_warning(skill_name, alert):
    """发送普通告警通知"""
    
    message = f"""
    ⚠️ 告警：{skill_name}
    
    问题：{alert['message']}
    级别：{alert['level']}
    建议：{alert['action']}
    
    时间：{datetime.now().isoformat()}
    """
    
    # 发送到日志和 Slack
    log_warning(message)
    send_slack(message)
```

---

## 第三部分：监控实践

### 3.1 定期监控任务

#### 每日监控

```python
def daily_monitoring():
    """每日监控任务"""
    
    monitor = SkillExecutionMonitor()
    
    # 获取所有 Skill
    all_skills = get_all_skills()
    
    for skill_name in all_skills:
        # 分析最近 24 小时
        analysis = monitor.analyze_performance(skill_name, "24h")
        
        metrics = analysis['performance_metrics']
        
        # 检查成功率
        if metrics['success_rate'] < 80:
            alert = {
                "level": "WARNING",
                "message": f"成功率: {metrics['success_rate']}%",
                "skill": skill_name
            }
            alert_response_workflow(skill_name, alert)
        
        # 检查错误数
        if metrics['error_count'] > 5:
            alert = {
                "level": "WARNING",
                "message": f"错误数: {metrics['error_count']}",
                "skill": skill_name
            }
            alert_response_workflow(skill_name, alert)
        
        # 生成日报
        generate_daily_report(skill_name, analysis)

# 定时运行
schedule.every().day.at("09:00").do(daily_monitoring)
```

#### 每周监控

```python
def weekly_monitoring():
    """每周监控任务"""
    
    monitor = SkillExecutionMonitor()
    
    # 获取所有 Skill
    all_skills = get_all_skills()
    
    for skill_name in all_skills:
        # 分析最近 7 天
        analysis = monitor.analyze_performance(skill_name, "7d")
        
        # 对比基线
        baseline = load_baseline(skill_name)
        current = analysis['performance_metrics']
        
        degradation = baseline['success_rate'] - current['success_rate']
        
        if degradation > 5:
            alert = {
                "level": "WARNING",
                "message": f"性能下降: {degradation:.2f}%",
                "baseline": baseline['success_rate'],
                "current": current['success_rate']
            }
            alert_response_workflow(skill_name, alert)
        
        # 生成周报
        generate_weekly_report(skill_name, analysis)

# 定时运行
schedule.every().monday.at("09:00").do(weekly_monitoring)
```

### 3.2 监控仪表板

```python
def create_monitoring_dashboard():
    """创建监控仪表板"""
    
    monitor = SkillExecutionMonitor()
    
    # 获取所有 Skill 的性能数据
    all_skills = get_all_skills()
    dashboard_data = []
    
    for skill_name in all_skills:
        analysis = monitor.analyze_performance(skill_name, "24h")
        metrics = analysis['performance_metrics']
        
        dashboard_data.append({
            "skill": skill_name,
            "success_rate": metrics['success_rate'],
            "error_count": metrics['error_count'],
            "warning_count": metrics['total_warnings'],
            "total_executions": metrics['total_executions'],
            "status": get_status(metrics)
        })
    
    # 生成 HTML 仪表板
    html = generate_dashboard_html(dashboard_data)
    
    # 保存到文件
    with open("monitoring_dashboard.html", "w") as f:
        f.write(html)
    
    return html

def get_status(metrics):
    """获取 Skill 状态"""
    
    if metrics['success_rate'] < 50:
        return "🔴 严重"
    elif metrics['success_rate'] < 80:
        return "🟡 警告"
    else:
        return "🟢 正常"
```

---

## 第四部分：性能优化

### 4.1 监控性能

#### 优化日志分析

```python
# ❌ 低效：逐行扫描
def analyze_log_slow(log_content):
    errors = 0
    warnings = 0
    for line in log_content.split('\n'):
        if 'error' in line.lower():
            errors += 1
        if 'warning' in line.lower():
            warnings += 1
    return errors, warnings

# ✅ 高效：使用正则表达式
import re

def analyze_log_fast(log_content):
    errors = len(re.findall(r'\berror\b', log_content, re.IGNORECASE))
    warnings = len(re.findall(r'\bwarning\b', log_content, re.IGNORECASE))
    return errors, warnings
```

#### 批量分析优化

```python
# ❌ 低效：逐个分析
def analyze_all_skills_slow():
    monitor = SkillExecutionMonitor()
    for skill in all_skills:
        analysis = monitor.analyze_performance(skill)
        # 处理...

# ✅ 高效：批量分析
def analyze_all_skills_fast():
    monitor = SkillExecutionMonitor()
    
    # 并行分析
    from concurrent.futures import ThreadPoolExecutor
    
    with ThreadPoolExecutor(max_workers=4) as executor:
        futures = [
            executor.submit(monitor.analyze_performance, skill)
            for skill in all_skills
        ]
        results = [f.result() for f in futures]
    
    return results
```

### 4.2 存储优化

#### 日志压缩

```python
import gzip
import json

def compress_old_logs(days=30):
    """压缩旧日志"""
    
    from datetime import datetime, timedelta
    
    cutoff_date = datetime.now() - timedelta(days=days)
    
    for skill_dir in Path("data/executions").iterdir():
        for exec_dir in skill_dir.iterdir():
            log_file = exec_dir / "execution.log"
            
            if log_file.exists():
                # 检查文件日期
                mtime = datetime.fromtimestamp(log_file.stat().st_mtime)
                
                if mtime < cutoff_date:
                    # 压缩日志
                    with open(log_file, 'rb') as f_in:
                        with gzip.open(f"{log_file}.gz", 'wb') as f_out:
                            f_out.writelines(f_in)
                    
                    # 删除原文件
                    log_file.unlink()
```

#### 数据库存储

```python
# 使用数据库替代文件存储以提高性能
import sqlite3

def init_execution_db():
    """初始化执行数据库"""
    
    conn = sqlite3.connect("executions.db")
    cursor = conn.cursor()
    
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS executions (
            id TEXT PRIMARY KEY,
            skill_name TEXT,
            execution_id TEXT,
            timestamp DATETIME,
            success_rate REAL,
            error_count INTEGER,
            warning_count INTEGER,
            total_lines INTEGER
        )
    """)
    
    conn.commit()
    return conn

def store_execution_db(conn, skill_name, execution_id, metrics):
    """存储执行数据到数据库"""
    
    cursor = conn.cursor()
    
    cursor.execute("""
        INSERT INTO executions 
        (id, skill_name, execution_id, timestamp, success_rate, error_count, warning_count, total_lines)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        f"{skill_name}_{execution_id}",
        skill_name,
        execution_id,
        datetime.now(),
        metrics['success_rate'],
        metrics['error_count'],
        metrics['warning_count'],
        metrics['total_lines']
    ))
    
    conn.commit()
```

---

## 第五部分：案例研究

### 案例 1：检测性能下降

**场景**：`second-brain` Skill 的成功率从 95% 下降到 70%

**监控过程**：

```python
# 1. 发现问题
monitor = SkillExecutionMonitor()
analysis = monitor.analyze_performance("second-brain", "24h")
current_rate = analysis['performance_metrics']['success_rate']  # 70%

# 2. 对比基线
baseline = load_baseline("second-brain")
baseline_rate = baseline['success_rate']  # 95%

degradation = baseline_rate - current_rate  # 25%

# 3. 触发告警
if degradation > 5:
    alert = {
        "level": "CRITICAL",
        "message": f"性能下降: {degradation}%",
        "baseline": baseline_rate,
        "current": current_rate
    }
    alert_response_workflow("second-brain", alert)

# 4. 调查根本原因
executions = monitor.list_executions("second-brain", limit=50)
failed_executions = [e for e in executions if e['log_analysis']['has_errors']]

# 分析失败模式
error_patterns = {}
for exec_data in failed_executions:
    # 提取错误信息
    # ...

# 5. 修复问题
# - 检查最近的更新
# - 回滚到上一个版本
# - 或修复代码

# 6. 验证修复
new_analysis = monitor.analyze_performance("second-brain", "24h")
new_rate = new_analysis['performance_metrics']['success_rate']

if new_rate >= 90:
    print("✅ 问题已解决")
    update_baseline("second-brain", new_analysis)
```

### 案例 2：检测内存泄漏

**场景**：`skill-router` 的日志行数逐渐增加，表明可能有内存泄漏

**监控过程**：

```python
# 1. 收集数据
monitor = SkillExecutionMonitor()

# 分析最近 7 天的数据
analysis_7d = monitor.analyze_performance("skill-router", "7d")
metrics_7d = analysis_7d['performance_metrics']

# 2. 检测趋势
avg_lines = metrics_7d['avg_log_lines']
max_lines = metrics_7d['max_log_lines']
min_lines = metrics_7d['min_log_lines']

# 计算增长率
growth_rate = (max_lines - min_lines) / min_lines * 100

if growth_rate > 50:
    print(f"⚠️ 警告：日志行数增长 {growth_rate}%")
    print(f"   最小: {min_lines} 行")
    print(f"   最大: {max_lines} 行")
    print(f"   平均: {avg_lines} 行")

# 3. 调查原因
# - 检查代码中的日志输出
# - 查找循环中的日志
# - 检查是否有内存泄漏

# 4. 修复问题
# - 减少日志输出
# - 修复内存泄漏
# - 优化代码

# 5. 验证修复
new_analysis = monitor.analyze_performance("skill-router", "24h")
new_metrics = new_analysis['performance_metrics']

if new_metrics['avg_log_lines'] < avg_lines * 0.8:
    print("✅ 问题已解决")
```

---

## 总结

本文档提供了完整的 Skill 监控和告警策略：

| 主题 | 关键点 |
|------|--------|
| **架构** | 分层设计，数据流清晰 |
| **告警** | 多级规则，自动响应 |
| **实践** | 定期监控，仪表板展示 |
| **优化** | 性能优化，存储优化 |
| **案例** | 真实场景，完整流程 |

通过实施本指南，您可以建立一个健壮的 Skill 监控系统。

---

**版本**：1.0.0  
**发布日期**：2026-06-17  
**状态**：生产就绪

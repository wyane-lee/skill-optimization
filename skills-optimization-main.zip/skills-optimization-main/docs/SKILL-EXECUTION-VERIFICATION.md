# Agent 有效调用 Skills 的机制与验证

## 问题分析

### 当前痛点
1. **调用失效** — Agent 选了 Skill，但 Skill 没有真正执行或执行不完整
2. **黑盒执行** — Agent 不知道 Skill 是否真的在工作
3. **反馈缺失** — 没有机制验证 Skill 执行结果

### 根本原因
- Agent 和 Skill 之间缺少**执行契约**（execution contract）
- 没有**验证层**来确认 Skill 真正执行
- 缺少**反馈机制**来告诉 Agent 执行状态

---

## 解决方案：三层验证架构

### 第 1 层：Skill 调用前验证（Pre-Execution）

#### 1.1 Skill 可用性检查
```python
def verify_skill_available(skill_name):
    """检查 Skill 是否真的存在且可用"""
    checks = {
        "skill_exists": skill_name in SKILL_REGISTRY,
        "skill_file_exists": Path(f"~/.config/opencode/skills/{skill_name}/SKILL.md").exists(),
        "skill_executable": check_skill_dependencies(skill_name),
        "skill_not_deprecated": SKILL_REGISTRY[skill_name].priority != "deprecated",
    }
    
    if not all(checks.values()):
        raise SkillNotAvailableError(f"Skill {skill_name} 不可用: {checks}")
    
    return True
```

#### 1.2 前置条件验证
```python
def verify_preconditions(skill_name, user_request):
    """验证 Skill 执行的前置条件"""
    skill = SKILL_REGISTRY[skill_name]
    
    # 检查必要的工具/权限
    required_tools = skill.required_tools  # 如 "bash", "read", "grep"
    available_tools = get_available_tools()
    
    if not all(t in available_tools for t in required_tools):
        raise PreconditionError(f"缺少必要工具: {required_tools}")
    
    # 检查数据源可访问性
    if skill.data_source == "webex":
        if not check_webex_token():
            raise PreconditionError("Webex token 过期或缺失")
    
    # 检查参数有效性
    if not validate_skill_params(skill_name, user_request):
        raise PreconditionError(f"参数无效: {user_request}")
    
    return True
```

#### 1.3 冲突检测
```python
def detect_conflicts(skill_name, current_context):
    """检查是否与当前上下文冲突"""
    conflicts = {
        "file_lock": check_file_locks(skill_name),
        "resource_busy": check_resource_availability(skill_name),
        "incompatible_state": check_state_compatibility(skill_name, current_context),
    }
    
    if any(conflicts.values()):
        return conflicts
    
    return None
```

---

### 第 2 层：Skill 执行中监控（Execution Monitoring）

#### 2.1 执行追踪
```python
class SkillExecutionTracker:
    """实时追踪 Skill 执行状态"""
    
    def __init__(self, skill_name, execution_id):
        self.skill_name = skill_name
        self.execution_id = execution_id
        self.start_time = time.time()
        self.events = []
        self.state = "initializing"
    
    def log_event(self, event_type, details):
        """记录执行事件"""
        self.events.append({
            "timestamp": time.time(),
            "type": event_type,  # "started", "tool_call", "tool_result", "completed", "failed"
            "details": details,
        })
    
    def get_status(self):
        """获取当前执行状态"""
        return {
            "skill": self.skill_name,
            "execution_id": self.execution_id,
            "state": self.state,
            "elapsed": time.time() - self.start_time,
            "events": self.events,
            "last_event": self.events[-1] if self.events else None,
        }
```

#### 2.2 工具调用验证
```python
def verify_tool_execution(tool_name, tool_args, tool_result):
    """验证工具是否真的执行了"""
    
    # 检查 1：工具是否返回了结果
    if tool_result is None or tool_result == "":
        return {
            "executed": False,
            "reason": "工具未返回结果",
            "severity": "critical",
        }
    
    # 检查 2：结果是否包含预期的数据
    if tool_name == "read" and len(tool_result) < 10:
        return {
            "executed": False,
            "reason": "读取结果过短，可能文件不存在",
            "severity": "high",
        }
    
    # 检查 3：结果是否包含错误信息
    if "error" in tool_result.lower() or "failed" in tool_result.lower():
        return {
            "executed": False,
            "reason": f"工具返回错误: {tool_result[:100]}",
            "severity": "high",
        }
    
    # 检查 4：对于 bash 命令，检查返回码
    if tool_name == "bash":
        if "exit code" in tool_result and "non-zero" in tool_result:
            return {
                "executed": False,
                "reason": "bash 命令执行失败",
                "severity": "high",
            }
    
    return {
        "executed": True,
        "reason": "工具成功执行",
        "severity": "none",
    }
```

#### 2.3 超时检测
```python
def monitor_execution_timeout(skill_name, max_duration=300):
    """监控 Skill 执行是否超时"""
    
    tracker = get_execution_tracker(skill_name)
    elapsed = time.time() - tracker.start_time
    
    if elapsed > max_duration:
        return {
            "timed_out": True,
            "elapsed": elapsed,
            "max_duration": max_duration,
            "action": "kill_skill_and_rollback",
        }
    
    return {"timed_out": False}
```

---

### 第 3 层：Skill 执行后验证（Post-Execution）

#### 3.1 输出验证
```python
def verify_skill_output(skill_name, expected_output_type, actual_output):
    """验证 Skill 的输出是否符合预期"""
    
    validations = {
        "output_exists": actual_output is not None,
        "output_type_correct": isinstance(actual_output, expected_output_type),
        "output_not_empty": len(str(actual_output)) > 0,
        "output_valid_format": validate_output_format(skill_name, actual_output),
    }
    
    if not all(validations.values()):
        return {
            "valid": False,
            "failures": [k for k, v in validations.items() if not v],
        }
    
    return {"valid": True}
```

#### 3.2 副作用验证
```python
def verify_side_effects(skill_name, expected_effects):
    """验证 Skill 是否产生了预期的副作用"""
    
    effects = {
        "files_created": [],
        "files_modified": [],
        "network_calls": [],
        "database_changes": [],
    }
    
    # 检查文件系统变化
    for file_path in expected_effects.get("files_created", []):
        if Path(file_path).exists():
            effects["files_created"].append(file_path)
    
    # 检查网络调用（从日志）
    for api_call in expected_effects.get("api_calls", []):
        if check_api_call_log(api_call):
            effects["network_calls"].append(api_call)
    
    # 检查数据库变化
    for db_change in expected_effects.get("db_changes", []):
        if verify_db_change(db_change):
            effects["database_changes"].append(db_change)
    
    return {
        "all_effects_verified": all(
            len(effects[k]) == len(expected_effects.get(k, []))
            for k in effects
        ),
        "effects": effects,
    }
```

#### 3.3 结果完整性检查
```python
def verify_result_completeness(skill_name, result):
    """验证结果是否完整"""
    
    skill = SKILL_REGISTRY[skill_name]
    required_fields = skill.output_schema.required_fields
    
    missing_fields = [f for f in required_fields if f not in result]
    
    if missing_fields:
        return {
            "complete": False,
            "missing_fields": missing_fields,
            "severity": "high",
        }
    
    return {"complete": True}
```

---

## 实现方案：Agent 执行流程

### 完整的 Skill 调用流程

```
┌─────────────────────────────────────────────────────────────┐
│ 1. 用户请求                                                 │
│    "搜索关于 ISE 的 Webex 讨论"                             │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│ 2. Skill 选择（使用智能路由）                               │
│    - 匹配：second-brain (primary) + webex-rag-query (alt)   │
│    - 选择：second-brain                                     │
│    - 理由：统一搜索，覆盖更全                               │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│ 3. 执行前验证（Pre-Execution）                              │
│    ✓ Skill 存在且可用                                       │
│    ✓ Webex token 有效                                       │
│    ✓ 参数有效                                               │
│    ✓ 无资源冲突                                             │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│ 4. 执行中监控（Execution Monitoring）                       │
│    - 创建 execution_id: exec_abc123                         │
│    - 追踪每个工具调用                                       │
│    - 监控超时（max 300s）                                   │
│    - 实时日志记录                                           │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│ 5. 工具执行验证（Tool Verification）                        │
│    - 检查工具是否返回结果                                   │
│    - 检查结果是否包含错误                                   │
│    - 验证返回码（bash）                                     │
│    - 确认数据完整性                                         │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│ 6. 执行后验证（Post-Execution）                             │
│    ✓ 输出格式正确                                           │
│    ✓ 输出不为空                                             │
│    ✓ 副作用已产生（文件创建、API 调用等）                   │
│    ✓ 结果完整性检查                                         │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│ 7. 结果返回与反馈                                           │
│    {                                                         │
│      "skill": "second-brain",                               │
│      "execution_id": "exec_abc123",                         │
│      "status": "success",                                   │
│      "result": [...],                                       │
│      "verification": {                                      │
│        "pre_execution": "passed",                           │
│        "execution": "completed",                            │
│        "post_execution": "passed",                          │
│        "total_time": 2.34,                                  │
│      }                                                       │
│    }                                                         │
└─────────────────────────────────────────────────────────────┘
```

---

## 关键机制：执行证明（Proof of Execution）

### 每个 Skill 执行都应该产生：

#### 1. 执行日志
```json
{
  "execution_id": "exec_abc123",
  "skill_name": "second-brain",
  "timestamp": "2026-06-17T14:30:00Z",
  "status": "success",
  "events": [
    {
      "time": "14:30:00.001",
      "type": "started",
      "details": "Skill 开始执行"
    },
    {
      "time": "14:30:00.050",
      "type": "tool_call",
      "tool": "grep",
      "args": {"pattern": "ISE", "path": "..."}
    },
    {
      "time": "14:30:00.150",
      "type": "tool_result",
      "tool": "grep",
      "result_lines": 42,
      "verified": true
    },
    {
      "time": "14:30:02.340",
      "type": "completed",
      "details": "Skill 成功完成"
    }
  ]
}
```

#### 2. 验证报告
```json
{
  "execution_id": "exec_abc123",
  "verifications": {
    "pre_execution": {
      "skill_available": true,
      "preconditions_met": true,
      "no_conflicts": true
    },
    "execution": {
      "all_tools_executed": true,
      "no_timeouts": true,
      "no_errors": true
    },
    "post_execution": {
      "output_valid": true,
      "side_effects_verified": true,
      "result_complete": true
    }
  },
  "overall_status": "verified_success"
}
```

#### 3. 可审计的痕迹
```
~/.opencode/skill-executions/
├── exec_abc123/
│   ├── metadata.json          # 执行元数据
│   ├── execution.log          # 完整执行日志
│   ├── verification.json      # 验证报告
│   ├── input.json             # 输入参数
│   ├── output.json            # 输出结果
│   └── artifacts/             # 生成的文件
│       ├── search_results.json
│       └── ...
```

---

## Agent 决策逻辑

### 如果 Skill 执行失败，Agent 应该：

```python
def handle_skill_failure(skill_name, execution_result):
    """处理 Skill 执行失败"""
    
    failure_type = execution_result.get("failure_type")
    
    if failure_type == "precondition_failed":
        # 例：Webex token 过期
        action = "ask_user_to_refresh_token"
    
    elif failure_type == "tool_execution_failed":
        # 例：grep 命令失败
        action = "retry_with_different_approach"
    
    elif failure_type == "output_invalid":
        # 例：输出格式错误
        action = "try_alternative_skill"
    
    elif failure_type == "timeout":
        # 例：执行超过 5 分钟
        action = "kill_and_try_alternative"
    
    elif failure_type == "deprecated":
        # 例：Skill 已弃用
        action = "use_recommended_alternative"
    
    return {
        "failure_type": failure_type,
        "action": action,
        "alternative_skill": get_alternative_skill(skill_name),
        "retry_count": execution_result.get("retry_count", 0),
    }
```

---

## 实现优先级

### 立即实现（Phase C）
1. ✅ **执行追踪** — 为每个 Skill 调用生成 execution_id
2. ✅ **工具验证** — 检查工具是否真的返回了结果
3. ✅ **输出验证** — 验证输出格式和完整性

### 短期实现（Phase D）
4. **执行日志** — 记录所有执行事件
5. **验证报告** — 生成可审计的验证报告
6. **失败处理** — 自动重试或切换 Skill

### 长期实现（Phase E）
7. **执行统计** — 追踪 Skill 成功率
8. **性能监控** — 监控 Skill 执行时间
9. **学习反馈** — 根据历史结果优化 Skill 选择

---

## 示例：完整的验证流程

### 场景：Agent 调用 `second-brain` 搜索 Webex

```python
# 1. 选择 Skill
skill_name = "second-brain"
user_request = "搜索关于 ISE 的 Webex 讨论"

# 2. 执行前验证
pre_checks = {
    "skill_available": verify_skill_available(skill_name),
    "preconditions": verify_preconditions(skill_name, user_request),
    "conflicts": detect_conflicts(skill_name, current_context),
}

if not all(pre_checks.values()):
    return {"status": "failed", "reason": "precondition failed"}

# 3. 创建执行追踪器
tracker = SkillExecutionTracker(skill_name, execution_id="exec_abc123")
tracker.log_event("started", {"request": user_request})

# 4. 执行 Skill（调用工具）
tools_called = []
for tool_call in skill.tool_calls:
    tracker.log_event("tool_call", {"tool": tool_call.name})
    
    result = execute_tool(tool_call)
    
    # 验证工具执行
    verification = verify_tool_execution(tool_call.name, tool_call.args, result)
    tracker.log_event("tool_result", {
        "tool": tool_call.name,
        "verified": verification["executed"],
        "result_length": len(result),
    })
    
    if not verification["executed"]:
        tracker.log_event("failed", {"reason": verification["reason"]})
        return {"status": "failed", "reason": verification["reason"]}
    
    tools_called.append({
        "name": tool_call.name,
        "result": result,
        "verified": True,
    })

# 5. 执行后验证
output = skill.process_results(tools_called)

post_checks = {
    "output_valid": verify_skill_output(skill_name, dict, output),
    "side_effects": verify_side_effects(skill_name, expected_effects),
    "complete": verify_result_completeness(skill_name, output),
}

tracker.log_event("completed", {"status": "success"})

# 6. 返回结果和验证报告
return {
    "status": "success",
    "execution_id": "exec_abc123",
    "result": output,
    "verification": {
        "pre_execution": all(pre_checks.values()),
        "execution": all(v["verified"] for v in tools_called),
        "post_execution": all(post_checks.values()),
        "overall": "verified_success",
    },
    "execution_log": tracker.get_status(),
}
```

---

## 总结

### Agent 有效调用 Skills 的 3 个关键要素

1. **执行前验证** — 确保 Skill 可用且条件满足
2. **执行中监控** — 追踪每个工具调用，验证真正执行
3. **执行后验证** — 检查输出和副作用，确保完整

### 确保 Skills 真正执行的 5 个检查点

1. ✅ **Skill 存在** — 文件系统中真的有这个 Skill
2. ✅ **工具返回结果** — 每个工具调用都有输出
3. ✅ **结果有效** — 输出格式正确，不是错误信息
4. ✅ **副作用产生** — 文件创建、API 调用等真的发生了
5. ✅ **结果完整** — 所有必要字段都存在

### 可审计的证明

每次 Skill 执行都应该产生：
- 执行日志（所有事件）
- 验证报告（所有检查）
- 输入输出（完整记录）
- 可追踪的 execution_id

这样 Agent 和用户都能看到 Skill 是否真的执行了，以及执行的每一步。

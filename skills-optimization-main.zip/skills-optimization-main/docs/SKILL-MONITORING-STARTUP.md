# 第一时间启动 Skill 监控机制

## 问题

当前的监控机制是 **事后验证**（Skill 执行完后才能查看日志）。但用户需要 **第一时间启动** 监控，即：

1. **在 Skill 被调用之前** — 预先配置监控
2. **在 Skill 执行时** — 实时追踪执行过程
3. **在 Skill 执行后** — 立即获得验证结果

---

## 解决方案：三阶段启动机制

### 阶段 1：预启动（Skill 调用前）

#### 1.1 启动监控守护进程

**目的**：在后台持续监控 Skill 执行目录，实时捕获新的执行

**实现方式**：
```bash
#!/bin/bash
# ~/bin/skill-monitor-daemon.sh

# 启动监控守护进程
skill_monitor_daemon() {
    local watch_dir="$HOME/.opencode/skill-executions"
    local last_check=$(date +%s)
    
    echo "[$(date)] Skill Monitor Daemon started"
    echo "Watching: $watch_dir"
    
    while true; do
        # 每 0.5 秒检查一次新的执行
        sleep 0.5
        
        # 找到最新的执行目录
        latest=$(ls -t "$watch_dir" 2>/dev/null | head -1)
        
        if [ -n "$latest" ]; then
            latest_time=$(stat -f %m "$watch_dir/$latest" 2>/dev/null || echo 0)
            
            # 如果有新的执行（时间戳更新）
            if [ "$latest_time" -gt "$last_check" ]; then
                last_check=$latest_time
                
                # 触发实时监控
                _monitor_execution "$latest"
            fi
        fi
    done
}

# 实时监控单个执行
_monitor_execution() {
    local execution_id=$1
    local exec_dir="$HOME/.opencode/skill-executions/$execution_id"
    
    echo ""
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "[$(date)] 🚀 Skill 执行开始"
    echo "Execution ID: $execution_id"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    
    # 实时显示执行日志
    tail -f "$exec_dir/execution.log" &
    local tail_pid=$!
    
    # 等待执行完成（检查 execution-report.json）
    while [ ! -f "$exec_dir/execution-report.json" ]; do
        sleep 0.1
    done
    
    # 停止 tail
    kill $tail_pid 2>/dev/null
    
    # 显示最终结果
    _show_execution_result "$execution_id"
}

# 显示执行结果
_show_execution_result() {
    local execution_id=$1
    local exec_dir="$HOME/.opencode/skill-executions/$execution_id"
    local report="$exec_dir/execution-report.json"
    
    if [ ! -f "$report" ]; then
        return
    fi
    
    local status=$(jq -r '.status' "$report")
    local skill_name=$(jq -r '.skill_name' "$report")
    local elapsed=$(jq -r '.elapsed_seconds' "$report")
    
    echo ""
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    
    if [ "$status" = "success" ]; then
        echo "✅ Skill 执行成功"
    else
        echo "❌ Skill 执行失败"
    fi
    
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "Skill: $skill_name"
    echo "Status: $status"
    echo "Elapsed: ${elapsed}s"
    echo "Execution ID: $execution_id"
    echo ""
    echo "验证报告："
    jq '{
        status: .status,
        skill_name: .skill_name,
        elapsed_seconds: .elapsed_seconds,
        preconditions_passed: (.preconditions | all),
        tool_calls_success: (.tool_calls | map(.status == "success") | all),
        output_valid: (.output_verification | all),
        side_effects_valid: (.side_effects | all)
    }' "$report"
    echo ""
    echo "查看详细报告："
    echo "  cat $report | jq"
    echo ""
    echo "查看执行日志："
    echo "  cat $exec_dir/execution.log"
    echo ""
    echo "查看生成的工件："
    echo "  ls -la $exec_dir/artifacts/"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
}

# 启动守护进程
skill_monitor_daemon
```

**使用方式**：
```bash
# 在后台启动监控守护进程
nohup ~/bin/skill-monitor-daemon.sh > ~/.opencode/skill-monitor.log 2>&1 &

# 或者在 tmux 中启动
tmux new-session -d -s skill-monitor "~/bin/skill-monitor-daemon.sh"
```

#### 1.2 配置 launchd 自动启动

**目的**：让监控守护进程在系统启动时自动运行

**实现方式**：
```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.opencode.skill-monitor</string>
    
    <key>ProgramArguments</key>
    <array>
        <string>/bin/bash</string>
        <string>/Users/wenfeli/bin/skill-monitor-daemon.sh</string>
    </array>
    
    <key>RunAtLoad</key>
    <true/>
    
    <key>KeepAlive</key>
    <true/>
    
    <key>StandardOutPath</key>
    <string>/Users/wenfeli/.opencode/skill-monitor.log</string>
    
    <key>StandardErrorPath</key>
    <string>/Users/wenfeli/.opencode/skill-monitor-error.log</string>
    
    <key>WorkingDirectory</key>
    <string>/Users/wenfeli</string>
</dict>
</plist>
```

**安装方式**：
```bash
# 1. 创建 plist 文件
cat > ~/Library/LaunchAgents/com.opencode.skill-monitor.plist << 'EOF'
[上面的 XML 内容]
EOF

# 2. 加载 launchd 服务
launchctl load ~/Library/LaunchAgents/com.opencode.skill-monitor.plist

# 3. 验证服务是否运行
launchctl list | grep skill-monitor

# 4. 查看日志
tail -f ~/.opencode/skill-monitor.log
```

---

### 阶段 2：实时监控（Skill 执行时）

#### 2.1 实时日志流

**目的**：在 Skill 执行时实时显示执行日志

**实现方式**：
```bash
#!/bin/bash
# ~/bin/skill-watch.sh - 实时监控 Skill 执行

skill_watch() {
    local execution_id=$1
    
    if [ -z "$execution_id" ]; then
        # 如果没有指定 execution_id，监控最新的执行
        execution_id=$(ls -t ~/.opencode/skill-executions/ 2>/dev/null | head -1)
    fi
    
    if [ -z "$execution_id" ]; then
        echo "❌ 没有找到 Skill 执行"
        return 1
    fi
    
    local exec_dir="$HOME/.opencode/skill-executions/$execution_id"
    local log_file="$exec_dir/execution.log"
    
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "📊 实时监控 Skill 执行"
    echo "Execution ID: $execution_id"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo ""
    
    # 实时显示日志
    if [ -f "$log_file" ]; then
        tail -f "$log_file"
    else
        echo "⏳ 等待执行日志..."
        while [ ! -f "$log_file" ]; do
            sleep 0.1
        done
        tail -f "$log_file"
    fi
}

skill_watch "$@"
```

**使用方式**：
```bash
# 监控最新的执行
skill-watch

# 监控特定的执行
skill-watch exec_second-brain_52098672
```

#### 2.2 实时仪表板

**目的**：在终端中显示实时的执行状态仪表板

**实现方式**：
```bash
#!/bin/bash
# ~/bin/skill-dashboard.sh - 实时仪表板

skill_dashboard() {
    while true; do
        clear
        
        echo "╔════════════════════════════════════════════════════════════════╗"
        echo "║           🎯 Skill 执行实时仪表板                              ║"
        echo "╚════════════════════════════════════════════════════════════════╝"
        echo ""
        
        # 显示最近的 5 个执行
        echo "📋 最近的执行："
        echo ""
        
        local count=0
        for exec_dir in $(ls -t ~/.opencode/skill-executions/ 2>/dev/null | head -5); do
            count=$((count + 1))
            
            local report="$HOME/.opencode/skill-executions/$exec_dir/execution-report.json"
            
            if [ -f "$report" ]; then
                local skill_name=$(jq -r '.skill_name' "$report")
                local status=$(jq -r '.status' "$report")
                local elapsed=$(jq -r '.elapsed_seconds' "$report")
                local timestamp=$(jq -r '.timestamp' "$report")
                
                # 显示状态图标
                if [ "$status" = "success" ]; then
                    local icon="✅"
                else
                    local icon="❌"
                fi
                
                printf "%d. %s %-30s [%s] %.3fs\n" "$count" "$icon" "$skill_name" "$status" "$elapsed"
            else
                # 执行还在进行中
                local log_file="$HOME/.opencode/skill-executions/$exec_dir/execution.log"
                if [ -f "$log_file" ]; then
                    local skill_name=$(grep "skill_name:" "$log_file" | head -1 | awk -F': ' '{print $2}')
                    printf "%d. ⏳ %-30s [running]\n" "$count" "$skill_name"
                fi
            fi
        done
        
        echo ""
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo ""
        
        # 显示统计信息
        echo "📊 统计信息："
        echo ""
        
        local total=$(ls -1 ~/.opencode/skill-executions/ 2>/dev/null | wc -l)
        local success=$(find ~/.opencode/skill-executions/ -name "execution-report.json" -exec grep -l '"status": "success"' {} \; 2>/dev/null | wc -l)
        local failed=$(find ~/.opencode/skill-executions/ -name "execution-report.json" -exec grep -l '"status": "failed"' {} \; 2>/dev/null | wc -l)
        
        echo "总执行数: $total"
        echo "成功: $success"
        echo "失败: $failed"
        echo "成功率: $(echo "scale=2; $success * 100 / $total" | bc)%"
        
        echo ""
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo ""
        echo "按 Ctrl+C 退出，每 2 秒刷新一次"
        echo ""
        
        sleep 2
    done
}

skill_dashboard
```

**使用方式**：
```bash
# 启动实时仪表板
skill-dashboard
```

---

### 阶段 3：立即反馈（Skill 执行后）

#### 3.1 自动通知

**目的**：Skill 执行完成后立即通知用户

**实现方式**：
```bash
#!/bin/bash
# ~/bin/skill-notify.sh - 自动通知

skill_notify() {
    local execution_id=$1
    local exec_dir="$HOME/.opencode/skill-executions/$execution_id"
    local report="$exec_dir/execution-report.json"
    
    if [ ! -f "$report" ]; then
        return
    fi
    
    local status=$(jq -r '.status' "$report")
    local skill_name=$(jq -r '.skill_name' "$report")
    local elapsed=$(jq -r '.elapsed_seconds' "$report")
    
    # macOS 通知
    if command -v osascript &> /dev/null; then
        if [ "$status" = "success" ]; then
            osascript -e "display notification \"$skill_name 执行成功 (${elapsed}s)\" with title \"Skill 执行完成\""
        else
            osascript -e "display notification \"$skill_name 执行失败\" with title \"Skill 执行失败\""
        fi
    fi
    
    # 终端通知
    echo ""
    echo "╔════════════════════════════════════════════════════════════════╗"
    if [ "$status" = "success" ]; then
        echo "║ ✅ Skill 执行成功                                            ║"
    else
        echo "║ ❌ Skill 执行失败                                            ║"
    fi
    echo "╚════════════════════════════════════════════════════════════════╝"
    echo "Skill: $skill_name"
    echo "Status: $status"
    echo "Elapsed: ${elapsed}s"
    echo "Execution ID: $execution_id"
    echo ""
}
```

#### 3.2 自动生成报告

**目的**：Skill 执行完成后自动生成可读的报告

**实现方式**：
```bash
#!/bin/bash
# ~/bin/skill-report.sh - 生成执行报告

skill_report() {
    local execution_id=$1
    
    if [ -z "$execution_id" ]; then
        execution_id=$(ls -t ~/.opencode/skill-executions/ | head -1)
    fi
    
    local exec_dir="$HOME/.opencode/skill-executions/$execution_id"
    local report="$exec_dir/execution-report.json"
    
    if [ ! -f "$report" ]; then
        echo "❌ 报告文件不存在"
        return 1
    fi
    
    echo "╔════════════════════════════════════════════════════════════════╗"
    echo "║                    📄 Skill 执行报告                           ║"
    echo "╚════════════════════════════════════════════════════════════════╝"
    echo ""
    
    # 基本信息
    echo "📋 基本信息"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    jq '{
        skill_name: .skill_name,
        status: .status,
        elapsed_seconds: .elapsed_seconds,
        timestamp: .timestamp
    }' "$report" | sed 's/^/  /'
    echo ""
    
    # 前置条件
    echo "✅ 前置条件检查"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    jq '.preconditions | to_entries[] | "  \(.key): \(.value)"' -r "$report"
    echo ""
    
    # 工具调用
    echo "🔧 工具调用"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    jq '.tool_calls[] | "  \(.tool_name): \(.status)"' -r "$report"
    echo ""
    
    # 输出验证
    echo "📊 输出验证"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    jq '.output_verification | to_entries[] | "  \(.key): \(.value)"' -r "$report"
    echo ""
    
    # 副作用
    echo "⚙️  副作用"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    jq '.side_effects | to_entries[] | "  \(.key): \(.value)"' -r "$report"
    echo ""
    
    # 生成的工件
    echo "📦 生成的工件"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    if [ -d "$exec_dir/artifacts" ]; then
        ls -lh "$exec_dir/artifacts/" | tail -n +2 | awk '{print "  " $9 " (" $5 ")"}'
    else
        echo "  (无)"
    fi
    echo ""
    
    echo "╔════════════════════════════════════════════════════════════════╗"
    echo "║                        报告生成完成                            ║"
    echo "╚════════════════════════════════════════════════════════════════╝"
}

skill_report "$@"
```

---

## 快速启动指南

### 步骤 1：创建监控脚本

```bash
# 创建脚本目录
mkdir -p ~/bin

# 复制监控脚本
cp docs/scripts/skill-monitor-daemon.sh ~/bin/
cp docs/scripts/skill-watch.sh ~/bin/
cp docs/scripts/skill-dashboard.sh ~/bin/
cp docs/scripts/skill-notify.sh ~/bin/
cp docs/scripts/skill-report.sh ~/bin/

# 赋予执行权限
chmod +x ~/bin/skill-*.sh
```

### 步骤 2：启动监控守护进程

```bash
# 方式 1：在后台启动
nohup ~/bin/skill-monitor-daemon.sh > ~/.opencode/skill-monitor.log 2>&1 &

# 方式 2：在 tmux 中启动
tmux new-session -d -s skill-monitor "~/bin/skill-monitor-daemon.sh"

# 方式 3：使用 launchd 自动启动（推荐）
cp docs/com.opencode.skill-monitor.plist ~/Library/LaunchAgents/
launchctl load ~/Library/LaunchAgents/com.opencode.skill-monitor.plist
```

### 步骤 3：创建别名

```bash
# 添加到 ~/.zshrc 或 ~/.bashrc
alias skill-watch='~/bin/skill-watch.sh'
alias skill-dashboard='~/bin/skill-dashboard.sh'
alias skill-report='~/bin/skill-report.sh'
alias skill-check='cat ~/.opencode/skill-executions/$(ls -t ~/.opencode/skill-executions/ | head -1)/execution-report.json | jq'
```

### 步骤 4：验证监控

```bash
# 查看监控日志
tail -f ~/.opencode/skill-monitor.log

# 查看 launchd 状态
launchctl list | grep skill-monitor

# 手动触发一个 Skill 执行，观察监控反应
```

---

## 监控工作流

```
┌─────────────────────────────────────────────────────────────┐
│ 1. 预启动（Skill 调用前）                                   │
│    - 启动监控守护进程                                       │
│    - 配置 launchd 自动启动                                  │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│ 2. 实时监控（Skill 执行时）                                 │
│    - 监控守护进程检测到新执行                               │
│    - 实时显示执行日志                                       │
│    - 显示实时仪表板                                         │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│ 3. 立即反馈（Skill 执行后）                                 │
│    - 自动通知用户（macOS 通知 + 终端通知）                  │
│    - 自动生成执行报告                                       │
│    - 显示验证结果                                           │
└─────────────────────────────────────────────────────────────┘
```

---

## 监控命令速查表

| 命令 | 用途 | 示例 |
|------|------|------|
| `skill-watch` | 实时监控最新执行 | `skill-watch` |
| `skill-watch <id>` | 监控特定执行 | `skill-watch exec_second-brain_52098672` |
| `skill-dashboard` | 显示实时仪表板 | `skill-dashboard` |
| `skill-report` | 生成执行报告 | `skill-report` |
| `skill-report <id>` | 生成特定执行的报告 | `skill-report exec_second-brain_52098672` |
| `skill-check` | 快速检查最新执行 | `skill-check` |

---

## 下一步

1. **立即启动** — 运行 `launchctl load ~/Library/LaunchAgents/com.opencode.skill-monitor.plist`
2. **测试监控** — 手动触发一个 Skill 执行，观察监控反应
3. **集成到 Agent** — 让 Agent 在调用 Skill 时自动提供 execution_id
4. **建立告警** — 当 Skill 执行失败时自动告警

---

## 参考资源

- [SKILL-CALL-CONFIRMATION.md](SKILL-CALL-CONFIRMATION.md) — Skill 调用确认机制
- [SKILL-EXECUTION-VERIFICATION.md](SKILL-EXECUTION-VERIFICATION.md) — 验证机制设计
- [skill-execution-verifier.py](../tools/skill-execution-verifier.py) — 验证框架实现

# Skill 维护和监控指南

## 概述

本指南提供了完整的 Skill 生命周期管理方案，包括：
- **安装和配置** — 新 Skill 的部署流程
- **更新和维护** — 现有 Skill 的升级管理
- **监控和分析** — 执行监控和性能分析
- **故障排除** — 常见问题和解决方案
- **最佳实践** — Skill 开发和部署的最佳实践

---

## 第一部分：Skill 安装和配置

### 1.1 安装新 Skill

#### 前置条件
- Skill 文件已准备好（包含 `SKILL.md` 和必要的脚本）
- 目标目录：`~/.config/opencode/skills/`
- 权限：可写入 `~/.config/opencode/` 目录

#### 安装步骤

**步骤 1：复制 Skill 文件**
```bash
# 假设 Skill 源文件在 /path/to/new-skill/
cp -r /path/to/new-skill/ ~/.config/opencode/skills/new-skill/

# 验证文件
ls -la ~/.config/opencode/skills/new-skill/
```

**步骤 2：检查 Skill 元数据**
```bash
# 验证 SKILL.md 存在
cat ~/.config/opencode/skills/new-skill/SKILL.md

# 验证必要的脚本
ls -la ~/.config/opencode/skills/new-skill/scripts/
```

**步骤 3：验证 Skill 可用性**
```python
from skill_execution_monitor import SkillExecutionMonitor

monitor = SkillExecutionMonitor()

# 列出所有 Skill
skills = monitor.list_executions()
print(f"已安装 Skill 数: {len(skills)}")
```

**步骤 4：运行初始化测试**
```bash
# 如果 Skill 有测试脚本
bash ~/.config/opencode/skills/new-skill/scripts/test.sh

# 或使用监控系统进行测试
python3 tools/skill_execution_monitor.py monitor \
    new-skill \
    exec_init_001 \
    /path/to/test/output.log
```

#### 验证清单

- [ ] Skill 文件已复制到 `~/.config/opencode/skills/new-skill/`
- [ ] `SKILL.md` 文件存在且内容完整
- [ ] 所有必要的脚本都存在
- [ ] 初始化测试通过
- [ ] 执行日志已记录

### 1.2 Skill 配置

#### 配置文件位置

```
~/.config/opencode/skills/new-skill/
├── SKILL.md                    # Skill 描述文件
├── config.json                 # 配置文件（可选）
├── scripts/
│   ├── init.sh                # 初始化脚本
│   ├── test.sh                # 测试脚本
│   └── cleanup.sh             # 清理脚本
└── data/
    └── default-config.json    # 默认配置
```

#### 配置示例

**config.json**
```json
{
  "name": "new-skill",
  "version": "1.0.0",
  "description": "Skill 描述",
  "triggers": ["trigger-word-1", "trigger-word-2"],
  "data_sources": ["webex", "email"],
  "actions": ["search", "analyze"],
  "priority": "high",
  "timeout": 300,
  "retry_count": 3,
  "enabled": true
}
```

#### 应用配置

```bash
# 验证配置文件
python3 -c "
import json
with open('~/.config/opencode/skills/new-skill/config.json') as f:
    config = json.load(f)
    print(f'Skill: {config[\"name\"]}')
    print(f'Version: {config[\"version\"]}')
    print(f'Enabled: {config[\"enabled\"]}')
"
```

---

## 第二部分：Skill 更新和维护

### 2.1 更新现有 Skill

#### 更新流程

**步骤 1：备份当前版本**
```bash
# 创建备份
cp -r ~/.config/opencode/skills/skill-name/ \
      ~/.config/opencode/skills/skill-name.backup.$(date +%Y%m%d)

# 验证备份
ls -la ~/.config/opencode/skills/skill-name.backup.*
```

**步骤 2：更新文件**
```bash
# 复制新版本文件
cp -r /path/to/updated-skill/* ~/.config/opencode/skills/skill-name/

# 验证更新
diff -r /path/to/updated-skill/ ~/.config/opencode/skills/skill-name/
```

**步骤 3：运行迁移脚本（如果需要）**
```bash
# 如果有迁移脚本
bash ~/.config/opencode/skills/skill-name/scripts/migrate.sh

# 验证迁移
echo "迁移完成"
```

**步骤 4：测试更新**
```bash
# 运行测试
bash ~/.config/opencode/skills/skill-name/scripts/test.sh

# 监控执行
python3 tools/skill_execution_monitor.py monitor \
    skill-name \
    exec_update_001 \
    /path/to/test/output.log
```

**步骤 5：验证性能**
```python
from skill_execution_monitor import SkillExecutionMonitor

monitor = SkillExecutionMonitor()

# 分析更新前后的性能
before = monitor.analyze_performance("skill-name", "7d")
print(f"更新前成功率: {before['performance_metrics']['success_rate']}%")

# 更新后再次分析
after = monitor.analyze_performance("skill-name", "24h")
print(f"更新后成功率: {after['performance_metrics']['success_rate']}%")
```

#### 更新清单

- [ ] 已创建备份
- [ ] 新文件已复制
- [ ] 迁移脚本已运行（如需要）
- [ ] 测试通过
- [ ] 性能指标正常
- [ ] 用户已通知

### 2.2 卸载 Skill

#### 卸载步骤

**步骤 1：停止相关进程**
```bash
# 查找相关进程
ps aux | grep skill-name

# 停止进程
pkill -f skill-name
```

**步骤 2：备份数据**
```bash
# 备份 Skill 数据
cp -r ~/.config/opencode/skills/skill-name/ \
      ~/backup/skill-name.$(date +%Y%m%d)

# 备份执行日志
cp -r ~/Documents/claude_projects/skills-optimization/data/executions/skill-name/ \
      ~/backup/executions/skill-name.$(date +%Y%m%d)
```

**步骤 3：删除 Skill**
```bash
# 删除 Skill 目录
rm -rf ~/.config/opencode/skills/skill-name/

# 验证删除
ls ~/.config/opencode/skills/ | grep skill-name
# 应该没有输出
```

**步骤 4：清理配置**
```bash
# 从 opencode.json 中移除 Skill 配置（如有）
# 手动编辑 ~/.config/opencode/opencode.json
# 或使用脚本自动化

python3 << 'EOF'
import json

config_file = "~/.config/opencode/opencode.json"
with open(config_file) as f:
    config = json.load(f)

# 移除 Skill 相关配置
if "skills" in config:
    config["skills"] = [s for s in config["skills"] if s["name"] != "skill-name"]

with open(config_file, 'w') as f:
    json.dump(config, f, indent=2)

print("配置已更新")
EOF
```

#### 卸载清单

- [ ] 相关进程已停止
- [ ] 数据已备份
- [ ] Skill 目录已删除
- [ ] 配置已清理
- [ ] 验证卸载成功

---

## 第三部分：Skill 监控和分析

### 3.1 执行监控

#### 实时监控

```python
from skill_execution_monitor import SkillExecutionMonitor

monitor = SkillExecutionMonitor()

# 监控 Skill 执行
result = monitor.monitor_execution(
    skill_name="second-brain",
    execution_id="exec_abc123",
    log_content="执行日志内容",
    metadata={
        "user": "dawid",
        "duration": 2.5,
        "timestamp": "2026-06-17T10:00:00"
    }
)

print(f"监控状态: {result['status']}")
print(f"日志文件: {result['log_file']}")
```

#### 监控指标

监控系统自动收集以下指标：

| 指标 | 说明 | 示例 |
|------|------|------|
| `total_lines` | 日志总行数 | 42 |
| `has_errors` | 是否有错误 | true/false |
| `has_warnings` | 是否有警告 | true/false |
| `has_success` | 是否有成功指标 | true/false |
| `error_count` | 错误数量 | 2 |
| `warning_count` | 警告数量 | 3 |

### 3.2 性能分析

#### 分析历史数据

```python
# 分析所有时间的性能
analysis = monitor.analyze_performance("second-brain")

# 分析最近 24 小时
analysis_24h = monitor.analyze_performance("second-brain", "24h")

# 分析最近 7 天
analysis_7d = monitor.analyze_performance("second-brain", "7d")

# 分析最近 30 天
analysis_30d = monitor.analyze_performance("second-brain", "30d")
```

#### 性能指标解读

```python
metrics = analysis['performance_metrics']

print(f"总执行数: {metrics['total_executions']}")
print(f"成功数: {metrics['success_count']}")
print(f"失败数: {metrics['error_count']}")
print(f"成功率: {metrics['success_rate']}%")
print(f"错误率: {metrics['error_rate']}%")
print(f"平均日志行数: {metrics['avg_log_lines']}")
print(f"最大日志行数: {metrics['max_log_lines']}")
print(f"最小日志行数: {metrics['min_log_lines']}")
```

#### 性能基线

建立性能基线用于对比：

```python
# 建立基线（第一次运行）
baseline = monitor.analyze_performance("skill-name")
baseline_success_rate = baseline['performance_metrics']['success_rate']

# 保存基线
import json
with open("baseline.json", "w") as f:
    json.dump(baseline, f, indent=2)

# 后续对比
current = monitor.analyze_performance("skill-name", "24h")
current_success_rate = current['performance_metrics']['success_rate']

# 计算变化
change = current_success_rate - baseline_success_rate
print(f"基线成功率: {baseline_success_rate}%")
print(f"当前成功率: {current_success_rate}%")
print(f"变化: {change:+.2f}%")

# 告警
if change < -5:
    print("⚠️ 警告：成功率下降超过 5%")
```

### 3.3 告警机制

#### 自动告警

```python
def check_skill_health(skill_name, alert_threshold=80):
    """检查 Skill 健康状态"""
    
    monitor = SkillExecutionMonitor()
    analysis = monitor.analyze_performance(skill_name, "24h")
    
    metrics = analysis['performance_metrics']
    success_rate = metrics['success_rate']
    
    # 成功率告警
    if success_rate < alert_threshold:
        print(f"🚨 告警: {skill_name} 成功率低于 {alert_threshold}%")
        print(f"   当前成功率: {success_rate}%")
        print(f"   失败数: {metrics['error_count']}")
        return False
    
    # 错误数告警
    if metrics['error_count'] > 5:
        print(f"🚨 告警: {skill_name} 错误数过多")
        print(f"   错误数: {metrics['error_count']}")
        return False
    
    # 警告数告警
    if metrics['total_warnings'] > 10:
        print(f"⚠️ 警告: {skill_name} 警告数过多")
        print(f"   警告数: {metrics['total_warnings']}")
    
    print(f"✅ {skill_name} 健康状态良好")
    return True

# 定期检查
for skill in ["second-brain", "webex-transcript-download", "skill-router"]:
    check_skill_health(skill)
```

#### 告警规则

| 规则 | 条件 | 动作 |
|------|------|------|
| 成功率低 | success_rate < 80% | 🚨 严重告警 |
| 错误过多 | error_count > 5 | 🚨 严重告警 |
| 警告过多 | warning_count > 10 | ⚠️ 普通告警 |
| 性能下降 | success_rate 下降 > 5% | ⚠️ 普通告警 |

---

## 第四部分：故障排除

### 4.1 常见问题

#### 问题 1：Skill 无法找到

**症状**：
```
Error: Skill not found: skill-name
```

**排查步骤**：
```bash
# 1. 检查 Skill 目录
ls -la ~/.config/opencode/skills/skill-name/

# 2. 检查 SKILL.md
cat ~/.config/opencode/skills/skill-name/SKILL.md

# 3. 检查权限
ls -la ~/.config/opencode/skills/ | grep skill-name

# 4. 重新加载 OpenCode
# 重启 OpenCode 或运行：
opencode mcp list
```

**解决方案**：
- 确保 Skill 目录存在
- 确保 `SKILL.md` 文件存在
- 检查目录权限（应该是 755）
- 重新启动 OpenCode

#### 问题 2：执行失败

**症状**：
```
Error: Execution failed
Log: ...
```

**排查步骤**：
```bash
# 1. 查看执行日志
cat ~/Documents/claude_projects/skills-optimization/data/executions/skill-name/exec_xxx/execution.log

# 2. 查看元数据
cat ~/Documents/claude_projects/skills-optimization/data/executions/skill-name/exec_xxx/metadata.json

# 3. 分析错误
python3 << 'EOF'
import json
with open("metadata.json") as f:
    data = json.load(f)
    log_analysis = data.get("log_analysis", {})
    print(f"错误数: {log_analysis.get('error_count', 0)}")
    print(f"警告数: {log_analysis.get('warning_count', 0)}")
EOF
```

**解决方案**：
- 检查日志中的错误信息
- 验证 Skill 的前置条件
- 检查依赖项是否已安装
- 查看 Skill 的故障排除文档

#### 问题 3：性能下降

**症状**：
```
成功率从 95% 下降到 70%
```

**排查步骤**：
```python
from skill_execution_monitor import SkillExecutionMonitor

monitor = SkillExecutionMonitor()

# 1. 对比性能
before = monitor.analyze_performance("skill-name", "7d")
after = monitor.analyze_performance("skill-name", "24h")

print(f"7天成功率: {before['performance_metrics']['success_rate']}%")
print(f"24小时成功率: {after['performance_metrics']['success_rate']}%")

# 2. 查看失败的执行
executions = monitor.list_executions("skill-name", limit=20)
for exec_data in executions:
    if exec_data["log_analysis"]["has_errors"]:
        print(f"失败执行: {exec_data['execution_id']}")

# 3. 分析错误模式
error_patterns = {}
for exec_data in executions:
    if exec_data["log_analysis"]["has_errors"]:
        # 提取错误信息
        # ...
```

**解决方案**：
- 检查最近的更新是否引入了问题
- 回滚到上一个稳定版本
- 检查依赖项的版本
- 查看系统资源使用情况

### 4.2 调试技巧

#### 启用详细日志

```python
import logging

# 启用调试日志
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

from skill_execution_monitor import SkillExecutionMonitor

monitor = SkillExecutionMonitor()
logger.debug(f"监控系统已初始化")

# 执行操作
result = monitor.monitor_execution(...)
logger.debug(f"执行结果: {result}")
```

#### 保存调试信息

```bash
# 保存完整的执行日志
python3 tools/skill_execution_monitor.py monitor \
    skill-name \
    exec_debug_001 \
    /path/to/debug.log \
    2>&1 | tee debug_output.txt

# 分析调试信息
grep -i "error\|warning\|debug" debug_output.txt
```

---

## 第五部分：最佳实践

### 5.1 Skill 开发最佳实践

#### 1. 编写清晰的日志

```python
# ✅ 好的日志
print("2026-06-17 10:00:00 - Starting skill execution")
print("2026-06-17 10:00:01 - Processing data...")
print("2026-06-17 10:00:02 - ✅ Success: Operation completed")

# ❌ 不好的日志
print("running")
print("done")
```

#### 2. 包含成功指标

```python
# ✅ 包含成功指标
if success:
    print("✅ Success: Operation completed")
    print("✅ All checks passed")
else:
    print("❌ Error: Operation failed")
```

#### 3. 提供错误信息

```python
# ✅ 清晰的错误信息
try:
    result = operation()
except Exception as e:
    print(f"Error: {type(e).__name__}: {str(e)}")
    print(f"Error: Failed to process data: {str(e)}")
```

### 5.2 Skill 测试最佳实践

#### 1. 编写测试脚本

```bash
#!/bin/bash
# scripts/test.sh

echo "Testing skill-name..."

# 测试 1：基本功能
echo "Test 1: Basic functionality"
python3 skill_main.py --test
if [ $? -eq 0 ]; then
    echo "✅ Test 1 passed"
else
    echo "❌ Test 1 failed"
    exit 1
fi

# 测试 2：错误处理
echo "Test 2: Error handling"
python3 skill_main.py --invalid-arg 2>&1 | grep -q "Error"
if [ $? -eq 0 ]; then
    echo "✅ Test 2 passed"
else
    echo "❌ Test 2 failed"
    exit 1
fi

echo "✅ All tests passed"
```

#### 2. 运行测试

```bash
# 运行测试脚本
bash ~/.config/opencode/skills/skill-name/scripts/test.sh

# 监控测试执行
python3 tools/skill_execution_monitor.py monitor \
    skill-name \
    exec_test_001 \
    test_output.log
```

### 5.3 Skill 部署最佳实践

#### 1. 部署清单

```bash
# 部署前检查清单
echo "部署前检查清单"
echo "[ ] Skill 文件已准备"
echo "[ ] SKILL.md 已编写"
echo "[ ] 测试已通过"
echo "[ ] 文档已完成"
echo "[ ] 备份已创建"
echo "[ ] 性能基线已建立"
```

#### 2. 灰度部署

```python
# 灰度部署：先在小范围测试
def canary_deployment(skill_name, canary_users=["dawid"]):
    """灰度部署"""
    
    monitor = SkillExecutionMonitor()
    
    # 1. 在小范围内测试
    for user in canary_users:
        print(f"Testing with user: {user}")
        # 执行 Skill
        # ...
    
    # 2. 分析结果
    analysis = monitor.analyze_performance(skill_name, "24h")
    success_rate = analysis['performance_metrics']['success_rate']
    
    # 3. 决定是否全量部署
    if success_rate >= 95:
        print("✅ 灰度测试通过，可以全量部署")
        return True
    else:
        print("❌ 灰度测试失败，暂停部署")
        return False
```

#### 3. 部署后验证

```bash
# 部署后验证
echo "部署后验证"

# 1. 检查 Skill 是否可用
opencode mcp list | grep skill-name

# 2. 运行初始化测试
bash ~/.config/opencode/skills/skill-name/scripts/test.sh

# 3. 监控执行
python3 tools/skill_execution_monitor.py monitor \
    skill-name \
    exec_deploy_001 \
    deploy_test.log

# 4. 分析性能
python3 tools/skill_execution_monitor.py analyze skill-name 24h
```

---

## 总结

本指南涵盖了 Skill 生命周期的所有方面：

| 阶段 | 关键活动 | 工具 |
|------|---------|------|
| **安装** | 复制文件、验证配置、初始化测试 | 文件系统、监控系统 |
| **维护** | 更新、备份、卸载 | 版本控制、备份工具 |
| **监控** | 执行监控、性能分析、告警 | 监控系统、分析工具 |
| **故障排除** | 问题诊断、调试、修复 | 日志分析、调试工具 |
| **最佳实践** | 开发、测试、部署 | 开发工具、测试框架 |

通过遵循本指南，您可以确保 Skill 的稳定性、可靠性和高性能。

---

**版本**：1.0.0  
**发布日期**：2026-06-17  
**状态**：生产就绪

# 🚀 Skill 监控机制启动指南

## 📌 核心问题

**用户如何第一时间启动监控机制？**

答案：通过一个一键启动脚本，自动配置所有监控工具。

---

## ⚡ 一键启动（30 秒）

```bash
# 1. 进入项目目录
cd /Users/wenfeli/Documents/claude_projects/skills-optimization

# 2. 运行一键启动脚本
bash scripts/setup-skill-monitoring.sh

# 3. 重新加载 shell 配置
source ~/.zshrc  # 或 source ~/.bashrc
```

**完成！** 监控机制已启动。

---

## 📊 启动后立即可用的命令

### 实时监控
```bash
# 监控最新的 Skill 执行
skill-watch

# 监控特定的执行
skill-watch exec_second-brain_52098672
```

### 实时仪表板
```bash
# 显示所有最近的执行和统计信息
skill-dashboard
```

### 生成报告
```bash
# 生成最新执行的报告
skill-report

# 生成特定执行的报告
skill-report exec_second-brain_52098672
```

### 快速检查
```bash
# 一行命令查看最新执行的状态
skill-check
```

---

## 🔄 工作流示例

### 场景 1：启动监控后自动追踪 Skill 执行

```bash
# 终端 1：启动监控守护进程（后台运行）
launchctl load ~/Library/LaunchAgents/com.opencode.skill-monitor.plist

# 终端 2：启动实时仪表板
skill-dashboard

# 终端 3：手动触发 Skill（或 Agent 调用 Skill）
# (Agent 调用 second-brain Skill)

# 结果：
# - 仪表板自动显示新的执行
# - 监控守护进程自动发送 macOS 通知
# - 执行完成后自动生成报告
```

### 场景 2：实时监控单个 Skill 执行

```bash
# 终端 1：启动实时日志监控
skill-watch

# 终端 2：手动触发 Skill
# (Agent 调用 Skill)

# 结果：
# - 日志窗口实时显示执行过程
# - 完成后自动显示最终结果
```

### 场景 3：事后查看执行报告

```bash
# 查看最新执行的详细报告
skill-report

# 输出：
# ╔════════════════════════════════════════════════════════════════╗
# ║                    📄 Skill 执行报告                           ║
# ╚════════════════════════════════════════════════════════════════╝
#
# 📋 基本信息
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#   skill_name: second-brain
#   status: success
#   elapsed_seconds: 0.079
#   timestamp: 2026-06-17T14:23:45.123Z
#
# ✅ 前置条件检查
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#   skill_available: true
#   webex_token_valid: true
#   no_conflicts: true
#
# ... (更多详细信息)
```

---

## 🔍 监控机制的三个层次

### 第 1 层：后台守护进程（自动）
- **脚本**：`skill-monitor-daemon.sh`
- **启动方式**：launchd（自动启动）
- **功能**：
  - 监控 `~/.opencode/skill-executions/` 目录
  - 检测新的 Skill 执行
  - 发送 macOS 通知
  - 记录执行日志

### 第 2 层：实时监控工具（手动）
- **脚本**：`skill-watch.sh`、`skill-dashboard.sh`
- **启动方式**：手动运行
- **功能**：
  - 实时显示执行日志
  - 显示实时仪表板
  - 显示统计信息

### 第 3 层：报告生成工具（手动）
- **脚本**：`skill-report.sh`
- **启动方式**：手动运行
- **功能**：
  - 生成详细的执行报告
  - 显示验证结果
  - 列出生成的工件

---

## 📁 启动后的文件结构

```
~/.opencode/
├── skill-executions/          # Skill 执行目录
│   ├── exec_skill1_12345/
│   │   ├── execution.log       # 执行日志
│   │   ├── execution-report.json  # 验证报告
│   │   └── artifacts/          # 生成的工件
│   └── exec_skill2_67890/
│       ├── execution.log
│       ├── execution-report.json
│       └── artifacts/
├── skill-monitor.log           # 监控守护进程日志
└── skill-monitor-error.log     # 错误日志

~/bin/
├── skill-monitor-daemon.sh     # 后台守护进程
├── skill-watch.sh              # 实时日志监控
├── skill-dashboard.sh          # 实时仪表板
└── skill-report.sh             # 报告生成工具

~/Library/LaunchAgents/
└── com.opencode.skill-monitor.plist  # launchd 配置
```

---

## 🛠️ 管理监控服务

### 查看服务状态
```bash
launchctl list | grep skill-monitor
```

### 停止监控服务
```bash
launchctl unload ~/Library/LaunchAgents/com.opencode.skill-monitor.plist
```

### 启动监控服务
```bash
launchctl load ~/Library/LaunchAgents/com.opencode.skill-monitor.plist
```

### 重启监控服务
```bash
launchctl unload ~/Library/LaunchAgents/com.opencode.skill-monitor.plist
launchctl load ~/Library/LaunchAgents/com.opencode.skill-monitor.plist
```

### 查看监控日志
```bash
# 实时查看日志
tail -f ~/.opencode/skill-monitor.log

# 查看错误日志
tail -f ~/.opencode/skill-monitor-error.log

# 查看最后 100 行
tail -100 ~/.opencode/skill-monitor.log
```

---

## ✅ 验证启动成功

```bash
# 1. 检查 launchd 服务
launchctl list | grep skill-monitor
# 输出应该显示：
# - 12345  0  com.opencode.skill-monitor

# 2. 检查脚本是否存在
ls -la ~/bin/skill-*.sh
# 输出应该显示 4 个脚本文件

# 3. 检查别名是否生效
alias | grep skill
# 输出应该显示 4 个别名

# 4. 查看监控日志
tail -5 ~/.opencode/skill-monitor.log
# 输出应该显示最近的监控日志
```

---

## 🚨 故障排除

### 问题 1：launchd 服务没有启动

**症状**：`launchctl list | grep skill-monitor` 没有输出

**解决方案**：
```bash
# 手动加载服务
launchctl load ~/Library/LaunchAgents/com.opencode.skill-monitor.plist

# 查看错误
cat ~/.opencode/skill-monitor-error.log
```

### 问题 2：没有收到 macOS 通知

**症状**：Skill 执行完成但没有通知

**解决方案**：
```bash
# 检查 macOS 通知设置
# 系统偏好设置 > 通知 > 允许来自 Terminal 的通知

# 手动测试通知
osascript -e 'display notification "Test" with title "Test"'
```

### 问题 3：监控日志太大

**症状**：`~/.opencode/skill-monitor.log` 文件很大

**解决方案**：
```bash
# 清理日志
rm ~/.opencode/skill-monitor.log
rm ~/.opencode/skill-monitor-error.log

# 重启服务
launchctl unload ~/Library/LaunchAgents/com.opencode.skill-monitor.plist
launchctl load ~/Library/LaunchAgents/com.opencode.skill-monitor.plist
```

### 问题 4：命令别名不生效

**症状**：运行 `skill-watch` 提示命令不存在

**解决方案**：
```bash
# 重新加载 shell 配置
source ~/.zshrc  # 或 source ~/.bashrc

# 或者重启终端
```

---

## 📚 相关文档

- [SKILL-MONITORING-STARTUP.md](docs/SKILL-MONITORING-STARTUP.md) — 完整的监控机制设计
- [SKILL-CALL-CONFIRMATION.md](docs/SKILL-CALL-CONFIRMATION.md) — Skill 调用确认机制
- [SKILL-EXECUTION-VERIFICATION.md](docs/SKILL-EXECUTION-VERIFICATION.md) — 验证机制设计

---

## 🎯 下一步

1. ✅ **立即启动** — 运行 `bash scripts/setup-skill-monitoring.sh`
2. ✅ **测试监控** — 手动触发一个 Skill，观察监控反应
3. ✅ **集成到 Agent** — 让 Agent 在调用 Skill 时自动提供 execution_id
4. ✅ **建立告警** — 当 Skill 执行失败时自动告警

---

## 💡 提示

- 监控守护进程在后台持续运行，无需手动启动
- 所有监控命令都可以在任何时间运行
- 执行日志和报告会自动保存到 `~/.opencode/skill-executions/`
- 可以同时运行多个监控工具（仪表板 + 日志监控）

---

**现在就启动监控机制吧！** 🚀

```bash
bash /Users/wenfeli/Documents/claude_projects/skills-optimization/scripts/setup-skill-monitoring.sh
```

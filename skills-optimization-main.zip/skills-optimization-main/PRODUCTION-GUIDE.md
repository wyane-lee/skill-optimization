# Skill 监控系统 - 投产指南

## 📋 目录

1. [快速安装](#快速安装)
2. [详细安装](#详细安装)
3. [验证安装](#验证安装)
4. [使用指南](#使用指南)
5. [故障排除](#故障排除)
6. [卸载](#卸载)

---

## 快速安装

### 一键安装（推荐）

```bash
# 1. 复制 Skill 到 OpenCode
mkdir -p ~/.config/opencode/skills/skill-monitoring
cp -r /Users/wenfeli/Documents/claude_projects/skills-optimization/* \
      ~/.config/opencode/skills/skill-monitoring/

# 2. 运行安装脚本
bash ~/.config/opencode/skills/skill-monitoring/scripts/setup-skill-monitoring.sh

# 3. 验证安装
launchctl list | grep skill-monitor
```

**预期输出**：
```
- 0 com.opencode.skill-monitor
```

---

## 详细安装

### 步骤 1：创建 Skill 目录

```bash
mkdir -p ~/.config/opencode/skills/skill-monitoring
```

### 步骤 2：复制项目文件

```bash
# 复制所有文件
cp -r /Users/wenfeli/Documents/claude_projects/skills-optimization/* \
      ~/.config/opencode/skills/skill-monitoring/

# 验证文件结构
ls -la ~/.config/opencode/skills/skill-monitoring/
```

**预期目录结构**：
```
~/.config/opencode/skills/skill-monitoring/
├── SKILL.md                          # Skill 描述文件
├── scripts/
│   ├── setup-skill-monitoring.sh
│   ├── skill-monitor-daemon.sh
│   ├── skill-watch.sh
│   ├── skill-dashboard.sh
│   ├── skill-report.sh
│   └── com.opencode.skill-monitor.plist
├── tools/
│   ├── skill_monitoring.py
│   ├── skill_router.py
│   ├── usage_analyzer.py
│   ├── skill-execution-verifier.py
│   └── test_suite.py
├── docs/
│   ├── SKILL-MONITORING-STARTUP.md
│   ├── SKILL-CALL-CONFIRMATION.md
│   └── SKILL-EXECUTION-VERIFICATION.md
└── data/
    ├── skills-inventory.json
    ├── skills-matrix.json
    ├── overlaps-detected.json
    └── skills-documentation.json
```

### 步骤 3：运行安装脚本

```bash
bash ~/.config/opencode/skills/skill-monitoring/scripts/setup-skill-monitoring.sh
```

**脚本会自动**：
- 创建必要的目录（`~/.opencode/skill-executions`）
- 复制脚本到 `~/bin/`
- 安装 launchd 服务
- 创建 shell 别名

### 步骤 4：重启 shell（可选）

```bash
# 重新加载 shell 配置
source ~/.zshrc  # 或 ~/.bashrc
```

---

## 验证安装

### 检查 1：launchd 服务

```bash
# 检查服务是否已安装
launchctl list | grep skill-monitor

# 预期输出：
# - 0 com.opencode.skill-monitor
```

### 检查 2：命令别名

```bash
# 检查别名是否可用
which skill-watch
which skill-dashboard
which skill-report

# 预期输出：
# /Users/wenfeli/bin/skill-watch
# /Users/wenfeli/bin/skill-dashboard
# /Users/wenfeli/bin/skill-report
```

### 检查 3：目录结构

```bash
# 检查 Skill 目录
ls -la ~/.config/opencode/skills/skill-monitoring/

# 检查执行目录
ls -la ~/.opencode/skill-executions/

# 检查脚本目录
ls -la ~/bin/skill-*
```

### 检查 4：运行测试

```bash
# 运行完整测试套件
python3 ~/.config/opencode/skills/skill-monitoring/tools/test_suite.py

# 预期输出：
# ✅ 总体统计: 22 通过, 0 失败, 成功率 100.00%
```

---

## 使用指南

### 命令行使用

#### 1. 启动监控

```bash
# 一键启动
bash ~/.config/opencode/skills/skill-monitoring/scripts/setup-skill-monitoring.sh

# 或使用别名
skill-setup
```

#### 2. 实时监控

```bash
# 监控最新执行
skill-watch

# 监控特定执行
skill-watch exec_abc123_1234567890

# 显示最后 100 行
skill-watch exec_abc123_1234567890 100
```

#### 3. 显示仪表板

```bash
# 显示实时仪表板
skill-dashboard

# 每 2 秒刷新一次，显示最近的执行和统计信息
```

#### 4. 生成报告

```bash
# 生成最新执行的报告
skill-report

# 生成特定执行的报告
skill-report exec_abc123_1234567890
```

#### 5. 快速检查

```bash
# 快速检查系统状态
skill-check
```

### Python API 使用

#### 1. 导入模块

```python
from skill_monitoring import SkillMonitoring
from skill_router import SkillRouter
from usage_analyzer import UsageAnalyzer
```

#### 2. 监控 Skill 执行

```python
monitor = SkillMonitoring()

# 生成执行 ID
execution_id = monitor.generate_execution_id()
print(f"执行 ID: {execution_id}")

# 列出最近的执行
executions = monitor.list_executions(limit=5)
for exec_info in executions["executions"]:
    print(f"  {exec_info['execution_id']}: {exec_info['status']}")

# 获取执行状态
status = monitor.get_execution_status(execution_id)
print(f"状态: {status['status']}")
```

#### 3. 路由到合适的 Skill

```python
router = SkillRouter()

# 根据用户意图路由
matches = router.route("我想监控 Skill 执行", top_k=3)
for match in matches:
    print(f"  {match.skill_name}: {match.similarity_score:.2f}")

# 根据操作类型路由
matches = router.route_by_action("search", top_k=3)

# 根据数据源路由
matches = router.route_by_data_source("webex", top_k=3)
```

#### 4. 分析性能

```python
analyzer = UsageAnalyzer()

# 分析所有执行
analysis = analyzer.analyze_all()
print(f"成功率: {analysis['summary']['success_rate']}%")

# 分析特定 Skill
skill_analysis = analyzer.analyze_skill("skill-name")

# 获取成功率
success_rate = analyzer.get_success_rate()
print(f"成功率: {success_rate['success_rate']}%")

# 获取错误报告
errors = analyzer.get_error_report()
print(f"错误数: {errors['error_count']}")

# 获取性能报告
performance = analyzer.get_performance_report()
print(f"平均耗时: {performance['performance']['average_duration']}s")
```

---

## 故障排除

### 问题 1：launchd 服务未启动

**症状**：`launchctl list | grep skill-monitor` 返回空

**解决方案**：

```bash
# 1. 检查 plist 文件
ls -la ~/Library/LaunchAgents/com.opencode.skill-monitor.plist

# 2. 手动加载服务
launchctl load ~/Library/LaunchAgents/com.opencode.skill-monitor.plist

# 3. 验证加载
launchctl list | grep skill-monitor
```

### 问题 2：命令别名不可用

**症状**：`command not found: skill-watch`

**解决方案**：

```bash
# 1. 检查脚本是否存在
ls -la ~/bin/skill-*

# 2. 检查 PATH
echo $PATH | grep ~/bin

# 3. 重新加载 shell 配置
source ~/.zshrc  # 或 ~/.bashrc

# 4. 手动添加到 PATH（如果需要）
export PATH="$HOME/bin:$PATH"
```

### 问题 3：执行目录不存在

**症状**：`mkdir: cannot create directory ~/.opencode/skill-executions`

**解决方案**：

```bash
# 1. 创建目录
mkdir -p ~/.opencode/skill-executions

# 2. 检查权限
ls -la ~/.opencode/

# 3. 修改权限（如果需要）
chmod 755 ~/.opencode/
```

### 问题 4：Python 模块导入失败

**症状**：`ModuleNotFoundError: No module named 'skill_monitoring'`

**解决方案**：

```bash
# 1. 检查 Python 路径
python3 -c "import sys; print(sys.path)"

# 2. 添加 Skill 目录到 PYTHONPATH
export PYTHONPATH="$HOME/.config/opencode/skills/skill-monitoring/tools:$PYTHONPATH"

# 3. 验证导入
python3 -c "from skill_monitoring import SkillMonitoring; print('OK')"
```

### 问题 5：权限被拒绝

**症状**：`Permission denied: setup-skill-monitoring.sh`

**解决方案**：

```bash
# 1. 添加执行权限
chmod +x ~/.config/opencode/skills/skill-monitoring/scripts/*.sh

# 2. 验证权限
ls -la ~/.config/opencode/skills/skill-monitoring/scripts/

# 3. 重新运行脚本
bash ~/.config/opencode/skills/skill-monitoring/scripts/setup-skill-monitoring.sh
```

### 问题 6：测试失败

**症状**：`test_suite.py` 返回非零退出码

**解决方案**：

```bash
# 1. 运行测试并查看详细输出
python3 ~/.config/opencode/skills/skill-monitoring/tools/test_suite.py

# 2. 检查测试报告
cat ~/.config/opencode/skills/skill-monitoring/tools/test-report.json | jq

# 3. 检查日志
ls -la ~/.opencode/skill-executions/
```

---

## 卸载

### 完全卸载

```bash
# 1. 停止 launchd 服务
launchctl unload ~/Library/LaunchAgents/com.opencode.skill-monitor.plist

# 2. 删除 launchd 配置
rm ~/Library/LaunchAgents/com.opencode.skill-monitor.plist

# 3. 删除脚本
rm ~/bin/skill-*

# 4. 删除 Skill 目录
rm -rf ~/.config/opencode/skills/skill-monitoring

# 5. 删除执行目录（可选）
rm -rf ~/.opencode/skill-executions
```

### 保留数据卸载

```bash
# 1-3. 同上

# 4. 只删除 Skill 目录，保留执行数据
rm -rf ~/.config/opencode/skills/skill-monitoring

# 5. 执行数据保留在 ~/.opencode/skill-executions/
```

---

## 支持

### 获取帮助

```bash
# 查看文档
cat ~/.config/opencode/skills/skill-monitoring/SKILL.md

# 查看设计文档
cat ~/.config/opencode/skills/skill-monitoring/docs/SKILL-MONITORING-STARTUP.md

# 查看测试报告
cat ~/.config/opencode/skills/skill-monitoring/tools/test-report.json | jq
```

### 报告问题

如遇到问题，请：

1. 收集日志：
   ```bash
   cat ~/.opencode/skill-monitor.log
   ```

2. 收集执行信息：
   ```bash
   ls -la ~/.opencode/skill-executions/
   ```

3. 运行诊断：
   ```bash
   python3 ~/.config/opencode/skills/skill-monitoring/tools/test_suite.py
   ```

---

## 下一步

安装完成后，你可以：

1. **启动监控**：
   ```bash
   bash ~/.config/opencode/skills/skill-monitoring/scripts/setup-skill-monitoring.sh
   ```

2. **查看仪表板**：
   ```bash
   skill-dashboard
   ```

3. **运行测试**：
   ```bash
   python3 ~/.config/opencode/skills/skill-monitoring/tools/test_suite.py
   ```

4. **阅读文档**：
   ```bash
   cat ~/.config/opencode/skills/skill-monitoring/docs/SKILL-MONITORING-STARTUP.md
   ```

---

## 版本信息

- **版本**：1.0.0
- **发布日期**：2026-06-17
- **状态**：生产就绪
- **测试覆盖**：100%（22/22 测试通过）

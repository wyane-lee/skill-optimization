# 🚀 Skill 监控机制快速启动指南

## 一键启动（推荐）

```bash
# 1. 复制脚本到 ~/bin
cp scripts/skill-*.sh ~/bin/
chmod +x ~/bin/skill-*.sh

# 2. 安装 launchd 服务（自动启动）
cp scripts/com.opencode.skill-monitor.plist ~/Library/LaunchAgents/
launchctl load ~/Library/LaunchAgents/com.opencode.skill-monitor.plist

# 3. 验证服务运行
launchctl list | grep skill-monitor

# 4. 查看监控日志
tail -f ~/.opencode/skill-monitor.log
```

---

## 监控命令

### 实时监控最新执行
```bash
skill-watch
```

### 监控特定执行
```bash
skill-watch exec_second-brain_52098672
```

### 显示实时仪表板
```bash
skill-dashboard
```

### 生成执行报告
```bash
skill-report
```

### 快速检查
```bash
cat ~/.opencode/skill-executions/$(ls -t ~/.opencode/skill-executions/ | head -1)/execution-report.json | jq
```

---

## 工作流

### 场景 1：启动监控后手动触发 Skill

```bash
# 1. 启动监控守护进程
launchctl load ~/Library/LaunchAgents/com.opencode.skill-monitor.plist

# 2. 在另一个终端中手动触发 Skill
# (Agent 调用 Skill)

# 3. 监控守护进程会自动：
#    - 检测到新的执行
#    - 显示实时日志
#    - 执行完成后发送通知
#    - 生成执行报告
```

### 场景 2：实时监控 Skill 执行

```bash
# 终端 1：启动仪表板
skill-dashboard

# 终端 2：实时监控日志
skill-watch

# 终端 3：手动触发 Skill
# (Agent 调用 Skill)

# 结果：
# - 仪表板显示最新执行
# - 日志窗口显示实时日志
# - 完成后自动生成报告
```

### 场景 3：事后查看报告

```bash
# 查看最新执行的报告
skill-report

# 查看特定执行的报告
skill-report exec_second-brain_52098672

# 查看详细的 JSON 报告
cat ~/.opencode/skill-executions/exec_second-brain_52098672/execution-report.json | jq
```

---

## 监控脚本说明

| 脚本 | 用途 | 启动方式 |
|------|------|---------|
| **skill-monitor-daemon.sh** | 后台监控守护进程 | launchd（自动） |
| **skill-watch.sh** | 实时监控日志 | 手动 |
| **skill-dashboard.sh** | 实时仪表板 | 手动 |
| **skill-report.sh** | 生成执行报告 | 手动 |

---

## 故障排除

### 监控守护进程没有启动

```bash
# 检查 launchd 状态
launchctl list | grep skill-monitor

# 如果没有显示，手动加载
launchctl load ~/Library/LaunchAgents/com.opencode.skill-monitor.plist

# 查看错误日志
cat ~/.opencode/skill-monitor-error.log
```

### 没有收到通知

```bash
# 检查 macOS 通知设置
# 系统偏好设置 > 通知 > 允许来自 Terminal 的通知

# 或者手动测试通知
osascript -e 'display notification "Test" with title "Test"'
```

### 监控日志太大

```bash
# 清理旧的监控日志
rm ~/.opencode/skill-monitor.log
rm ~/.opencode/skill-monitor-error.log

# 重启守护进程
launchctl unload ~/Library/LaunchAgents/com.opencode.skill-monitor.plist
launchctl load ~/Library/LaunchAgents/com.opencode.skill-monitor.plist
```

---

## 高级配置

### 自定义监控间隔

编辑 `skill-monitor-daemon.sh`，修改：
```bash
sleep 0.5  # 改为你想要的间隔（秒）
```

### 自定义通知方式

编辑 `skill-monitor-daemon.sh`，修改通知部分：
```bash
# 发送 Slack 通知
curl -X POST -H 'Content-type: application/json' \
    --data "{\"text\":\"Skill $skill_name 执行完成\"}" \
    $SLACK_WEBHOOK_URL

# 发送邮件通知
echo "Skill $skill_name 执行完成" | mail -s "Skill 执行完成" user@example.com
```

### 自定义报告格式

编辑 `skill-report.sh`，修改输出格式

---

## 下一步

1. ✅ **立即启动** — 运行一键启动命令
2. ✅ **测试监控** — 手动触发一个 Skill，观察监控反应
3. ✅ **集成到 Agent** — 让 Agent 在调用 Skill 时自动提供 execution_id
4. ✅ **建立告警** — 当 Skill 执行失败时自动告警

---

## 参考资源

- [SKILL-MONITORING-STARTUP.md](SKILL-MONITORING-STARTUP.md) — 完整的监控机制设计
- [SKILL-CALL-CONFIRMATION.md](SKILL-CALL-CONFIRMATION.md) — Skill 调用确认机制
- [SKILL-EXECUTION-VERIFICATION.md](SKILL-EXECUTION-VERIFICATION.md) — 验证机制设计

# 项目部署形式分析：Plugin vs Skill

## 核心问题

**这个项目应该以什么形式安装或投产？是 Plugin 还是 Skill？**

---

## 📊 对比分析

### Plugin 模式

**定义**：Plugin 是 OpenCode 的扩展机制，通过修改 `opencode.json` 配置文件来加载。

**特点**：
- 在 `opencode.json` 中注册
- 可以添加新的 MCP 服务器
- 可以添加新的 Agent
- 可以修改 OpenCode 的核心行为
- 需要重启 OpenCode 才能生效

**示例**：
```json
{
  "plugins": [
    {
      "name": "skill-monitoring",
      "type": "monitoring",
      "config": {
        "enabled": true,
        "daemon": true
      }
    }
  ]
}
```

### Skill 模式

**定义**：Skill 是 OpenCode 中的一个工具集合，通过 `~/.config/opencode/skills/` 目录加载。

**特点**：
- 在 `~/.config/opencode/skills/` 中创建目录
- 包含 `SKILL.md` 文件（描述和使用说明）
- 可以包含脚本、工具、配置
- 无需重启 OpenCode 即可使用
- Agent 可以通过 `skill` 工具调用

**示例**：
```
~/.config/opencode/skills/
└── skill-monitoring/
    ├── SKILL.md
    ├── scripts/
    │   ├── setup.sh
    │   ├── monitor.sh
    │   └── ...
    └── config/
        └── ...
```

---

## 🎯 这个项目应该选择哪种形式？

### 分析

#### 项目的特点
1. ✅ 不需要修改 OpenCode 核心行为
2. ✅ 不需要添加新的 MCP 服务器
3. ✅ 不需要添加新的 Agent
4. ✅ 是一个独立的工具集合
5. ✅ 包含脚本、文档、配置
6. ✅ 可以独立运行和管理
7. ✅ 用户可以选择性地启用或禁用

#### 结论

**应该采用 Skill 模式** ✅

**原因**：
1. 项目是一个独立的工具集合，不需要修改 OpenCode 核心
2. 项目包含脚本和文档，符合 Skill 的结构
3. 用户可以通过 `skill` 工具调用，无需重启 OpenCode
4. 更灵活，更易于维护和更新
5. 符合 OpenCode 的设计哲学

---

## 📦 Skill 模式的部署方案

### 方案 1：标准 Skill 安装

#### 步骤 1：创建 Skill 目录结构
```bash
mkdir -p ~/.config/opencode/skills/skill-monitoring
```

#### 步骤 2：创建 SKILL.md（Skill 描述文件）
```markdown
# Skill: Skill 监控机制

## 用途
监控 OpenCode 中 Skill 的执行，提供实时追踪、验证和报告功能。

## 触发条件
- 用户说"启动 Skill 监控"
- 用户说"监控 Skill 执行"
- 用户说"skill-watch"、"skill-dashboard"、"skill-report"

## 功能
- 一键启动监控机制
- 实时监控 Skill 执行
- 自动生成执行报告
- 发送 macOS 通知

## 使用方式
```bash
# 一键启动
bash ~/.config/opencode/skills/skill-monitoring/scripts/setup-skill-monitoring.sh

# 实时监控
skill-watch
skill-dashboard
skill-report
```

## 输出
- 执行日志：~/.opencode/skill-executions/{execution_id}/execution.log
- 验证报告：~/.opencode/skill-executions/{execution_id}/execution-report.json
- 工件：~/.opencode/skill-executions/{execution_id}/artifacts/
```

#### 步骤 3：复制项目文件
```bash
# 复制脚本
cp -r scripts/* ~/.config/opencode/skills/skill-monitoring/

# 复制文档
cp docs/*.md ~/.config/opencode/skills/skill-monitoring/

# 复制工具
cp tools/*.py ~/.config/opencode/skills/skill-monitoring/

# 复制数据
cp -r data/ ~/.config/opencode/skills/skill-monitoring/
```

#### 步骤 4：创建安装脚本
```bash
# ~/.config/opencode/skills/skill-monitoring/install.sh
#!/bin/bash

# 创建必要的目录
mkdir -p ~/bin
mkdir -p ~/.opencode

# 复制脚本到 ~/bin
cp scripts/skill-*.sh ~/bin/
chmod +x ~/bin/skill-*.sh

# 安装 launchd 服务
cp scripts/com.opencode.skill-monitor.plist ~/Library/LaunchAgents/
launchctl load ~/Library/LaunchAgents/com.opencode.skill-monitor.plist

echo "✅ Skill 监控机制已安装"
```

#### 步骤 5：用户使用
```bash
# Agent 调用 Skill
skill skill-monitoring

# 或者用户直接运行
bash ~/.config/opencode/skills/skill-monitoring/scripts/setup-skill-monitoring.sh
```

---

### 方案 2：集成到 OpenCode 的 Skill 工具

#### 创建 Skill 工具接口
```python
# ~/.config/opencode/skills/skill-monitoring/skill_monitoring.py

class SkillMonitoring:
    """Skill 监控工具"""
    
    def __init__(self):
        self.base_dir = os.path.expanduser("~/.config/opencode/skills/skill-monitoring")
    
    def setup(self):
        """一键启动"""
        script = os.path.join(self.base_dir, "scripts/setup-skill-monitoring.sh")
        subprocess.run(["bash", script])
    
    def watch(self, execution_id=None):
        """实时监控"""
        script = os.path.join(self.base_dir, "scripts/skill-watch.sh")
        subprocess.run(["bash", script, execution_id or ""])
    
    def dashboard(self):
        """显示仪表板"""
        script = os.path.join(self.base_dir, "scripts/skill-dashboard.sh")
        subprocess.run(["bash", script])
    
    def report(self, execution_id=None):
        """生成报告"""
        script = os.path.join(self.base_dir, "scripts/skill-report.sh")
        subprocess.run(["bash", script, execution_id or ""])
```

#### Agent 调用方式
```python
# Agent 可以这样调用
from skill_monitoring import SkillMonitoring

monitor = SkillMonitoring()
monitor.setup()           # 一键启动
monitor.watch()           # 实时监控
monitor.dashboard()       # 显示仪表板
monitor.report()          # 生成报告
```

---

## 📁 最终的 Skill 目录结构

```
~/.config/opencode/skills/skill-monitoring/
├── SKILL.md                          # Skill 描述文件
├── install.sh                        # 安装脚本
├── skill_monitoring.py               # Python 接口
├── scripts/
│   ├── setup-skill-monitoring.sh
│   ├── skill-monitor-daemon.sh
│   ├── skill-watch.sh
│   ├── skill-dashboard.sh
│   ├── skill-report.sh
│   └── com.opencode.skill-monitor.plist
├── docs/
│   ├── SKILL-MONITORING-STARTUP.md
│   ├── SKILL-CALL-CONFIRMATION.md
│   └── SKILL-EXECUTION-VERIFICATION.md
├── tools/
│   ├── skill-execution-verifier.py
│   └── build-matrix-and-detect.py
└── data/
    ├── skills-inventory.json
    ├── skills-matrix.json
    ├── overlaps-detected.json
    └── skills-documentation.json
```

---

## 🚀 安装步骤

### 步骤 1：复制 Skill 到 OpenCode
```bash
# 从项目目录复制到 OpenCode skills 目录
cp -r /Users/wenfeli/Documents/claude_projects/skills-optimization \
      ~/.config/opencode/skills/skill-monitoring
```

### 步骤 2：创建 SKILL.md
```bash
# 在 Skill 目录中创建 SKILL.md
cat > ~/.config/opencode/skills/skill-monitoring/SKILL.md << 'EOF'
# Skill: Skill 监控机制

## 用途
监控 OpenCode 中 Skill 的执行，提供实时追踪、验证和报告功能。

## 功能
- 一键启动监控机制
- 实时监控 Skill 执行
- 自动生成执行报告
- 发送 macOS 通知

## 使用
bash ~/.config/opencode/skills/skill-monitoring/scripts/setup-skill-monitoring.sh
EOF
```

### 步骤 3：运行安装脚本
```bash
bash ~/.config/opencode/skills/skill-monitoring/scripts/setup-skill-monitoring.sh
```

### 步骤 4：验证安装
```bash
# 检查 launchd 服务
launchctl list | grep skill-monitor

# 检查命令别名
alias | grep skill
```

---

## 🔄 与 Plugin 的对比

| 特性 | Skill 模式 | Plugin 模式 |
|------|-----------|-----------|
| 安装位置 | `~/.config/opencode/skills/` | `opencode.json` |
| 需要重启 | ❌ 否 | ✅ 是 |
| 独立性 | ✅ 高 | ❌ 低 |
| 灵活性 | ✅ 高 | ❌ 低 |
| 易于维护 | ✅ 是 | ❌ 否 |
| 易于卸载 | ✅ 是 | ❌ 否 |
| 适合本项目 | ✅ 是 | ❌ 否 |

---

## 💡 为什么选择 Skill 模式？

1. **独立性强** — 不需要修改 OpenCode 核心配置
2. **易于安装** — 只需复制文件到 `~/.config/opencode/skills/`
3. **易于卸载** — 只需删除 Skill 目录
4. **易于更新** — 无需重启 OpenCode
5. **易于维护** — 所有文件都在一个目录中
6. **符合设计** — 符合 OpenCode 的 Skill 设计哲学
7. **用户友好** — 用户可以选择性地启用或禁用

---

## 📋 投产清单

### 前置条件
- [ ] 项目文件已准备好
- [ ] 所有脚本都已测试
- [ ] 所有文档都已完成

### 安装步骤
- [ ] 复制 Skill 到 `~/.config/opencode/skills/skill-monitoring`
- [ ] 创建 `SKILL.md` 文件
- [ ] 运行安装脚本
- [ ] 验证安装成功

### 验证步骤
- [ ] 检查 launchd 服务是否运行
- [ ] 检查命令别名是否生效
- [ ] 手动触发一个 Skill 执行
- [ ] 观察监控反应

### 文档步骤
- [ ] 更新 AGENTS.md（添加 Skill 描述）
- [ ] 创建安装指南
- [ ] 创建使用指南

---

## 🎯 建议的投产方案

### 方案：标准 Skill 安装

1. **创建 Skill 目录**
   ```bash
   mkdir -p ~/.config/opencode/skills/skill-monitoring
   ```

2. **复制项目文件**
   ```bash
   cp -r /Users/wenfeli/Documents/claude_projects/skills-optimization/* \
         ~/.config/opencode/skills/skill-monitoring/
   ```

3. **创建 SKILL.md**
   ```bash
   # 在 Skill 目录中创建 SKILL.md
   ```

4. **运行安装脚本**
   ```bash
   bash ~/.config/opencode/skills/skill-monitoring/scripts/setup-skill-monitoring.sh
   ```

5. **验证安装**
   ```bash
   launchctl list | grep skill-monitor
   ```

---

## 📚 相关文档

- [SKILL-MONITORING-STARTUP.md](docs/SKILL-MONITORING-STARTUP.md) — 完整设计
- [STARTUP-GUIDE.md](STARTUP-GUIDE.md) — 启动指南
- [PROJECT-STATUS.md](PROJECT-STATUS.md) — 项目状态

---

## 🎉 结论

**这个项目应该以 Skill 模式安装和投产。**

**优势**：
- ✅ 独立性强，不需要修改 OpenCode 核心
- ✅ 易于安装、卸载、更新
- ✅ 符合 OpenCode 的设计哲学
- ✅ 用户友好，易于使用

**安装方式**：
1. 复制文件到 `~/.config/opencode/skills/skill-monitoring`
2. 创建 `SKILL.md` 文件
3. 运行安装脚本
4. 验证安装成功

**立即投产**：
```bash
# 一键安装
bash ~/.config/opencode/skills/skill-monitoring/scripts/setup-skill-monitoring.sh
```
